"""Backend-neutral API: plain-dict/JSON-string functions used by both the local GUI
server (gui.py) and the Pyodide browser build (webui/pyodide-adapter.js).

All functions are stateless apart from the cached Tables instance; inputs and outputs
are JSON strings so the Pyodide boundary stays trivial.
"""
from __future__ import annotations

import base64
import json
from datetime import datetime

import yaml

from .model import load_project
from .rules import apply_auto_groups, generate, synthesize_motherwords
from .sqlout import default_filename, render_sql
from .tables import Tables, project_tables
from .validate import soft_checks_detailed, validate_detailed
from .yamlio import OPTION_DEFAULTS, SCHEMA_HEADER, to_yaml_dict

_tables: Tables | None = None


def tables() -> Tables:
    global _tables
    if _tables is None:
        _tables = Tables()
    return _tables


def source_rows(project) -> list[int | None]:
    """Map each validated point back to the row the caller sent.

    Validation runs after motherword synthesis, so the "point N" in an error
    counts rows the caller never wrote. Entry i is the 1-based index of that
    point in the incoming list, or None for a row this tool invented.
    """
    out: list[int | None] = []
    seen = 0
    for p in project.points:
        if p.synthesized:
            out.append(None)
        else:
            seen += 1
            out.append(seen)
    return out


def prepare(data: dict):
    """Load + auto-fill + synthesize + validate.
    Returns (project, findings, notes, point_rows).

    `findings` carry the code, the address, the advice and any suggestion; every caller
    that only wants sentences takes `.message`."""
    project = load_project(to_yaml_dict(data))
    # the project's own datatype rows join the shipped ones here, once, so every step
    # below reads the same table
    t = project_tables(project, tables())
    apply_auto_groups(project, t)
    created = synthesize_motherwords(project, t)
    errors = validate_detailed(project, t)
    notes = [f"synthesized motherword for addr {p.addr} (group {p.group})"
             for p in created]
    # warnings stay inside `notes` as the "warning: …" strings every caller expects,
    # and travel structurally as well - a prefix is a poor way to tell a warning from
    # a note, and it is the only way there was
    warnings = soft_checks_detailed(project, t)
    notes.extend(w.message for w in warnings)
    return project, errors, notes, source_rows(project), warnings


def bootstrap_json() -> str:
    t = tables()
    return json.dumps({
        "projects": [],
        "project_times": {},     # no filesystem in the browser build; see gui.Api
        "defaults": OPTION_DEFAULTS,
        "datatypes": [vars(d) for d in t.datatypes.values()],
        "units": sorted(t.units),
        "scaling": list(t.scaling),
        # no filesystem here, so a datatype cannot be promoted into the shared table:
        # the page hides that action rather than offering one that cannot work
        "writable_tables": False,
    })


def validate_json(project_json: str) -> str:
    try:
        project, errors, notes, rows, warns = prepare(json.loads(project_json))
    except Exception as e:
        return json.dumps({"errors": [str(e)], "notes": []})
    return json.dumps({"errors": [f.message for f in errors],
                       "findings": [f.as_dict() for f in errors],
                       "warnings": [w.as_dict() for w in warns],
                       "notes": notes, "point_rows": rows,
                       "points": len(project.points), "groups": len(project.groups)})


def generate_json(project_json: str, timestamp: str | None = None) -> str:
    try:
        project, errors, notes, rows, warns = prepare(json.loads(project_json))
    except Exception as e:
        return json.dumps({"errors": [str(e)], "notes": []})
    if errors:
        return json.dumps({"errors": [f.message for f in errors],
                           "findings": [f.as_dict() for f in errors],
                           "warnings": [w.as_dict() for w in warns],
                           "notes": notes, "point_rows": rows})
    ts = timestamp or datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    sql = render_sql(project, generate(project, tables(), ts))
    encoded = sql.encode(project.options.encoding, errors="replace")
    return json.dumps({
        "errors": [], "warnings": [w.as_dict() for w in warns],
        "notes": notes, "sql": sql,
        "points": len(project.points), "groups": len(project.groups),
        "filename": default_filename(project),
        "b64": base64.b64encode(encoded).decode("ascii"),
    })


def import_xlsm_json(b64: str, filename: str = "workbook.xlsm") -> str:
    """A Modbustemplate workbook (base64) -> {"project": dict, "notes": [str]}.

    Backs the GUI's Insert Excel button in both backends. The bytes are written to a
    temporary file because both importers take a path and derive a fallback table
    name from it; Pyodide's virtual filesystem serves that as well as a real one.
    Mirrors the CLI's fallback to the older template generation.
    """
    import shutil
    import tempfile
    from pathlib import Path

    tmpdir = tempfile.mkdtemp()
    try:
        path = Path(tmpdir) / (Path(filename).name or "workbook.xlsm")
        path.write_bytes(base64.b64decode(b64))
        from .importer import import_xlsm
        try:
            data, notes = import_xlsm(path)
        except ValueError as e:
            if "missing sheet" not in str(e):
                raise
            from .importer_old import import_old_xlsm
            data, notes = import_old_xlsm(path)
            notes.insert(0, "old-format workbook detected - reconstructed from its "
                            "generated columns")
        from .notes import as_dicts
        return json.dumps({"project": data, "notes": notes,
                           "import_notes": as_dicts(notes)})
    except Exception as e:
        return json.dumps({"error": str(e)})
    finally:
        shutil.rmtree(tmpdir, ignore_errors=True)


def xlsm_json(project_json: str, template: str | None = None) -> str:
    """Project JSON -> a filled Modbustemplate workbook, base64 for the download.

    `template` names the workbook to fill; the local GUI leaves it None and gets the
    one in the repository, while the browser build fetches it and writes it into
    Pyodide's filesystem first, so the bytes never cross this boundary.
    """
    from .xlsmexport import default_filename, export_xlsm
    data = json.loads(project_json)
    try:
        blob, notes = export_xlsm(data, template)
    except Exception as e:
        return json.dumps({"error": str(e)})
    return json.dumps({
        "notes": notes,
        "filename": default_filename(str(data.get("table", "")),
                                     str(data.get("plant", ""))),
        "b64": base64.b64encode(blob).decode("ascii"),
    })


def yaml_text(project_json: str) -> str:
    """Project JSON -> canonical YAML text (for client-side download)."""
    clean = to_yaml_dict(json.loads(project_json))
    load_project(clean)     # refuse to hand out YAML the loader would reject
    return SCHEMA_HEADER + yaml.safe_dump(clean, sort_keys=False, allow_unicode=True,
                                          width=100)


def parse_project(text: str) -> str:
    """YAML or JSON project text -> {"project": dict} or {"error": str}.
    Used by the browser build's Import-project button for .yaml files."""
    try:
        data = yaml.safe_load(text)
        load_project(to_yaml_dict(data))    # structural check with a clear message
    except Exception as e:
        return json.dumps({"error": str(e)})
    return json.dumps({"project": data})


def import_sql_json(text: str) -> str:
    """Generated SQL text -> {"project": dict, "notes": [str]} or {"error": str}.
    Backs the GUI's Import SQL button (both backends)."""
    from .sqlimport import import_sql
    try:
        data, notes = import_sql(text)
    except Exception as e:
        return json.dumps({"error": str(e)})
    from .notes import as_dicts
    return json.dumps({"project": data, "notes": notes,
                       "import_notes": as_dicts(notes)})
