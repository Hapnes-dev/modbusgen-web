"""Backend-neutral API: plain-dict/JSON-string functions used by both the local GUI
server (gui.py) and the Pyodide browser build (webui/pyodide-adapter.js).

All functions are stateless apart from the cached Tables instance; inputs and outputs
are JSON strings so the Pyodide boundary stays trivial.
"""
from __future__ import annotations

import base64
import json
from datetime import datetime


from .model import check_shape, load_project, unknown_keys
from .rules import apply_auto_groups, generate, synthesize_motherwords
from .sqlout import (change_report_csv, default_filename, preview_filename, preview_sql,
                     render_sql, report_filename, verify_filename,
                     verify_sql)
from .tables import Tables, project_tables
from .validate import scale_decimals_table, soft_checks_detailed, validate_detailed
from .yamlio import (HELP_BLOCK, OPTION_DEFAULTS, SCHEMA_HEADER_PUBLIC, SCHEMA_URL,
                     dump_yaml, parse_text, to_yaml_dict)

_tables: Tables | None = None


def tables() -> Tables:
    global _tables
    if _tables is None:
        _tables = Tables()
    return _tables


def source_rows(project) -> list[int | None]:
    """Map each validated point back to the row the caller sent.

    Validation runs after motherword synthesis, so the "point N" in an error
    counts rows the caller never wrote. Entry i is the 1-based index of that
    point in the incoming list, or None for a row this tool invented.
    """
    out: list[int | None] = []
    seen = 0
    for p in project.points:
        if p.synthesized:
            out.append(None)
        else:
            seen += 1
            out.append(seen)
    return out


def prepare(data: dict):
    """Load + auto-fill + synthesize + validate.
    Returns (project, findings, notes, point_rows).

    `findings` carry the code, the address, the advice and any suggestion; every caller
    that only wants sentences takes `.message`."""
    # On the raw payload, before to_yaml_dict prunes it: pruning drops a top-level
    # `subtract_one` or a nested `points` without a word, which is how a file that was
    # not a project used to reach load_project looking like an empty one.
    check_shape(data)
    project = load_project(to_yaml_dict(data))
    # the project's own datatype rows join the shipped ones here, once, so every step
    # below reads the same table
    t = project_tables(project, tables())
    apply_auto_groups(project, t)
    created = synthesize_motherwords(project, t)
    errors = validate_detailed(project, t)
    notes = [f"synthesized motherword for addr {p.addr} (group {p.group})"
             for p in created]
    # warnings stay inside `notes` as the "warning: …" strings every caller expects,
    # and travel structurally as well - a prefix is a poor way to tell a warning from
    # a note, and it is the only way there was
    warnings = soft_checks_detailed(project, t)
    notes.extend(w.message for w in warnings)
    return project, errors, notes, source_rows(project), warnings


def bootstrap_json() -> str:
    t = tables()
    return json.dumps({
        "projects": [],
        "project_times": {},     # no filesystem in the browser build; see gui.Api
        "project_meta": {},
        "defaults": OPTION_DEFAULTS,
        "datatypes": [vars(d) for d in t.datatypes.values()],
        "units": sorted(t.units),
        "scaling": list(t.scaling),
        "scale_decimals": scale_decimals_table(t),
        # no filesystem here, so a datatype cannot be promoted into the shared table:
        # the page hides that action rather than offering one that cannot work
        "writable_tables": False,
    })


def validate_json(project_json: str) -> str:
    try:
        project, errors, notes, rows, warns = prepare(json.loads(project_json))
    except Exception as e:
        return json.dumps({"errors": [str(e)], "notes": []})
    return json.dumps({"errors": [f.message for f in errors],
                       "findings": [f.as_dict() for f in errors],
                       "warnings": [w.as_dict() for w in warns],
                       "notes": notes, "point_rows": rows,
                       "points": len(project.points), "groups": len(project.groups)})


def built(data: dict, timestamp: str):
    """(project, result) for a project payload, prepared the way generate needs it.
    Used for the previous version of a list, which is generated but never written."""
    project = load_project(to_yaml_dict(data))
    t = project_tables(project, tables())
    apply_auto_groups(project, t)
    synthesize_motherwords(project, t)
    return project, generate(project, t, timestamp)


def plan_dict(plan) -> dict:
    """An update plan as the page shows it: the summary, the rows that go, the points
    re-addressed or changed in place, and what reading the previous version noted."""
    return {"summary": plan.summary(), "added": len(plan.added),
            "removed": [{"element_id": e, "driver_id": d, "alias": a}
                        for e, d, a in plan.removed_rows],
            "readdressed": plan.readdressed, "unchanged": plan.unchanged,
            "changed": plan.changed, "groups_gone": plan.groups_gone,
            "previous_table": plan.previous_table, "renamed_from": plan.renamed_from,
            "notes": [str(n) for n in plan.notes]}


def _previous_version(previous, project, result, ts):
    """The previous version the page sent, as an update plan. It is a project (the page
    read a .json/.yaml through /api/parse), or {"sql": text} - the script that put the
    list on the plant, read row by row rather than rebuilt into a project, which lost
    rows the import cannot resolve - or {"project": ...}; either envelope may carry
    "renamed_from" (review, 2026-10-24)."""
    from .sqlout import plan_update, previous_from_data, previous_from_sql
    renamed_from = None
    if isinstance(previous, dict) and "points" not in previous and \
            ("sql" in previous or "project" in previous):
        renamed_from = previous.get("renamed_from") or None
        if "sql" in previous:
            version = previous_from_sql(str(previous["sql"]), project.table, renamed_from)
        else:
            version = previous_from_data(previous["project"], tables(), ts)
    else:
        version = previous_from_data(previous, tables(), ts)
    return plan_update(version, project, result, renamed_from=renamed_from)


def generate_json(project_json: str, timestamp: str | None = None,
                  previous_json: str | None = None, schema: str = "") -> str:
    """Project -> the script, its verification SQL and preview SQL and, given the previous
    version of the list (previous_json: a project, or {"sql": ...} / {"project": ...} with
    an optional "renamed_from"), the rows that version had and this one has not and the
    change report. `schema` qualifies the verification and preview SQL's tables."""
    try:
        project, errors, notes, rows, warns = prepare(json.loads(project_json))
    except Exception as e:
        return json.dumps({"errors": [str(e)], "notes": []})
    if errors:
        return json.dumps({"errors": [f.message for f in errors],
                           "findings": [f.as_dict() for f in errors],
                           "warnings": [w.as_dict() for w in warns],
                           "notes": notes, "point_rows": rows})
    ts = timestamp or datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    # the merged tables, as prepare validated with: the shipped ones alone raised
    # KeyError on any datatype the project defines itself (review, 2026-10-23)
    result = generate(project, project_tables(project, tables()), ts)
    plan = None
    if previous_json:
        from .sqlout import PreviousMismatch
        try:
            plan = _previous_version(json.loads(previous_json), project, result, ts)
        except PreviousMismatch as e:
            # the page offers the rename when the tables differ; the rest it cannot fix
            text = str(e).replace("pass the old table name as renamed_from",
                                  "confirm the rename when the page asks")
            return json.dumps({"errors": [f"previous version: {text}"], "notes": notes,
                               "warnings": [w.as_dict() for w in warns],
                               "previous_mismatch": {"code": e.code, "table": e.table,
                                                     "previous_table": e.previous_table}})
        except Exception as e:
            return json.dumps({"errors": [f"previous version: {e}"], "notes": notes,
                               "warnings": [w.as_dict() for w in warns]})
    sql = render_sql(project, result, plan)
    try:
        encoded = sql.encode(project.options.encoding)
    except UnicodeEncodeError as e:
        # a "?" written in its place, without a word, is what the download used to hold
        return json.dumps({"errors": [unencodable_message(project, e)], "notes": notes,
                           "warnings": [w.as_dict() for w in warns]})
    check = verify_sql(project, result, schema)
    ahead = preview_sql(project, result, plan, schema)
    out = {
        "errors": [], "warnings": [w.as_dict() for w in warns],
        "notes": notes, "sql": sql,
        "points": len(project.points), "groups": len(project.groups),
        "filename": default_filename(project),
        "b64": base64.b64encode(encoded).decode("ascii"),
        "verify_sql": check,
        "verify_filename": verify_filename(project),
        # the plant's tables are latin1, and an element_id with an ø has to match there
        "verify_b64": base64.b64encode(
            check.encode(project.options.encoding, errors="replace")).decode("ascii"),
        # read-only, to run before the import: what the DELETEs and TRUNCATEs would take
        "preview_filename": preview_filename(project),
        "preview_b64": base64.b64encode(
            ahead.encode(project.options.encoding, errors="replace")).decode("ascii"),
    }
    if plan is not None:
        out["update"] = plan_dict(plan)
        out["changes_filename"] = report_filename(project)
        # UTF-8 with a BOM, so Excel shows the Norwegian letters of the aliases
        out["changes_b64"] = base64.b64encode(
            change_report_csv(plan).encode("utf-8-sig")).decode("ascii")
    return json.dumps(out)


def import_xlsm_json(b64: str, filename: str = "workbook.xlsm") -> str:
    """A Modbustemplate workbook (base64) -> {"project": dict, "notes": [str]}.

    Backs the GUI's Insert Excel button in both backends. The bytes are written to a
    temporary file because both importers take a path and derive a fallback table
    name from it; Pyodide's virtual filesystem serves that as well as a real one.
    Mirrors the CLI's fallback to the older template generation.
    """
    import shutil
    import tempfile
    from pathlib import Path

    tmpdir = tempfile.mkdtemp()
    try:
        path = Path(tmpdir) / (Path(filename).name or "workbook.xlsm")
        path.write_bytes(base64.b64decode(b64))
        from .importer import import_xlsm
        try:
            data, notes = import_xlsm(path)
        except ValueError as e:
            if "missing sheet" not in str(e):
                raise
            from .importer_old import import_old_xlsm
            data, notes = import_old_xlsm(path)
            notes.insert(0, "old-format workbook detected - reconstructed from its "
                            "generated columns")
        from .notes import as_dicts
        return json.dumps({"project": data, "notes": notes,
                           "import_notes": as_dicts(notes)})
    except Exception as e:
        return json.dumps({"error": str(e)})
    finally:
        shutil.rmtree(tmpdir, ignore_errors=True)


def xlsm_json(project_json: str, template: str | None = None) -> str:
    """Project JSON -> a filled Modbustemplate workbook, base64 for the download.

    `template` names the workbook to fill; the local GUI leaves it None and gets the
    one in the repository, while the browser build fetches it and writes it into
    Pyodide's filesystem first, so the bytes never cross this boundary.
    """
    from .xlsmexport import default_filename, export_xlsm
    data = json.loads(project_json)
    try:
        blob, notes = export_xlsm(data, template)
    except Exception as e:
        return json.dumps({"error": str(e)})
    return json.dumps({
        "notes": notes,
        "filename": default_filename(str(data.get("table", "")),
                                     str(data.get("plant", ""))),
        "b64": base64.b64encode(blob).decode("ascii"),
    })


def yaml_text(project_json: str) -> str:
    """Project JSON -> canonical YAML text (for client-side download)."""
    clean = to_yaml_dict(json.loads(project_json))
    load_project(clean)     # refuse to hand out YAML the loader would reject
    # the loader's own quoting rules: safe_dump left 1E2 bare, which YAML 1.2 reads back
    # as a number (review, 2026-10-24)
    return SCHEMA_HEADER_PUBLIC + dump_yaml(clean)


def canonical_json(project_json: str) -> str:
    """Project JSON -> the canonical, self-describing form the Export button downloads.

    Same pruning as the YAML path (to_yaml_dict): options at their defaults, empty
    blocks and per-point nulls disappear, and unknown keys a hand-written source
    carried are dropped - which also stops Export producing a file load_project would
    refuse. `$schema` comes first and is the published URL, so the file names its own
    contract to any editor or AI agent that receives it cold, and `_help` follows it with
    the briefing YAML would carry in comments (yamlio.HELP_BLOCK) - the rules that are
    expensive to get wrong and cannot be recovered from the data.

    Deliberately no load_project gate: Export is the save-your-work button, and a
    draft with no table name yet must still download.
    """
    data = to_yaml_dict(json.loads(project_json))
    return json.dumps({"project": {"$schema": SCHEMA_URL, "_help": HELP_BLOCK, **data}})


def parse_project(text: str, name: str = "") -> str:
    """YAML or JSON project text -> {"project": dict, "notes": [str]} or {"error": str}.
    Used by the browser build's Import-project button. `notes` names every key the page
    will leave out (model.unknown_keys), which used to vanish without a word."""
    try:
        data = parse_text(text, name)
        check_shape(data)                   # the whole container, before pruning
        load_project(to_yaml_dict(data))    # structural check with a clear message
    except Exception as e:
        return json.dumps({"error": str(e)})
    return json.dumps({"project": data, "notes": unknown_keys(data)})


def check_keys_json(text: str) -> str:
    """Project text -> {"notes": [str], "errors": [str]} (yamlio.key_report).

    `notes`: the keys the page will leave out on import. `errors`: one sentence per reason
    the raw text cannot be read as written - a key written twice in one mapping, a NaN or
    an Infinity, each with its key path and line - or the parser's message when it is not
    JSON or YAML at all; empty when the text reads cleanly. The page parses the file with
    JSON.parse, which keeps the last copy of a repeated key without a word, so this is
    where the repeat can still be seen.
    """
    from .yamlio import key_report
    try:
        return json.dumps(key_report(text))
    except Exception as e:                 # never leave the page without an answer
        return json.dumps({"notes": [], "errors": [str(e)]})


def unencodable_message(project, err: UnicodeEncodeError) -> str:
    """Which point and field holds the character the script's encoding cannot write."""
    ch = err.object[err.start:err.end]
    for i, p in enumerate(project.points, start=1):
        for field_name in ("text", "unit", "extra", "tag", "system_no", "menu", "range_min",
                           "range_max", "element_id", "group"):
            value = str(getattr(p, field_name) or "")
            if ch in value:
                return (f"point {i} (addr {p.addr}): {field_name} {value!r} holds {ch!r}, "
                        f"which {project.options.encoding} cannot write - replace it")
    return (f"{ch!r} cannot be written in {project.options.encoding} (in a group, state "
            f"text or system field) - replace it")


def import_sql_json(text: str) -> str:
    """Generated SQL text -> {"project": dict, "notes": [str]} or {"error": str}.
    Backs the GUI's Import SQL button (both backends)."""
    from .sqlimport import import_sql
    try:
        data, notes = import_sql(text)
    except Exception as e:
        return json.dumps({"error": str(e)})
    from .notes import as_dicts
    return json.dumps({"project": data, "notes": notes,
                       "import_notes": as_dicts(notes)})
