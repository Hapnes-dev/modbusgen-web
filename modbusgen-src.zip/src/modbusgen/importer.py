"""Import a filled Modbustemplate workbook (the original Excel tool) into a YAML
project dict.

Reads the Work input columns A-AE, the Main_Setup / Protocol_Spesific_Setup toggles,
the active Groups_Setup table and the JSON Setup state texts - the cell map is
docs/01-workbook-structure.md and docs/02-inputs.md. The generated output columns
(BA-CL) and status columns (Y/Z) are ignored: modbusgen re-derives them.

Requires openpyxl (pip install openpyxl).
"""
from __future__ import annotations

import re
from pathlib import Path

# Work sheet input columns (1-based indexes; see docs/01)
COL = {"group": 1, "element_id": 3, "datatype": 4, "addr": 5, "bit": 6,
       "system_no": 13, "tag": 14, "extra": 15, "text": 16, "alarm": 18,
       "unit": 19, "scale": 20, "rw": 21, "online": 22, "active": 23,
       "no_group": 24, "menu": 27, "decimals": 28, "range_min": 29,
       "range_max": 30, "statetext": 31}
ROW_CAP = 5000          # the Excel macros scan to row 5000 (docs/08 item 22)

REQUIRED_SHEETS = ["Work", "Main_Setup", "Protocol_Spesific_Setup", "Groups_Setup",
                   "JSON Setup"]


def _b(v) -> bool:
    return v is True


def _s(v) -> str:
    """Cell value as string; integral floats collapse (360.0 -> '360')."""
    if v is None:
        return ""
    if isinstance(v, float) and v.is_integer():
        return str(int(v))
    return str(v).strip()


def _int(v):
    try:
        return int(float(v))
    except (TypeError, ValueError):
        return None


def import_xlsm(path: Path) -> tuple[dict, list[str]]:
    """Returns (project dict, notes). Raises ValueError on a workbook that does not
    look like a Modbustemplate."""
    try:
        import openpyxl
    except ImportError as e:
        raise ValueError("openpyxl is required for import: pip install openpyxl") from e

    wb = openpyxl.load_workbook(path, data_only=True, read_only=True)
    missing = [s for s in REQUIRED_SHEETS if s not in wb.sheetnames]
    if missing:
        raise ValueError(f"not a Modbustemplate workbook - missing sheet(s): "
                         f"{', '.join(missing)}")
    notes: list[str] = []
    main = wb["Main_Setup"]
    prot = wb["Protocol_Spesific_Setup"]

    # --- header + options -------------------------------------------------
    table = _s(main["B19"].value).lower()
    if not re.fullmatch(r"[a-z0-9_]+", table or ""):
        fallback = re.sub(r"[^a-z0-9_]+", "_", Path(path).stem.lower()).strip("_")
        notes.append(f"Main_Setup!B19 table name {'empty' if not table else 'invalid'} "
                     f"- using '{fallback}'")
        table = fallback
    plant = _s(main["B21"].value)
    if not plant:
        notes.append("Main_Setup!B21 plant number empty - set it before generating")

    options = {
        "subtract_one": _b(prot["B18"].value),
        "truncate": _b(main["B23"].value),
        "create_tables": _b(main["B25"].value),
        "use_tag": _b(main["B27"].value),
        "use_system_no": _b(main["B31"].value),
        "use_extra": _b(main["B35"].value),
        "force_active": _b(prot["B38"].value),
        "include_minmax": _b(prot["B42"].value),
        "auto_groups": _b(prot["B22"].value),
        "alarms_to_alm": _b(prot["B26"].value),
        "exclude_motherwords_from_groups": _b(prot["B30"].value),
        "statetext_only_rw": _b(prot["B58"].value),
        "statetext_in_alias": _b(prot["B62"].value),
        "use_json": _b(prot["B54"].value),
        "override_decimal": _b(prot["B46"].value),
    }
    if _b(main["B14"].value) and _s(main["B13"].value):
        options["reserve_text"] = _s(main["B13"].value)
    else:
        options["reserve_text"] = ""        # rule disabled in the workbook

    # --- system block (only when the workbook enabled either iw_sys section) ----
    system = None
    if _b(main["B42"].value) or _b(main["B45"].value):
        system = {
            "units": _b(main["B42"].value),
            "settings": _b(main["B45"].value),
            "unit_id": _s(main["B48"].value),
            "unit_name": _s(main["B51"].value),
            "reg_type": _s(main["B54"].value),
            "order_no": _s(main["B57"].value),
            "owner": _s(main["B60"].value),
            "driver_addr": _s(main["B63"].value),
            "driver_addr_prefix": "1_" if _b(main["C63"].value) else "0_",
            "comm": {
                "mode": "rtu" if _b(main["B10"].value) else "tcp",
                "ip": _s(main["B69"].value),
                "com_port": _s(main["B66"].value),
                "baudrate": 9600 if _b(main["B72"].value) else 19200,
                "parity": _s(main["E75"].value) or "even",
                "stop_bits": 1 if _b(main["B78"].value) else 2,
            },
        }

    # --- groups (the table that was active in the workbook) ----------------
    gs = wb["Groups_Setup"]
    groups: dict[str, dict] = {}
    ref_col, alias_col, order_col = (13, 14, 12) if options["auto_groups"] else (4, 5, 3)
    for row in gs.iter_rows(min_row=4, max_row=gs.max_row):
        ref = _s(row[ref_col - 1].value) if len(row) >= ref_col else ""
        if not ref:
            continue
        alias = _s(row[alias_col - 1].value) if len(row) >= alias_col else ""
        order = _int(row[order_col - 1].value) if len(row) >= order_col else None
        groups[ref] = {"alias": alias, "order": order} if order else alias

    # --- state texts -------------------------------------------------------
    js = wb["JSON Setup"]
    rows = list(js.iter_rows(min_row=1, max_row=min(js.max_row, 1000),
                             max_col=105, values_only=True))
    numbers = {}
    if len(rows) >= 2:
        for col in range(1, 101):           # columns B..CW
            n = _int(rows[1][col]) if col < len(rows[1]) else None
            if n is not None:
                numbers[col] = n
    statetexts: dict[int, dict[int, str]] = {}
    for r in rows[2:]:
        sid = _int(r[0])
        if sid is None:
            continue
        states = {numbers[c]: _s(r[c]) for c in numbers
                  if c < len(r) and _s(r[c]) != ""}
        if not states and len(r) >= 105 and _s(r[104]):
            # word cells cleared but the generated plain text (column DA) survives -
            # recover "1=Kjøling 2=Stopp Kjøl ..." from it
            states = {int(n): w for n, w in
                      re.findall(r"(\d+)=(.*?)(?=\s+\d+=|\s*$)", _s(r[104]))}
            if states:
                notes.append(f"state list {sid}: recovered from plain-text column DA "
                             f"(input word cells were empty)")
        if states:
            statetexts[sid] = states

    # --- points ------------------------------------------------------------
    work = wb["Work"]
    points: list[dict] = []
    junk = 0
    hand_patched_menu = 0
    for row in work.iter_rows(min_row=3, max_row=min(work.max_row, ROW_CAP),
                              max_col=57, values_only=True):
        get = lambda name: row[COL[name] - 1] if len(row) >= COL[name] else None
        datatype, addr = _s(get("datatype")), _int(get("addr"))
        if not datatype and addr is None and not _s(get("text")):
            continue                        # empty row
        if not datatype or addr is None:
            junk += 1                       # e.g. the leftover D-only rows (docs/08 item 8)
            continue
        p: dict = {"group": _s(get("group")), "datatype": datatype, "addr": addr,
                   "text": _s(get("text"))}
        if (bit := _int(get("bit"))) is not None:
            p["bit"] = bit
        elif re.fullmatch(r"\d+#\d+", _s(get("bit"))):
            p["bit"] = _s(get("bit"))            # legacy nibble syntax "start#length"
        elif _s(get("bit")):
            notes.append(f"addr {addr}: unrecognized bit value "
                         f"{_s(get('bit'))!r} - dropped")
        if not _s(get("menu")) and len(row) >= 57 and _s(row[56]):
            hand_patched_menu += 1               # menu typed into generated column BE
        for name in ("element_id", "system_no", "tag", "extra", "unit", "scale", "menu"):
            if (v := _s(get(name))):
                p[name] = v
        if (alarm := _s(get("alarm")).upper()):
            p["alarm"] = alarm
        rw = _s(get("rw")).lower()
        p["rw"] = rw if rw else "r"
        if not rw:
            notes.append(f"addr {addr}: Read/Write column empty - defaulted to 'r'")
        if _int(get("online")) == 1:
            p["online"] = True
        if (active := _int(get("active"))) in (0, 1):
            p["active"] = active
        if _s(get("no_group")).lower() == "x":
            p["no_group"] = True
        if (dec := _int(get("decimals"))) is not None:
            if dec in (0, 1, 2, 3):
                p["decimals"] = dec
            else:
                notes.append(f"addr {addr}: decimals {dec} outside 0..3 - dropped")
        for name in ("range_min", "range_max"):
            if (v := _s(get(name))):
                p[name] = v
        if (st := _int(get("statetext"))) is not None:
            p["statetext"] = st
        points.append(p)
    wb.close()
    if junk:
        notes.append(f"skipped {junk} incomplete row(s) with only partial data "
                     f"(datatype or address missing)")
    if hand_patched_menu:
        notes.append(f"{hand_patched_menu} row(s) have menu text only in the generated "
                     f"column (BE) - hand-patched after generation; copy the values "
                     f"into the menu field if they should survive regeneration")

    data = {"table": table, "plant": plant, "options": options, "system": system,
            "groups": groups, "statetexts": statetexts, "points": points}
    return data, notes
