"""Import a filled Modbustemplate workbook (the original Excel tool) into a YAML
project dict.

Reads the Work input columns A-AE, the Main_Setup / Protocol_Spesific_Setup toggles,
the Main_Setup device and driver cells, the active Groups_Setup table and the JSON
Setup state texts - the cell map is
docs/01-workbook-structure.md and docs/02-inputs.md. The generated output columns
(BA-CL) and status columns (Y/Z) are ignored: modbusgen re-derives them.

Requires openpyxl (pip install openpyxl).
"""
from __future__ import annotations

import re
from pathlib import Path

from .notes import ACTION, DROPPED, INFO, REPAIRED, Note, where
from .tables import default_tables, unknown_datatype_notes

# Work sheet input columns (1-based indexes; see docs/01)
COL = {"group": 1, "element_id": 3, "datatype": 4, "addr": 5, "bit": 6,
       "system_no": 13, "tag": 14, "extra": 15, "text": 16, "alarm": 18,
       "unit": 19, "scale": 20, "rw": 21, "online": 22, "active": 23,
       "no_group": 24, "menu": 27, "decimals": 28, "range_min": 29,
       "range_max": 30, "statetext": 31}
ROW_CAP = 5000          # the Excel macros scan to row 5000 (docs/08 item 22)

# Modbus_Variables!Z:AI, the workbook's own datatype table (docs/02). Read only for the
# datatypes the points use and the shipped table does not have.
VARIABLES_SHEET = "Modbus_Variables"
VARIABLES_FIRST_ROW = 3
VARIABLES_LAST_ROW = 100
VARIABLES_COLS = (26, 27, 28, 29, 30, 31, 32, 33, 34, 35)
VARIABLES_FIELDS = ("read_func", "write_func", "raw_type", "read_swap", "write_swap",
                    "application", "parameter_type", "rw_hint", "default_group")

REQUIRED_SHEETS = ["Work", "Main_Setup", "Protocol_Spesific_Setup", "Groups_Setup",
                   "JSON Setup"]

# The Main_Setup cells a person types a device or driver into (docs/02). The template
# ships them empty, apart from the address, which it ships as 1. The checkbox cells -
# prefix, RTU flag, baud rate, parity, stop bit - always read as something, even in a
# workbook nobody touched, so they travel with a typed value rather than count as one.
TYPED_UNIT_CELLS = {"unit_id": "B48", "unit_name": "B51", "reg_type": "B54",
                    "order_no": "B57", "owner": "B60"}
TYPED_COMM_CELLS = {"com_port": "B66", "ip": "B69"}
TEMPLATE_DRIVER_ADDR = ("", "1")


def _b(v) -> bool:
    return v is True


def _s(v) -> str:
    """Cell value as string; integral floats collapse (360.0 -> '360')."""
    if v is None:
        return ""
    if isinstance(v, float) and v.is_integer():
        return str(int(v))
    return str(v).strip()


def _int(v):
    try:
        return int(float(v))
    except (TypeError, ValueError):
        return None


def _workbook_datatypes(wb, used: set[str]) -> dict[str, dict]:
    """Datatype rows this workbook defines that modbusgen's table does not have.

    A delivery is evidence of what was shipped, not of what is correct, so these are
    carried across verbatim and left for validation to comment on. Only rows the points
    actually use are taken: a workbook defines 79 of them, and copying all of them into
    every imported project would bury the one row that matters.
    """
    if VARIABLES_SHEET not in wb.sheetnames:
        return {}
    shipped = default_tables().datatypes
    ws = wb[VARIABLES_SHEET]
    found: dict[str, dict] = {}
    for row in range(VARIABLES_FIRST_ROW, VARIABLES_LAST_ROW + 1):
        name = ws.cell(row=row, column=VARIABLES_COLS[0]).value
        if name in (None, ""):
            continue
        name = str(name).strip()
        if name.casefold() not in used or name in shipped or name in found:
            continue
        values = [ws.cell(row=row, column=c).value for c in VARIABLES_COLS[1:]]
        found[name] = {f: ("" if v is None else str(v).strip())
                       for f, v in zip(VARIABLES_FIELDS, values)}
    return found


def import_xlsm(path: Path) -> tuple[dict, list[str]]:
    """Returns (project dict, notes). Raises ValueError on a workbook that does not
    look like a Modbustemplate."""
    try:
        import openpyxl
    except ImportError as e:
        raise ValueError("openpyxl is required for import: pip install openpyxl") from e

    wb = openpyxl.load_workbook(path, data_only=True, read_only=True)
    missing = [s for s in REQUIRED_SHEETS if s not in wb.sheetnames]
    if missing:
        raise ValueError(f"not a Modbustemplate workbook - missing sheet(s): "
                         f"{', '.join(missing)}")
    notes: list[str] = []
    main = wb["Main_Setup"]
    prot = wb["Protocol_Spesific_Setup"]

    # --- header + options -------------------------------------------------
    table = _s(main["B19"].value).lower()
    if not re.fullmatch(r"[a-z0-9_]+", table or ""):
        fallback = re.sub(r"[^a-z0-9_]+", "_", Path(path).stem.lower()).strip("_")
        notes.append(Note(
            f"Main_Setup!B19 table name {'empty' if not table else 'invalid'} "
            f"- using '{fallback}'", code="table-name-derived", kind=REPAIRED,
            advice="Check the table name against the plant's existing iw_par_ tables "
                   "before generating; it is derived from the file name here."))
        table = fallback
    plant = _s(main["B21"].value)
    if not plant:
        notes.append(Note(
            "Main_Setup!B21 plant number empty - set it before generating",
            code="plant-number-missing", kind=ACTION,
            advice="Set the plant number before generating. It names the output file "
                   "and cannot be recovered from the workbook."))

    options = {
        "subtract_one": _b(prot["B18"].value),
        "truncate": _b(main["B23"].value),
        "create_tables": _b(main["B25"].value),
        "use_tag": _b(main["B27"].value),
        "use_system_no": _b(main["B31"].value),
        "use_extra": _b(main["B35"].value),
        "force_active": _b(prot["B38"].value),
        "include_minmax": _b(prot["B42"].value),
        "auto_groups": _b(prot["B22"].value),
        "alarms_to_alm": _b(prot["B26"].value),
        "exclude_motherwords_from_groups": _b(prot["B30"].value),
        "statetext_only_rw": _b(prot["B58"].value),
        "statetext_in_alias": _b(prot["B62"].value),
        "use_json": _b(prot["B54"].value),
        "override_decimal": _b(prot["B46"].value),
    }
    if _b(main["B14"].value) and _s(main["B13"].value):
        options["reserve_text"] = _s(main["B13"].value)
    else:
        options["reserve_text"] = ""        # rule disabled in the workbook

    # --- system block ---------------------------------------------------------
    # B42/B45 decide whether the Excel tool *writes* the iw_sys blocks, not whether the
    # workbook holds a device and a driver. A list prepared for a plant that already has
    # both carries them with both boxes off - plant 2794's EKE 100 workbook, 2026-09-30,
    # whose unit, owner, address and COM port were dropped here without a word. Keep
    # whatever was typed in, with the two switches as the workbook has them, which is
    # the rule the GUI's System card follows; only a workbook with nothing typed into
    # those cells has no system block.
    system = {
        "units": _b(main["B42"].value),
        "settings": _b(main["B45"].value),
        "unit_id": _s(main["B48"].value),
        "unit_name": _s(main["B51"].value),
        "reg_type": _s(main["B54"].value),
        "order_no": _s(main["B57"].value),
        "owner": _s(main["B60"].value),
        "driver_addr": _s(main["B63"].value),
        "driver_addr_prefix": "1_" if _b(main["C63"].value) else "0_",
        "comm": {
            "mode": "rtu" if _b(main["B10"].value) else "tcp",
            "ip": _s(main["B69"].value),
            "com_port": _s(main["B66"].value),
            "baudrate": 9600 if _b(main["B72"].value) else 19200,
            "parity": _s(main["E75"].value) or "even",
            "stop_bits": 1 if _b(main["B78"].value) else 2,
        },
    }
    if not (system["units"] or system["settings"]):
        typed = ([f"{name} ({cell})" for name, cell in TYPED_UNIT_CELLS.items()
                  if system[name]]
                 + (["driver_addr (B63)"]
                    if system["driver_addr"] not in TEMPLATE_DRIVER_ADDR else [])
                 + [f"comm.{name} ({cell})" for name, cell in TYPED_COMM_CELLS.items()
                    if system["comm"][name]])
        if not typed:
            system = None
        else:
            notes.append(Note(
                f"Main_Setup!B42 and B45 are off: the device and driver the workbook "
                f"holds - {', '.join(typed)} - were imported into system, but the SQL "
                f"registers neither until system.units or system.settings is on",
                code="system-sections-off", kind=INFO,
                advice="Switch on system.units to register the device and "
                       "system.settings to register the driver, if the plant does not "
                       "have them yet. Leave both off when it does: that is what the "
                       "workbook was set to."))

    # --- groups (the table that was active in the workbook) ----------------
    gs = wb["Groups_Setup"]
    groups: dict[str, dict] = {}
    ref_col, alias_col, order_col = (13, 14, 12) if options["auto_groups"] else (4, 5, 3)
    for row in gs.iter_rows(min_row=4, max_row=gs.max_row):
        ref = _s(row[ref_col - 1].value) if len(row) >= ref_col else ""
        if not ref:
            continue
        alias = _s(row[alias_col - 1].value) if len(row) >= alias_col else ""
        order = _int(row[order_col - 1].value) if len(row) >= order_col else None
        groups[ref] = {"alias": alias, "order": order} if order else alias

    # --- state texts -------------------------------------------------------
    js = wb["JSON Setup"]
    rows = list(js.iter_rows(min_row=1, max_row=min(js.max_row, 1000),
                             max_col=105, values_only=True))
    numbers = {}
    if len(rows) >= 2:
        for col in range(1, 101):           # columns B..CW
            n = _int(rows[1][col]) if col < len(rows[1]) else None
            if n is not None:
                numbers[col] = n
    statetexts: dict[int, dict[int, str]] = {}
    for r in rows[2:]:
        sid = _int(r[0])
        if sid is None:
            continue
        states = {numbers[c]: _s(r[c]) for c in numbers
                  if c < len(r) and _s(r[c]) != ""}
        if not states and len(r) >= 105 and _s(r[104]):
            # word cells cleared but the generated plain text (column DA) survives -
            # recover "1=Kjøling 2=Stopp Kjøl ..." from it
            states = {int(n): w for n, w in
                      re.findall(r"(\d+)=(.*?)(?=\s+\d+=|\s*$)", _s(r[104]))}
            if states:
                notes.append(Note(
                    f"state list {sid}: recovered from plain-text column DA "
                    f"(input word cells were empty)", code="statetext-recovered",
                    kind=REPAIRED,
                    advice="The words were read back from the generated column, so "
                           "check their spelling and order against the device document."))
        if states:
            statetexts[sid] = states

    # --- points ------------------------------------------------------------
    work = wb["Work"]
    points: list[dict] = []
    junk = 0
    bad_bits: list[int] = []
    rw_defaulted: list[int] = []
    bad_decimals: list[int] = []
    hand_patched_menu = 0
    for row in work.iter_rows(min_row=3, max_row=min(work.max_row, ROW_CAP),
                              max_col=57, values_only=True):
        get = lambda name: row[COL[name] - 1] if len(row) >= COL[name] else None
        datatype, addr = _s(get("datatype")), _int(get("addr"))
        if not datatype and addr is None and not _s(get("text")):
            continue                        # empty row
        if not datatype or addr is None:
            junk += 1                       # e.g. the leftover D-only rows (docs/08 item 8)
            continue
        p: dict = {"group": _s(get("group")), "datatype": datatype, "addr": addr,
                   "text": _s(get("text"))}
        if (bit := _int(get("bit"))) is not None:
            p["bit"] = bit
        elif re.fullmatch(r"\d+#\d+", _s(get("bit"))):
            p["bit"] = _s(get("bit"))            # legacy nibble syntax "start#length"
        elif _s(get("bit")):
            bad_bits.append(addr)
        if not _s(get("menu")) and len(row) >= 57 and _s(row[56]):
            hand_patched_menu += 1               # menu typed into generated column BE
        for name in ("element_id", "system_no", "tag", "extra", "unit", "scale", "menu"):
            if (v := _s(get(name))):
                p[name] = v
        if (alarm := _s(get("alarm")).upper()):
            p["alarm"] = alarm
        rw = _s(get("rw")).lower()
        p["rw"] = rw if rw else "r"
        if not rw:
            rw_defaulted.append(addr)
        if _int(get("online")) == 1:
            p["online"] = True
        if (active := _int(get("active"))) in (0, 1):
            p["active"] = active
        if _s(get("no_group")).lower() == "x":
            p["no_group"] = True
        if (dec := _int(get("decimals"))) is not None:
            if dec in (0, 1, 2, 3):
                p["decimals"] = dec
            else:
                bad_decimals.append(addr)
        for name in ("range_min", "range_max"):
            if (v := _s(get(name))):
                p[name] = v
        if (st := _int(get("statetext"))) is not None:
            p["statetext"] = st
        points.append(p)
    # read the workbook's own datatype table before closing it: a row it defines and
    # the shipped table does not is the difference between a project that validates
    # and one that cannot
    used = {str(p.get("datatype", "")).strip().casefold() for p in points}
    carried = _workbook_datatypes(wb, used - {""})
    wb.close()
    # one note per family, not one per row: sixty blank Read/Write cells used to be
    # sixty notes saying one thing, and a real delivery is 1 619 points
    if rw_defaulted:
        notes.append(Note(
            f"{len(rw_defaulted)} row(s) had an empty Read/Write column - defaulted to "
            f"'r' ({where(rw_defaulted)})", code="rw-defaulted", kind=REPAIRED,
            count=len(rw_defaulted), addrs=tuple(rw_defaulted),
            advice="Check any row that should be writable: the workbook left the column "
                   "blank and read-only is the safe reading of that, not a known one."))
    if bad_bits:
        notes.append(Note(
            f"{len(bad_bits)} row(s) had an unrecognized bit value - dropped "
            f"({where(bad_bits)})", code="bit-value-dropped", kind=DROPPED,
            count=len(bad_bits), addrs=tuple(bad_bits),
            advice="Those rows lost their bit and now read the whole word. Re-author "
                   "each from the device document: a bit is 0-31, or the nibble form "
                   "start#length."))
    if bad_decimals:
        notes.append(Note(
            f"{len(bad_decimals)} row(s) had decimals outside 0..3 - dropped "
            f"({where(bad_decimals)})", code="decimals-dropped", kind=DROPPED,
            count=len(bad_decimals), addrs=tuple(bad_decimals),
            advice="The display format is empty on those rows. Set decimals 0-3 to "
                   "match the scaling, or leave it empty deliberately."))
    if junk:
        notes.append(Note(
            f"skipped {junk} incomplete row(s) with only partial data "
            f"(datatype or address missing)", code="rows-skipped", kind=DROPPED,
            count=junk,
            advice="Real deliveries carry hundreds of these as fill-down residue, and "
                   "skipping them is right. Reconcile the count against the source "
                   "before claiming the list is complete (docs/11 coverage accounting)."))
    if hand_patched_menu:
        notes.append(Note(
            f"{hand_patched_menu} row(s) have menu text only in the generated "
            f"column (BE) - hand-patched after generation; copy the values "
            f"into the menu field if they should survive regeneration",
            code="menu-hand-patched", kind=ACTION, count=hand_patched_menu,
            advice="Copy those values into the menu field. Regenerating without them "
                   "silently drops text somebody typed into the delivered workbook."))

    if carried:
        notes.append(Note(
            f"carried {len(carried)} datatype row(s) from {VARIABLES_SHEET} "
            f"that data/tables/datatypes.csv does not have: "
            f"{', '.join(sorted(carried))}. They travel in the project's own "
            f"`datatypes` block.", code="datatypes-carried", kind=INFO,
            count=len(carried),
            advice="Check each against docs/15 before shipping: the workbook defined "
                   "them, which is evidence of what was delivered rather than of what "
                   "the driver accepts."))
    notes += unknown_datatype_notes(
        [p for p in points if str(p.get("datatype", "")).strip() not in carried])

    data = {"table": table, "plant": plant, "options": options, "system": system,
            "groups": groups, "statetexts": statetexts, "datatypes": carried,
            "points": points}
    return data, notes
