"""Canonical YAML serialization of a project dict (shared by GUI save and the
xlsm importer): defaults pruned, keys in schema order, schema header line for
editor support."""
from __future__ import annotations

import json
import math
import re
from dataclasses import fields as dc_fields
from pathlib import Path

import yaml

from .model import SCHEMA_URL, Options, Point, unknown_keys

OPTION_DEFAULTS = {f.name: getattr(Options(), f.name) for f in dc_fields(Options)}

_STR_TAG = "tag:yaml.org,2002:str"
_FLOAT_TAG = "tag:yaml.org,2002:float"
_MERGE_TAG = "tag:yaml.org,2002:merge"


# --- text a parser reads without a word of complaint, and must not --------------------
# JSON and YAML both let a mapping repeat a key, and both parsers keep the last copy and
# drop the others silently: two "points" arrays loaded as the second one alone (`OK - 1
# point(s)` for a file holding three), and a repeated statetexts "1" shipped the second
# list's words. json.loads also takes NaN and Infinity, which no project field can carry -
# `"view_order": Infinity` crashed validate and a group `"order": Infinity` crashed the
# load (review, 2026-10-24). Every route that reads a project file's own text goes through
# parse_text below, so both are refused there, each problem named by its key path and
# line; the page, whose JSON.parse has already collapsed a repeat by the time it sends
# the project on, learns of it from key_report on the raw text.

class _TextProblems:
    """What the two parse errors share: the list of problems, one sentence each."""
    problems: list[str]

    def describe(self) -> str:
        if len(self.problems) == 1:
            return self.problems[0]
        return (f"{len(self.problems)} problems in the project text, nothing was loaded:\n"
                + "\n".join(f"  - {p}" for p in self.problems))


class JsonTextError(_TextProblems, json.JSONDecodeError):
    """A JSON project text that parses and still cannot be read safely.

    A JSONDecodeError, so every caller that already reports invalid JSON - the CLI,
    compare, the web routes - reports this too, with the problems as its message.
    """

    def __init__(self, problems: list[str], doc: str, pos: int):
        json.JSONDecodeError.__init__(self, problems[0], doc, pos)
        self.problems = problems

    def __str__(self) -> str:
        return self.describe()

    def __reduce__(self):
        return self.__class__, (self.problems, self.doc, self.pos)


class YamlTextError(_TextProblems, yaml.YAMLError):
    """The YAML twin of JsonTextError: a YAMLError, for the same reason."""

    def __init__(self, problems: list[str]):
        yaml.YAMLError.__init__(self, problems)
        self.problems = problems

    def __str__(self) -> str:
        return self.describe()


class _Item(int):
    """A position in a list, told apart from a mapping key that happens to be a number -
    YAML's `statetexts: {1: ...}` is a key, points[1] is an item."""


def _key_path(path: list) -> str:
    """points[2].text - the loader's own spelling: list items counted from 1."""
    out = ""
    for part in path:
        if isinstance(part, _Item):
            out += f"[{part}]"
        else:
            text = str(part)
            if not text or re.search(r"[\s.\[\]\"]", text):
                text = json.dumps(text, ensure_ascii=False)
            out += f".{text}" if out else text
    return out


def _repeated(key, path: list, first: tuple[int, int], again: tuple[int, int]) -> str:
    """first and again are (line, column), both counted from 1."""
    where = f"in {_key_path(path)}" if path else "at the top level"
    places = (f"line {first[0]}, columns {first[1]} and {again[1]}" if first[0] == again[0]
              else f"lines {first[0]} and {again[0]}")
    return (f"{json.dumps(str(key), ensure_ascii=False)} is written twice {where} "
            f"({places}) - a parser keeps only the last copy and drops the other without "
            f"a word, so write it once")


def _not_finite(path: list, spelled: str, line: int) -> str:
    return (f"{_key_path(path) or 'the project'} is {spelled} (line {line}) - NaN and "
            f"Infinity are not values a project can carry; write the number the document "
            f"prints, or leave the field out")


_JSON_WS = re.compile(r"[ \t\n\r]*")
_JSON_NUMBER = re.compile(r"-?(?:0|[1-9][0-9]*)(\.[0-9]+)?([eE][-+]?[0-9]+)?")


def _json_problems(text: str) -> list[tuple[int, str]]:
    """(position, sentence) for every repeated key and every NaN or Infinity in a text
    json.loads has already accepted. Only run once the fast parse below has flagged
    something, so it may assume the text is well formed and keep track of positions,
    which the C scanner cannot report."""
    from json.decoder import scanstring

    found: list[tuple[int, str]] = []

    def line(pos: int) -> int:
        return text.count("\n", 0, pos) + 1

    def place(pos: int) -> tuple[int, int]:
        return line(pos), pos - text.rfind("\n", 0, pos)

    def skip(i: int) -> int:
        return _JSON_WS.match(text, i).end()

    def value(i: int, path: list) -> int:
        i = skip(i)
        ch = text[i:i + 1]
        if ch == "{":
            i = skip(i + 1)
            if text.startswith("}", i):
                return i + 1
            seen: dict[str, int] = {}
            while True:
                start = i
                key, i = scanstring(text, i + 1)
                if key in seen:
                    found.append((start, _repeated(key, path, place(seen[key]),
                                                   place(start))))
                else:
                    seen[key] = start
                i = skip(skip(i) + 1)                  # past the colon
                i = skip(value(i, path + [key]))
                if text.startswith(",", i):
                    i = skip(i + 1)
                    continue
                return i + 1
        if ch == "[":
            i = skip(i + 1)
            if text.startswith("]", i):
                return i + 1
            n = 0
            while True:
                n += 1
                i = skip(value(i, path + [_Item(n)]))
                if text.startswith(",", i):
                    i += 1
                    continue
                return i + 1
        if ch == '"':
            return scanstring(text, i + 1)[1]
        for word in ("NaN", "-Infinity", "Infinity"):
            if text.startswith(word, i):
                found.append((i, _not_finite(path, word, line(i))))
                return i + len(word)
        for word in ("true", "false", "null"):
            if text.startswith(word, i):
                return i + len(word)
        m = _JSON_NUMBER.match(text, i)
        if (m.group(1) or m.group(2)) and not math.isfinite(float(m.group(0))):
            found.append((i, _not_finite(path, m.group(0), line(i))))
        return m.end()

    value(0, [])
    return found


def _strict_json(text: str):
    """json.loads, refusing a repeated key, NaN and Infinity (JsonTextError).

    The hooks only notice; the position-keeping second pass runs only when one did, so a
    clean file pays about a third over plain json.loads (10 ms against 7 on a 6 000-point
    list) and nothing more.
    """
    flagged: list[bool] = []

    def pairs(items):
        mapping = dict(items)
        if len(mapping) != len(items):
            flagged.append(True)
        return mapping

    def constant(_name):
        flagged.append(True)
        return None

    def number(spelled):
        v = float(spelled)
        if not math.isfinite(v):
            flagged.append(True)
        return v

    data = json.loads(text, object_pairs_hook=pairs, parse_constant=constant,
                      parse_float=number)
    if flagged:
        try:
            found = _json_problems(text)
        except RecursionError:          # nested deeper than a project ever is
            found = []
        if not found:
            found = [(0, "the project text repeats a key or carries NaN or Infinity - "
                         "write each key once and every number as the document prints it")]
        raise JsonTextError([sentence for _pos, sentence in found], text, found[0][0])
    return data


def _yaml_problems(loader, root) -> list[str]:
    """Every repeated key and every non-finite number in a composed YAML document, by
    line. Keys are compared as the constructor will build them, so `1:` and `+1:` are one
    key, exactly as they are in the dict PyYAML would return."""
    from yaml.nodes import MappingNode, ScalarNode, SequenceNode

    found: list[tuple[int, str]] = []
    visited: set[int] = set()
    stack = [(root, [])]
    while stack:
        node, path = stack.pop()
        if id(node) in visited:          # an alias, or a structure that refers to itself
            continue
        visited.add(id(node))
        if isinstance(node, MappingNode):
            seen: dict = {}
            for key_node, value_node in node.value:
                if key_node.tag == _MERGE_TAG:
                    stack.append((value_node, path))
                    continue
                key = None
                if isinstance(key_node, ScalarNode):
                    key = loader.construct_object(key_node)
                    try:
                        hash(key)
                    except TypeError:
                        key = None
                mark = key_node.start_mark
                here = (mark.line + 1, mark.column + 1)
                if key is not None:
                    if key in seen:
                        found.append((here[0], _repeated(key, path, seen[key], here)))
                    else:
                        seen[key] = here
                stack.append((value_node, path + ["?" if key is None else key]))
        elif isinstance(node, SequenceNode):
            stack.extend((item, path + [_Item(n)])
                         for n, item in enumerate(node.value, start=1))
        elif node.tag == _FLOAT_TAG:
            v = loader.construct_object(node)
            if isinstance(v, float) and not math.isfinite(v):
                line = node.start_mark.line + 1
                found.append((line, _not_finite(path, str(node.value), line)))
    return [sentence for _line, sentence in sorted(found, key=lambda f: f[0])]


def _yaml12_loader():
    """A safe YAML loader that reads plain scalars the way YAML 1.2 and JSON do.

    PyYAML follows YAML 1.1, where unquoted Off/On/No/Yes are booleans, 0010 is octal 8,
    360_02 is the number 36002 and 2026-10-23 is a date. So state words Off/On reached the
    plant as "False"/"True", a table named 360_02 became iw_par_36002_param, and
    `addr: 0010` read register 8 (review, 2026-10-23). Here only true/false are booleans,
    a number is plain decimal, and everything else stays the text it looks like.
    """
    base = getattr(yaml, "CSafeLoader", None) or getattr(yaml, "SafeLoader", None)
    if base is None:
        return None                     # the Copilot skill's JSON-only yaml_shim

    class Yaml12Loader(base):           # noqa: D401 - a loader, not a function
        pass

    replaced = {"tag:yaml.org,2002:bool", "tag:yaml.org,2002:int", "tag:yaml.org,2002:float",
                "tag:yaml.org,2002:timestamp"}
    Yaml12Loader.yaml_implicit_resolvers = {
        first: [r for r in resolvers if r[0] not in replaced]
        for first, resolvers in base.yaml_implicit_resolvers.items()}
    Yaml12Loader.add_implicit_resolver(
        "tag:yaml.org,2002:bool", re.compile(r"^(?:true|True|TRUE|false|False|FALSE)$"),
        list("tTfF"))
    Yaml12Loader.add_implicit_resolver(
        "tag:yaml.org,2002:int", re.compile(r"^[-+]?(?:0|[1-9][0-9]*)$"), list("-+0123456789"))
    Yaml12Loader.add_implicit_resolver(
        "tag:yaml.org,2002:float",
        re.compile(r"^[-+]?(?:[0-9]+\.[0-9]*|\.[0-9]+)(?:[eE][-+]?[0-9]+)?$"
                   r"|^[-+]?[0-9]+[eE][-+]?[0-9]+$"), list("-+0123456789."))
    return Yaml12Loader


_YAML12 = []                            # built on first use: the yaml module can be a shim


def _loader():
    if not _YAML12:
        _YAML12.append(_yaml12_loader())
    return _YAML12[0]


def parse_text(text: str, name: str = ""):
    """Project text -> data, the one parser every route uses.

    JSON (a .json name, or text that starts with `{`) goes to the JSON parser: strict,
    and about 250 times faster than PyYAML on a 6000-point list (7 ms against 2 s).
    Anything else is YAML, read by YAML 1.2 rules (_yaml12_loader).

    Both refuse a key written twice in one mapping and a NaN or Infinity, naming each by
    its key path and line (JsonTextError, YamlTextError): a parser would otherwise keep
    the last copy of the key and lose the rest without a word.
    """
    text = text.lstrip("\ufeff")
    if name.lower().endswith(".json") or text.lstrip().startswith("{"):
        return _strict_json(text)
    loader_cls = _loader()
    if loader_cls is None:
        # the Copilot skill's JSON-only yaml_shim: JSON is the only text it reads, so read
        # it strictly, and let the shim's own message explain anything that is not JSON
        try:
            return _strict_json(text)
        except JsonTextError:
            raise
        except json.JSONDecodeError:
            return yaml.safe_load(text)
    loader = loader_cls(text)
    try:
        node = loader.get_single_node()
        if node is None:
            return None
        problems = _yaml_problems(loader, node)
        if problems:
            raise YamlTextError(problems)
        return loader.construct_document(node)
    finally:
        loader.dispose()


def key_report(text: str, name: str = "") -> dict:
    """{"notes": [...], "errors": [...]} for an imported project text, before the page
    prunes it.

    `notes` names every key the page will leave out (model.unknown_keys). `errors` holds
    one sentence per reason the text cannot be read as written - a key written twice, a
    NaN or an Infinity, each with its key path and line - or the parser's own message
    when the text is not JSON or YAML at all; empty when it reads cleanly. The page's
    JSON.parse keeps the last copy of a repeated key without a word, so this, reading
    the raw text, is the only place the repeat can still be seen.
    """
    try:
        data = parse_text(text, name)
    except (JsonTextError, YamlTextError) as e:
        return {"notes": [], "errors": list(e.problems)}
    except (ValueError, yaml.YAMLError) as e:
        return {"notes": [], "errors": [str(e)]}
    return {"notes": unknown_keys(data), "errors": []}


def option_default(name: str, sql_format: str | None = None):
    """The value an option takes when a file leaves it out. Only truncate depends on
    the format (Options.truncates): on for legacy, off for modern."""
    if name == "truncate":
        return (sql_format or OPTION_DEFAULTS["sql_format"]) == "legacy"
    return OPTION_DEFAULTS[name]
POINT_DEFAULTS = {f.name: getattr(Point(), f.name) for f in dc_fields(Point)
                  if f.name != "synthesized"}
POINT_ORDER = ["group", "datatype", "addr", "bit", "element_id", "system_no", "tag",
               "text", "extra", "alarm", "unit", "scale", "rw", "update_freq",
               "online", "active", "no_group", "menu", "decimals", "range_min",
               "range_max", "statetext"]

SCHEMA_HEADER = "# yaml-language-server: $schema=../schema/project.schema.json\n"

# The published copy of the same schema. A file saved into projects/ keeps the relative
# header above - it works offline for anyone with the checkout - but a file that is
# DOWNLOADED travels to machines and AI chats that have no checkout, so it references
# the contract by a URL anything can fetch. build_web.py ships the schema there.
# SCHEMA_URL is defined in model.py (the shape check names it) and imported above; it
# is still reachable as yamlio.SCHEMA_URL, which is where every other module reads it.
SCHEMA_HEADER_PUBLIC = f"# yaml-language-server: $schema={SCHEMA_URL}\n"

# The relative form, for a JSON file written into projects/ - the sibling of
# SCHEMA_HEADER above, which YAML has carried since the beginning and JSON had not.
SCHEMA_REL = "../schema/project.schema.json"

# Help text carried inside every exported JSON.
#
# YAML says this in comments; JSON has none, and an exported list is precisely the thing
# that travels - into a Copilot chat, onto a partner's machine, into a mail thread - where
# no CLAUDE.md, no copilot-instructions and no docs/ are in reach. $schema answers "what
# is this field"; nothing answered "what am I holding, and what would be wrong to do to
# it", so an agent handed a list cold had to infer the rules from the data, which is how
# invented datatype keys and doubly-subtracted addresses get into a file that still parses.
#
# What earns a line here is a rule that is expensive to get wrong and impossible to
# recover from the file itself. Only two URLs are quoted, because only those two resolve
# without a checkout: the published schema and the browser build. The source repository
# is private, so docs/11 is named rather than linked - it is written to be uploaded into
# a chat, and asking for it beats guessing at what it says.
#
# The loader strips the block (model.load_project), so it costs bytes and nothing else.
HELP_BLOCK = {
    "what": "An IWMAC/Kiona Modbus point list in modbusgen project form. This file is "
            "the source of truth for the plant's list: the SQL import script is "
            "generated from it, and is never hand-written or hand-patched.",
    "generate": "modbusgen generate <this file>. Without a checkout, the same tool runs "
                "in the browser at https://hapnes-dev.github.io/modbusgen-web/ - open "
                "this file there to edit, validate and generate.",
    "contract": "Every field, its type and its meaning are in the schema named by "
                "$schema above, which is a fetchable URL. Read it before adding or "
                "renaming anything: an unknown key is a load error, not a comment.",
    "absent_fields": "Anything not written here is at its documented default. The file "
                     "is pruned on export, so every field present was decided - do not "
                     "expand defaults back into it, and do not read an absent field as "
                     "an omission to fill in.",
    "never_invent": "datatype and scale are keys into the tool's shipped tables "
                    "(data/tables/datatypes.csv, scaling.csv), not free text; unit is a "
                    "key into units.csv where one exists, and a custom unit the table "
                    "lacks ships into eng_unit exactly as typed, with nothing raised - "
                    "never a near-miss spelling of a key. For datatype and scale a near "
                    "miss is a validation error carrying a suggested key - check "
                    "the suggestion against the vendor document before taking it: "
                    "I_Hold_U16R_N suggests I_Hold_U16_R, which is wrong for a device "
                    "that really is _N.",
    "addressing": "addr is the register as the vendor document prints it, with any "
                  "4xxxx/3xxxxx prefix stripped. options.subtract_one is the only "
                  "offset conversion there is - never subtract one per point as well.",
    "driver": "The top-level driver key names which IWMAC Modbus driver the plant runs "
              "- mb.exe or modbus.php - and is absent when nobody has said. It reaches "
              "no database column; it decides what is possible at all. modbus.php "
              "supports no word or byte swap and no FC16, so on it a _R or _W point "
              "reads a plausible wrong number and a writable 32-bit point is never "
              "written, neither of them with any error. mb.exe is the house standard "
              "and what a new project starts with, so most files say it outright; "
              "modbus.php is the exception, and belongs in the file whenever the plant "
              "is known to run it. Leaving the key out is still a legal answer - it "
              "means nobody said, not mb.exe - and guessing is still not.",
    "bit_points": "A bit row carries a Bit_*/Coil_* datatype and a bit number, nothing "
                  "more. The 16-bit motherword is synthesized - do not author one. A bit "
                  "of 16-31 is an error unless an explicit 32-bit point at the same "
                  "address commits to a word order.",
    "point_order": "The order of points is the order the operator sees (view_order). It "
                   "is meaningful, not cosmetic: normally the vendor document's own "
                   "order, or the source workbook's section order.",
    "language": "Nothing user-facing is translated. A point's text, the state words and "
                "the group aliases all keep the document's own wording as printed, so "
                "the list and the manual read side by side. The document's language is "
                "the list's language: a Norwegian manual gives Norwegian texts, an "
                "English one English, and translating either way is the mistake. Do not "
                "invent a description either: where the document names nothing, say so "
                "rather than shipping 'Register 4'. The five default group aliases are "
                "the tool's own, for a document with no sections of its own. Keep all of "
                "them short.",
    "validation": "modbusgen refuses to generate while an error stands. Warnings do not "
                  "block and are not noise: each names what it costs to ignore. Fix the "
                  "cause the code names; never delete the row that reports it.",
    "authoring_guide": "Authoring a list from a vendor register document is governed by "
                       "docs/11-ai-json-authoring.md in the (private) "
                       "modbus-list-generator repository. It is written to be uploaded "
                       "into a chat - ask for it rather than inferring its rules here.",
    "this_block": "_help is annotation. modbusgen ignores it on load and rewrites it on "
                  "export, so edits to it are not preserved and never affect output.",
}


def _text_or_blank(value) -> str:
    """A value as the text the file means: null is blank, not the word 'None' (review,
    2026-10-24 - a null plant or state word reached the page and the script as 'None')."""
    return "" if value is None else str(value)


def _numbered(mapping):
    """A mapping keyed by list id or state number, its keys as ints - or the mapping as it
    came when that cannot be done faithfully: a key that is not a whole number, or two
    spellings of one number ("1" and "01"). Collapsing those here would keep one of the
    two without a word; left alone, load_project names the problem instead."""
    if not isinstance(mapping, dict):
        return mapping
    out: dict = {}
    for key, value in mapping.items():
        if isinstance(key, int) and not isinstance(key, bool):
            number = key
        elif isinstance(key, str) and re.fullmatch(r"\s*[-+]?\d+\s*", key):
            number = int(key)
        else:
            return dict(mapping)
        if number in out:
            return dict(mapping)
        out[number] = value
    return out


def to_yaml_dict(data: dict) -> dict:
    """Canonical, pruned YAML representation of a project payload."""
    out: dict = {"table": data.get("table", ""), "plant": _text_or_blank(data.get("plant"))}
    # Beside plant, and pruned when not stated - "" is the documented default and an
    # absent field reads as one. Every payload the GUI sends goes through here, so a
    # field this drops never reaches load_project at all.
    driver = str(data.get("driver") or "").strip()
    if driver:
        out["driver"] = driver
    # Anything that is not the shape it should be is passed on as it came rather than
    # read here: load_project names it with its path, where this used to raise a bare
    # AttributeError or ValueError, or quietly keep one of two colliding keys.
    raw_options = data.get("options") or {}
    if isinstance(raw_options, dict):
        options = {k: v for k, v in raw_options.items()
                   if k in OPTION_DEFAULTS and v is not None
                   and v != option_default(k, raw_options.get("sql_format"))}
        if options:
            out["options"] = options
    else:
        out["options"] = raw_options
    if data.get("system"):
        out["system"] = data["system"]
    if data.get("groups"):
        out["groups"] = data["groups"]
    statetexts = data.get("statetexts") or {}
    if statetexts:
        lists = _numbered(statetexts)
        if isinstance(lists, dict):
            lists = {sid: _numbered(states) for sid, states in lists.items()}
            lists = {sid: ({n: _text_or_blank(w) for n, w in states.items()}
                           if isinstance(states, dict) else states)
                     for sid, states in lists.items()}
        out["statetexts"] = lists
    datatypes = data.get("datatypes") or {}
    if datatypes:
        names = ({str(name) for name in datatypes} if isinstance(datatypes, dict) else ())
        if isinstance(datatypes, dict) and len(names) == len(datatypes):
            # a null column is blank - a row with no write function - not the text 'None'
            out["datatypes"] = {str(name): ({k: _text_or_blank(v) for k, v in row.items()}
                                            if isinstance(row, dict) else row)
                                for name, row in datatypes.items()}
        else:
            out["datatypes"] = datatypes
    points = []
    for p in data.get("points") or []:
        if not isinstance(p, dict):
            points.append(p)
            continue
        row = {}
        for key in POINT_ORDER:
            v = p.get(key)
            if v is None or v == "" or v == POINT_DEFAULTS.get(key):
                continue
            row[key] = v
        points.append(row)
    out["points"] = points
    return out


def _yaml12_dumper():
    """A safe dumper that quotes every text the YAML 1.2 loader above would not read back
    as text.

    PyYAML's dumper quotes by YAML 1.1 rules, under which 1E2 and 1.5e3 are text and go
    out bare - and the 1.2 loader reads them back as the numbers 100.0 and 1500.0, so a
    text '1E2' failed to load ("write 100.0 in quotes") and a range '1E3' came back as
    '1000' (review, 2026-10-24). A text is written bare here only when both rule sets
    read it as text: the file then reads back the same through this loader, and through
    a YAML 1.1 reader too - On stays quoted, as it always was.
    """
    base = getattr(yaml, "SafeDumper", None)
    loader = _loader()
    if base is None or loader is None:
        return None                     # the Copilot skill's shim writes no YAML
    resolvers = loader.yaml_implicit_resolvers

    class Yaml12Dumper(base):           # noqa: D401 - a dumper, not a function
        def resolve(self, kind, value, implicit):
            tag = super().resolve(kind, value, implicit)
            if kind is yaml.ScalarNode and implicit[0] and tag == _STR_TAG:
                for t, regexp in (resolvers.get(value[:1], [])
                                  + resolvers.get(None, [])):
                    if regexp.match(value):
                        return t
            return tag

    return Yaml12Dumper


_DUMPER = []


def dump_yaml(data) -> str:
    """YAML text that parse_text reads back exactly as it was written (_yaml12_dumper).

    The one dumper for project YAML: write_project_yaml writes through it, and so should
    every other route that hands out a .yaml file.
    """
    if not _DUMPER:
        _DUMPER.append(_yaml12_dumper())
    if _DUMPER[0] is None:
        return yaml.safe_dump(data, sort_keys=False, allow_unicode=True, width=100)
    return yaml.dump(data, Dumper=_DUMPER[0], sort_keys=False, allow_unicode=True,
                     width=100)


def write_project_yaml(path: Path, data: dict) -> dict:
    """Prune, dump and write; returns the pruned dict."""
    clean = to_yaml_dict(data)
    text = dump_yaml(clean)
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8", newline="\n") as fh:
        fh.write(SCHEMA_HEADER)
        fh.write(text)
    return clean


def write_project(path: Path, data: dict) -> dict:
    """Write as JSON or YAML depending on the file extension."""
    if str(path).lower().endswith(".json"):
        import json
        clean = to_yaml_dict(data)
        # JSON object keys are strings; statetext ids/numbers survive as strings and
        # load_project converts them back to ints.
        # $schema and _help are what the YAML header is for a JSON file: the contract it
        # is written against, and the prose YAML would carry in comments. The relative
        # path matches SCHEMA_HEADER because this writes into the checkout; a DOWNLOADED
        # file gets the public URL instead (webapi.canonical_json).
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "w", encoding="utf-8", newline="\n") as fh:
            json.dump({"$schema": SCHEMA_REL, "_help": HELP_BLOCK, **clean}, fh,
                      indent=2, ensure_ascii=False)
            fh.write("\n")
        return clean
    return write_project_yaml(path, data)
