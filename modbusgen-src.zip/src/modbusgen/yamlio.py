"""Canonical YAML serialization of a project dict (shared by GUI save and the
xlsm importer): defaults pruned, keys in schema order, schema header line for
editor support."""
from __future__ import annotations

from dataclasses import fields as dc_fields
from pathlib import Path

import yaml

from .model import SCHEMA_URL, Options, Point

OPTION_DEFAULTS = {f.name: getattr(Options(), f.name) for f in dc_fields(Options)}


def option_default(name: str, sql_format: str | None = None):
    """The value an option takes when a file leaves it out. Only truncate depends on
    the format (Options.truncates): on for legacy, off for modern."""
    if name == "truncate":
        return (sql_format or OPTION_DEFAULTS["sql_format"]) == "legacy"
    return OPTION_DEFAULTS[name]
POINT_DEFAULTS = {f.name: getattr(Point(), f.name) for f in dc_fields(Point)
                  if f.name != "synthesized"}
POINT_ORDER = ["group", "datatype", "addr", "bit", "element_id", "system_no", "tag",
               "text", "extra", "alarm", "unit", "scale", "rw", "update_freq",
               "online", "active", "no_group", "menu", "decimals", "range_min",
               "range_max", "statetext"]

SCHEMA_HEADER = "# yaml-language-server: $schema=../schema/project.schema.json\n"

# The published copy of the same schema. A file saved into projects/ keeps the relative
# header above - it works offline for anyone with the checkout - but a file that is
# DOWNLOADED travels to machines and AI chats that have no checkout, so it references
# the contract by a URL anything can fetch. build_web.py ships the schema there.
# SCHEMA_URL is defined in model.py (the shape check names it) and imported above; it
# is still reachable as yamlio.SCHEMA_URL, which is where every other module reads it.
SCHEMA_HEADER_PUBLIC = f"# yaml-language-server: $schema={SCHEMA_URL}\n"

# The relative form, for a JSON file written into projects/ - the sibling of
# SCHEMA_HEADER above, which YAML has carried since the beginning and JSON had not.
SCHEMA_REL = "../schema/project.schema.json"

# Help text carried inside every exported JSON.
#
# YAML says this in comments; JSON has none, and an exported list is precisely the thing
# that travels - into a Copilot chat, onto a partner's machine, into a mail thread - where
# no CLAUDE.md, no copilot-instructions and no docs/ are in reach. $schema answers "what
# is this field"; nothing answered "what am I holding, and what would be wrong to do to
# it", so an agent handed a list cold had to infer the rules from the data, which is how
# invented datatype keys and doubly-subtracted addresses get into a file that still parses.
#
# What earns a line here is a rule that is expensive to get wrong and impossible to
# recover from the file itself. Only two URLs are quoted, because only those two resolve
# without a checkout: the published schema and the browser build. The source repository
# is private, so docs/11 is named rather than linked - it is written to be uploaded into
# a chat, and asking for it beats guessing at what it says.
#
# The loader strips the block (model.load_project), so it costs bytes and nothing else.
HELP_BLOCK = {
    "what": "An IWMAC/Kiona Modbus point list in modbusgen project form. This file is "
            "the source of truth for the plant's list: the SQL import script is "
            "generated from it, and is never hand-written or hand-patched.",
    "generate": "modbusgen generate <this file>. Without a checkout, the same tool runs "
                "in the browser at https://hapnes-dev.github.io/modbusgen-web/ - open "
                "this file there to edit, validate and generate.",
    "contract": "Every field, its type and its meaning are in the schema named by "
                "$schema above, which is a fetchable URL. Read it before adding or "
                "renaming anything: an unknown key is a load error, not a comment.",
    "absent_fields": "Anything not written here is at its documented default. The file "
                     "is pruned on export, so every field present was decided - do not "
                     "expand defaults back into it, and do not read an absent field as "
                     "an omission to fill in.",
    "never_invent": "datatype and scale are keys into the tool's shipped tables "
                    "(data/tables/datatypes.csv, scaling.csv), not free text; unit is a "
                    "key into units.csv where one exists, and a custom unit the table "
                    "lacks ships into eng_unit exactly as typed, with nothing raised - "
                    "never a near-miss spelling of a key. For datatype and scale a near "
                    "miss is a validation error carrying a suggested key - check "
                    "the suggestion against the vendor document before taking it: "
                    "I_Hold_U16R_N suggests I_Hold_U16_R, which is wrong for a device "
                    "that really is _N.",
    "addressing": "addr is the register as the vendor document prints it, with any "
                  "4xxxx/3xxxxx prefix stripped. options.subtract_one is the only "
                  "offset conversion there is - never subtract one per point as well.",
    "driver": "The top-level driver key names which IWMAC Modbus driver the plant runs "
              "- mb.exe or modbus.php - and is absent when nobody has said. It reaches "
              "no database column; it decides what is possible at all. modbus.php "
              "supports no word or byte swap and no FC16, so on it a _R or _W point "
              "reads a plausible wrong number and a writable 32-bit point is never "
              "written, neither of them with any error. mb.exe is the house standard "
              "and what a new project starts with, so most files say it outright; "
              "modbus.php is the exception, and belongs in the file whenever the plant "
              "is known to run it. Leaving the key out is still a legal answer - it "
              "means nobody said, not mb.exe - and guessing is still not.",
    "bit_points": "A bit row carries a Bit_*/Coil_* datatype and a bit number, nothing "
                  "more. The 16-bit motherword is synthesized - do not author one. A bit "
                  "of 16-31 is an error unless an explicit 32-bit point at the same "
                  "address commits to a word order.",
    "point_order": "The order of points is the order the operator sees (view_order). It "
                   "is meaningful, not cosmetic: normally the vendor document's own "
                   "order, or the source workbook's section order.",
    "language": "Nothing user-facing is translated. A point's text, the state words and "
                "the group aliases all keep the document's own wording as printed, so "
                "the list and the manual read side by side. The document's language is "
                "the list's language: a Norwegian manual gives Norwegian texts, an "
                "English one English, and translating either way is the mistake. Do not "
                "invent a description either: where the document names nothing, say so "
                "rather than shipping 'Register 4'. The five default group aliases are "
                "the tool's own, for a document with no sections of its own. Keep all of "
                "them short.",
    "validation": "modbusgen refuses to generate while an error stands. Warnings do not "
                  "block and are not noise: each names what it costs to ignore. Fix the "
                  "cause the code names; never delete the row that reports it.",
    "authoring_guide": "Authoring a list from a vendor register document is governed by "
                       "docs/11-ai-json-authoring.md in the (private) "
                       "modbus-list-generator repository. It is written to be uploaded "
                       "into a chat - ask for it rather than inferring its rules here.",
    "this_block": "_help is annotation. modbusgen ignores it on load and rewrites it on "
                  "export, so edits to it are not preserved and never affect output.",
}


def to_yaml_dict(data: dict) -> dict:
    """Canonical, pruned YAML representation of a project payload."""
    out: dict = {"table": data.get("table", ""), "plant": str(data.get("plant", ""))}
    # Beside plant, and pruned when not stated - "" is the documented default and an
    # absent field reads as one. Every payload the GUI sends goes through here, so a
    # field this drops never reaches load_project at all.
    driver = str(data.get("driver") or "").strip()
    if driver:
        out["driver"] = driver
    raw_options = data.get("options") or {}
    options = {k: v for k, v in raw_options.items()
               if k in OPTION_DEFAULTS and v is not None
               and v != option_default(k, raw_options.get("sql_format"))}
    if options:
        out["options"] = options
    if data.get("system"):
        out["system"] = data["system"]
    if data.get("groups"):
        out["groups"] = data["groups"]
    statetexts = data.get("statetexts") or {}
    if statetexts:
        out["statetexts"] = {int(k): {int(n): str(w) for n, w in v.items()}
                             for k, v in statetexts.items()}
    datatypes = data.get("datatypes") or {}
    if datatypes:
        out["datatypes"] = {str(name): {k: str(v) for k, v in row.items()}
                            for name, row in datatypes.items()}
    points = []
    for p in data.get("points") or []:
        row = {}
        for key in POINT_ORDER:
            v = p.get(key)
            if v is None or v == "" or v == POINT_DEFAULTS.get(key):
                continue
            row[key] = v
        points.append(row)
    out["points"] = points
    return out


def write_project_yaml(path: Path, data: dict) -> dict:
    """Prune, dump and write; returns the pruned dict."""
    clean = to_yaml_dict(data)
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8", newline="\n") as fh:
        fh.write(SCHEMA_HEADER)
        yaml.safe_dump(clean, fh, sort_keys=False, allow_unicode=True, width=100)
    return clean


def write_project(path: Path, data: dict) -> dict:
    """Write as JSON or YAML depending on the file extension."""
    if str(path).lower().endswith(".json"):
        import json
        clean = to_yaml_dict(data)
        # JSON object keys are strings; statetext ids/numbers survive as strings and
        # load_project converts them back to ints.
        # $schema and _help are what the YAML header is for a JSON file: the contract it
        # is written against, and the prose YAML would carry in comments. The relative
        # path matches SCHEMA_HEADER because this writes into the checkout; a DOWNLOADED
        # file gets the public URL instead (webapi.canonical_json).
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "w", encoding="utf-8", newline="\n") as fh:
            json.dump({"$schema": SCHEMA_REL, "_help": HELP_BLOCK, **clean}, fh,
                      indent=2, ensure_ascii=False)
            fh.write("\n")
        return clean
    return write_project_yaml(path, data)
