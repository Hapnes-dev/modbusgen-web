"""Canonical YAML serialization of a project dict (shared by GUI save and the
xlsm importer): defaults pruned, keys in schema order, schema header line for
editor support."""
from __future__ import annotations

from dataclasses import fields as dc_fields
from pathlib import Path

import yaml

from .model import Options, Point

OPTION_DEFAULTS = {f.name: getattr(Options(), f.name) for f in dc_fields(Options)}
POINT_DEFAULTS = {f.name: getattr(Point(), f.name) for f in dc_fields(Point)
                  if f.name != "synthesized"}
POINT_ORDER = ["group", "datatype", "addr", "bit", "element_id", "system_no", "tag",
               "text", "extra", "alarm", "unit", "scale", "rw", "online", "active",
               "no_group", "menu", "decimals", "range_min", "range_max", "statetext"]

SCHEMA_HEADER = "# yaml-language-server: $schema=../schema/project.schema.json\n"


def to_yaml_dict(data: dict) -> dict:
    """Canonical, pruned YAML representation of a project payload."""
    out: dict = {"table": data.get("table", ""), "plant": str(data.get("plant", ""))}
    options = {k: v for k, v in (data.get("options") or {}).items()
               if k in OPTION_DEFAULTS and v != OPTION_DEFAULTS[k]}
    if options:
        out["options"] = options
    if data.get("system"):
        out["system"] = data["system"]
    if data.get("groups"):
        out["groups"] = data["groups"]
    statetexts = data.get("statetexts") or {}
    if statetexts:
        out["statetexts"] = {int(k): {int(n): str(w) for n, w in v.items()}
                             for k, v in statetexts.items()}
    points = []
    for p in data.get("points") or []:
        row = {}
        for key in POINT_ORDER:
            v = p.get(key)
            if v is None or v == "" or v == POINT_DEFAULTS.get(key):
                continue
            row[key] = v
        points.append(row)
    out["points"] = points
    return out


def write_project_yaml(path: Path, data: dict) -> dict:
    """Prune, dump and write; returns the pruned dict."""
    clean = to_yaml_dict(data)
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8", newline="\n") as fh:
        fh.write(SCHEMA_HEADER)
        yaml.safe_dump(clean, fh, sort_keys=False, allow_unicode=True, width=100)
    return clean


def write_project(path: Path, data: dict) -> dict:
    """Write as JSON or YAML depending on the file extension."""
    if str(path).lower().endswith(".json"):
        import json
        clean = to_yaml_dict(data)
        # JSON object keys are strings; statetext ids/numbers survive as strings and
        # load_project converts them back to ints
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "w", encoding="utf-8", newline="\n") as fh:
            json.dump(clean, fh, indent=2, ensure_ascii=False)
            fh.write("\n")
        return clean
    return write_project_yaml(path, data)
