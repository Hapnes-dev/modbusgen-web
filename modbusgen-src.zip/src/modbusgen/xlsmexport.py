"""Write a project back into the original Modbustemplate workbook.

The exact inverse of importer.py: it fills the Work input columns A-AE, the
Main_Setup / Protocol_Spesific_Setup toggles, the active Groups_Setup table and the
JSON Setup state texts, using the same cell map (docs/01-workbook-structure.md,
docs/02-inputs.md). Only *input* cells are written - the generated columns are the
Excel macro's job, so the file lands ready for the macro to run, not pre-filled with
output this tool would have derived differently.

The workbook is opened with keep_vba so the macros survive, and never with
data_only, which would replace every formula with its cached value.

Two things the workbook cannot hold, both reported rather than silently dropped:
it has room for exactly one device (the project's `unit_list` may carry several),
and its baud rate is a checkbox offering only 9600 or 19200.

Requires openpyxl (pip install openpyxl).
"""
from __future__ import annotations

import io
from pathlib import Path

from .importer import COL, ROW_CAP
from .model import Project, load_project
from .yamlio import to_yaml_dict

TEMPLATE = (Path(__file__).resolve().parent.parent.parent
            / "reference" / "Modbustemplate_18082026.xlsm")

# Main_Setup / Protocol_Spesific_Setup option cells, mirroring importer.import_xlsm.
MAIN_FLAGS = {"truncate": "B23", "create_tables": "B25", "use_tag": "B27",
              "use_system_no": "B31", "use_extra": "B35"}
PROT_FLAGS = {"subtract_one": "B18", "auto_groups": "B22", "alarms_to_alm": "B26",
              "exclude_motherwords_from_groups": "B30", "force_active": "B38",
              "include_minmax": "B42", "override_decimal": "B46", "use_json": "B54",
              "statetext_only_rw": "B58", "statetext_in_alias": "B62"}

GROUPS_FIRST_ROW = 4        # rows 1-3 are headers and the default_link row
JSON_FIRST_ROW = 3          # row 1 titles, row 2 the state numbers
WORK_FIRST_ROW = 3          # rows 1-2 are the column index and the header


def _blank(sheet, first_row: int, columns, last_row: int) -> None:
    """Clear the template's own sample data out of the columns we are about to fill."""
    for row in range(first_row, last_row + 1):
        for col in columns:
            sheet.cell(row=row, column=col).value = None


def export_xlsm(data: dict, template=None) -> tuple[bytes, list[str]]:
    """Project dict -> (.xlsm bytes, notes).

    `template` is a path, raw bytes, or any binary file object; None means the
    reference workbook in the repository. The browser build passes a path inside
    Pyodide's virtual filesystem, which is why this does not insist on a real one.
    Raises ValueError if openpyxl is missing or the template cannot be found.
    """
    try:
        import openpyxl
    except ImportError as e:  # pragma: no cover - environment-dependent
        raise ValueError("openpyxl is required for xlsm export: "
                         "pip install openpyxl") from e

    if isinstance(template, (bytes, bytearray)):
        src = io.BytesIO(template)
    elif template is None or isinstance(template, (str, Path)):
        src = Path(template) if template else TEMPLATE
        if not src.is_file():
            raise ValueError(f"Modbustemplate workbook not found at {src}")
    else:
        src = template            # already a file object

    project: Project = load_project(to_yaml_dict(data))
    notes: list[str] = []
    wb = openpyxl.load_workbook(src, keep_vba=True)
    try:
        _write_setup(wb, project, notes)
        _write_groups(wb, project)
        _write_statetexts(wb, project, notes)
        _write_points(wb, project, notes)
        buf = io.BytesIO()
        wb.save(buf)
    finally:
        wb.close()
    return buf.getvalue(), notes


def _write_setup(wb, project: Project, notes: list[str]) -> None:
    main, prot = wb["Main_Setup"], wb["Protocol_Spesific_Setup"]
    o = project.options
    main["B19"] = project.table
    main["B21"] = project.plant
    for name, cell in MAIN_FLAGS.items():
        main[cell] = bool(getattr(o, name))
    for name, cell in PROT_FLAGS.items():
        prot[cell] = bool(getattr(o, name))
    # the reserve rule is a flag plus its text; an empty text means the rule is off
    main["B13"] = o.reserve_text or None
    main["B14"] = bool(o.reserve_text)

    s = project.system
    main["B42"] = bool(s and s.units)
    main["B45"] = bool(s and s.settings)
    if not s:
        return

    units = list(s.unit_list or [])
    first = units[0] if units else s
    main["B48"] = getattr(first, "unit_id", "") or ""
    main["B51"] = getattr(first, "unit_name", "") or ""
    main["B63"] = getattr(first, "driver_addr", "") or ""
    if len(units) > 1:
        kept = getattr(first, "unit_id", "") or "the first device"
        notes.append(f"the workbook holds one device: wrote {kept} and left out "
                     f"{len(units) - 1} more ({', '.join(str(getattr(u, 'unit_id', '?')) for u in units[1:])}). "
                     f"Add them in the plant database, or keep using the JSON project.")
    main["B54"] = s.reg_type or ""
    main["B57"] = s.order_no or ""
    main["B60"] = s.owner or ""
    main["C63"] = s.driver_addr_prefix == "1_"

    c = s.comm
    if not c:
        return
    main["B10"] = c.mode == "rtu"
    main["B69"] = c.ip or ""
    main["B66"] = c.com_port or ""
    main["B72"] = int(c.baudrate or 19200) == 9600
    if int(c.baudrate or 19200) not in (9600, 19200):
        notes.append(f"the workbook's baud rate is a 9600/19200 checkbox, so "
                     f"{c.baudrate} could not be written - it now reads 19200. "
                     f"Set the real rate in the plant database.")
    main["E75"] = c.parity or "even"
    main["B78"] = int(c.stop_bits or 1) == 1
    if c.mode == "tcp" and c.port and int(c.port) != 502:
        notes.append(f"the workbook has no TCP port cell, so port {c.port} was not "
                     f"written (it assumes 502)")


def _write_groups(wb, project: Project) -> None:
    """Fill whichever of the two Groups_Setup tables the auto_groups toggle selects -
    the same choice importer.import_xlsm reads back."""
    gs = wb["Groups_Setup"]
    order_col, ref_col, alias_col = ((12, 13, 14) if project.options.auto_groups
                                     else (3, 4, 5))
    _blank(gs, GROUPS_FIRST_ROW, (order_col, ref_col, alias_col), gs.max_row)
    row = GROUPS_FIRST_ROW
    for i, g in enumerate(project.groups, start=1):
        gs.cell(row=row, column=order_col).value = g.order if g.order else i
        gs.cell(row=row, column=ref_col).value = g.name
        gs.cell(row=row, column=alias_col).value = g.alias or ""
        row += 1


def _write_statetexts(wb, project: Project, notes: list[str]) -> None:
    """Row 2 carries the state numbers; each list is a row keyed by id in column A."""
    js = wb["JSON Setup"]
    number_col = {}
    for cell in js[2]:
        if isinstance(cell.value, int):
            number_col.setdefault(cell.value, cell.column)
    last_col = max(number_col.values(), default=1)
    _blank(js, JSON_FIRST_ROW, [1] + sorted(number_col.values()), js.max_row)

    row = JSON_FIRST_ROW
    for sid, states in sorted(project.statetexts.items()):
        js.cell(row=row, column=1).value = int(sid)
        missing = []
        for number, word in sorted(states.items(), key=lambda kv: int(kv[0])):
            col = number_col.get(int(number))
            if col is None:
                missing.append(int(number))
                continue
            js.cell(row=row, column=col).value = word
        if missing:
            notes.append(f"state list {sid}: the sheet only has columns for states "
                         f"0-{max(number_col, default=0)}, so {missing} were left out")
        row += 1
    if project.statetexts and not project.options.use_json:
        notes.append("state texts were written but use_json is off, so the workbook "
                     "will ignore them until that toggle is on")
    _ = last_col


def _write_points(wb, project: Project, notes: list[str]) -> None:
    work = wb["Work"]
    columns = sorted(COL.values())
    # the template ships with an empty Work sheet, but an export of an export is
    # still a real case - clear whatever input cells are there before writing
    _blank(work, WORK_FIRST_ROW, columns, min(work.max_row, ROW_CAP))

    written = 0
    for i, p in enumerate(project.points):
        if p.synthesized:
            continue            # motherwords are the macro's to synthesize, not ours
        row = WORK_FIRST_ROW + written
        if row > ROW_CAP:
            notes.append(f"the workbook's macros only scan to row {ROW_CAP}, so "
                         f"{len(project.points) - i} point(s) were left out")
            break
        def put(name, value, _row=row):
            work.cell(row=_row, column=COL[name]).value = value

        put("group", p.group or None)
        put("datatype", p.datatype)
        put("addr", p.addr)
        put("bit", p.bit if p.bit not in ("", None) else None)
        for name in ("element_id", "system_no", "tag", "extra", "text", "unit",
                     "scale", "menu"):
            put(name, getattr(p, name) or None)
        put("alarm", (p.alarm or "").upper() or None)
        put("rw", p.rw or "r")
        put("online", 1 if p.online else None)
        put("active", p.active if p.active in (0, 1) else None)
        put("no_group", "x" if p.no_group else None)
        put("decimals", p.decimals if p.decimals is not None else None)
        put("range_min", p.range_min or None)
        put("range_max", p.range_max or None)
        put("statetext", p.statetext if p.statetext else None)
        written += 1

    dropped = sum(1 for p in project.points if p.synthesized)
    if dropped:
        notes.append(f"left out {dropped} synthesized motherword row(s) - the "
                     f"workbook's macros create those themselves")
    if any(p.update_freq for p in project.points):
        notes.append("update_freq has no column in the workbook and was dropped; "
                     "the JSON project keeps it")


def default_filename(project_table: str, plant: str) -> str:
    stem = "_".join(x for x in (plant, project_table) if x) or "modbus"
    return f"Modbustemplate_{stem}.xlsm"
