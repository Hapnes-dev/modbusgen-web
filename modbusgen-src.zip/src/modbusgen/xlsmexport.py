"""Write a project back into the original Modbustemplate workbook.

The exact inverse of importer.py: it fills the Work input columns A-AE, the
Main_Setup / Protocol_Spesific_Setup toggles, the active Groups_Setup table and the
JSON Setup state texts, using the same cell map (docs/01-workbook-structure.md,
docs/02-inputs.md). Only *input* cells are written - the generated columns are the
Excel macro's job, so the file lands ready for the macro to run, not pre-filled with
output this tool would have derived differently.

The workbook is opened with keep_vba so the macros survive, and never with
data_only, which would replace every formula with its cached value. keep_vba is
not by itself enough to hand someone a working tool: openpyxl rebuilds the
package's root relationships from its own model, and that model has no notion of a
custom ribbon, so the saved file keeps `customUI/customUI14.xml` and its two button
images while losing the one relationship that points Excel at them. The result opens
with the VBA intact and no **INAS Modbus** tab — the macros are all there, and the
way anybody actually runs them is gone. `_restore_ribbon` puts that relationship
back after the save, along with any part it reaches that openpyxl dropped.

Two things the workbook cannot hold, both reported rather than silently dropped:
it has room for exactly one device (the project's `unit_list` may carry several),
and its baud rate is a checkbox offering only 9600 or 19200.

Requires openpyxl (pip install openpyxl).
"""
from __future__ import annotations

import io
import re
import zipfile
from pathlib import Path

from .importer import COL, ROW_CAP
from .model import Project, load_project
from .tables import project_tables, unknown_datatypes
from .yamlio import to_yaml_dict

TEMPLATE = (Path(__file__).resolve().parent.parent.parent
            / "reference" / "Modbustemplate_18082026.xlsm")

# Main_Setup / Protocol_Spesific_Setup option cells, mirroring importer.import_xlsm.
MAIN_FLAGS = {"truncate": "B23", "create_tables": "B25", "use_tag": "B27",
              "use_system_no": "B31", "use_extra": "B35"}
PROT_FLAGS = {"subtract_one": "B18", "auto_groups": "B22", "alarms_to_alm": "B26",
              "exclude_motherwords_from_groups": "B30", "force_active": "B38",
              "include_minmax": "B42", "override_decimal": "B46", "use_json": "B54",
              "statetext_only_rw": "B58", "statetext_in_alias": "B62"}

# The ribbon repair. Both the 2007 and the 2010 customUI relationship types end in
# `/ui/extensibility`, and a template carrying neither simply skips the repair.
ROOT_RELS = "_rels/.rels"
CONTENT_TYPES = "[Content_Types].xml"
UI_EXTENSIBILITY = "/ui/extensibility"
_REL = re.compile(r"<Relationship\b[^>]*?/>")
_REL_ID = re.compile(r'\bId="([^"]*)"')
_REL_TARGET = re.compile(r'\bTarget="([^"]*)"')
_DEFAULT_TYPE = re.compile(r'<Default\b[^>]*?Extension="([^"]*)"[^>]*?/>', re.I)

# Modbus_Variables!Z:AI - the workbook's own datatype table (docs/02). Header on row 2,
# data from row 3, and the VBA lookup range is the literal Z3:AI100, so row 100 is the
# last row the macro can see. Rows 3-81 are used in the shipped template: 19 are free.
VARIABLES_SHEET = "Modbus_Variables"
VARIABLES_FIRST_ROW = 3
VARIABLES_LAST_ROW = 100                  # the VBA range, not the sheet
VARIABLES_COLS = (26, 27, 28, 29, 30, 31, 32, 33, 34, 35)   # Z..AI
VARIABLES_FIELDS = ("name", "read_func", "write_func", "raw_type", "read_swap",
                    "write_swap", "application", "parameter_type", "rw_hint",
                    "default_group")

GROUPS_FIRST_ROW = 4        # rows 1-3 are headers and the default_link row
JSON_FIRST_ROW = 3          # row 1 titles, row 2 the state numbers
WORK_FIRST_ROW = 3          # rows 1-2 are the column index and the header


def _sync_workbook_datatypes(wb, project: Project, tables) -> list[str]:
    """Give the workbook every datatype this project's points actually use.

    The macro resolves Work column D against this sheet, not against modbusgen's table,
    and the two are not the same: 64 of the 135 shipped datatypes are absent here (the
    56 added on 2026-08-20 and the eight I_Input_*_R/_W keys that correct the sheet's
    own misnamed rows), quite apart from anything the project defined for itself. A key
    the sheet lacks comes back #N/A in every generated column, silently, which is why
    this writes rather than warns.
    """
    if VARIABLES_SHEET not in wb.sheetnames:
        return []                          # an older template; nothing to keep in step
    ws = wb[VARIABLES_SHEET]
    present, last_used = set(), VARIABLES_FIRST_ROW - 1
    for row in range(VARIABLES_FIRST_ROW, VARIABLES_LAST_ROW + 1):
        name = ws.cell(row=row, column=VARIABLES_COLS[0]).value
        if name in (None, ""):
            continue
        present.add(str(name).strip().casefold())
        last_used = row

    wanted, seen = [], set()
    for p in project.points:
        key = (p.datatype or "").strip()
        if not key or key.casefold() in present or key.casefold() in seen:
            continue
        dt = tables.datatypes.get(key)
        if dt is None:
            continue                       # _refuse_unknown_datatypes already stopped this
        seen.add(key.casefold())
        wanted.append(dt)
    if not wanted:
        return []

    free = VARIABLES_LAST_ROW - last_used
    if len(wanted) > free:
        raise ValueError(
            f"cannot export to the workbook: it needs {len(wanted)} datatype row(s) "
            f"added to {VARIABLES_SHEET} and only {free} fit. The macro's lookup range "
            f"is the literal Z3:AI{VARIABLES_LAST_ROW}, so rows past it would be "
            f"invisible to it. Use fewer distinct datatypes in one list, or widen that "
            f"range in the workbook's VBA first.")

    for offset, dt in enumerate(wanted, start=1):
        row = last_used + offset
        for col, fieldname in zip(VARIABLES_COLS, VARIABLES_FIELDS):
            value = getattr(dt, fieldname)
            # the sheet's own rows hold the two function columns as numbers
            ws.cell(row=row, column=col).value = (int(value) if value.isdigit()
                                                  else value)
    names = ", ".join(dt.name for dt in wanted)
    return [f"added {len(wanted)} datatype row(s) to {VARIABLES_SHEET} so the "
            f"workbook's macro can resolve them: {names}"]


def _refuse_unknown_datatypes(project: Project) -> None:
    """Stop an export that would write a datatype nothing describes.

    `generate` has always been gated by `modbusgen validate`, which rejects a datatype
    missing from `data/tables/datatypes.csv`. The workbook export never was, so a
    spelling no table knows could be written into Work column D and handed on - and the
    workbook's own macro derives every generated column from its datatype table, so the
    recipient gets a list that is wrong rather than a list that refuses. Same table,
    same rule, at the same strength as generating: this raises rather than warns.
    """
    unknown = unknown_datatypes(project.points, project_tables(project))
    if not unknown:
        return
    lines = []
    for name, rows in sorted(unknown.items()):
        shown = ", ".join(str(r) for r in rows[:5])
        if len(rows) > 5:
            shown += f", … {len(rows) - 5} more"
        lines.append(f"  datatype '{name}' - {len(rows)} point(s), row(s) {shown}")
    raise ValueError(
        "cannot export to the workbook: "
        f"{len(unknown)} datatype spelling(s) are not in data/tables/datatypes.csv.\n"
        + "\n".join(lines)
        + "\nThe workbook's macro derives its generated columns from that table, so a "
          "datatype nothing describes produces a broken list rather than an error. "
          "Pick an existing key, or add the row to data/tables/datatypes.csv first.")


def _part_path(base: str, target: str) -> str:
    """Resolve an OPC relationship target against the folder its .rels file describes."""
    if target.startswith("/"):
        return target.lstrip("/")
    parts = [p for p in base.split("/") if p]
    for segment in target.split("/"):
        if segment in ("", "."):
            continue
        if segment == "..":
            if parts:
                parts.pop()
        else:
            parts.append(segment)
    return "/".join(parts)


def _free_id(rel: str, used: set[str]) -> str:
    """Keep the template's relationship id unless openpyxl has already spent it."""
    found = _REL_ID.search(rel)
    if found and found.group(1) not in used:
        used.add(found.group(1))
        return rel
    n = 1
    while f"rId{n}" in used:
        n += 1
    used.add(f"rId{n}")
    return (_REL_ID.sub(f'Id="rId{n}"', rel, count=1) if found
            else rel[:-2] + f' Id="rId{n}"/>')


def _restore_ribbon(saved: bytes, template: bytes) -> bytes:
    """Give a saved workbook its custom ribbon back.

    openpyxl carries the `customUI/` parts over from the source workbook but writes a
    root `_rels/.rels` containing only the four relationships it knows about, so the
    INAS Modbus tab and its Run Application button vanish from a file whose VBA is
    byte-for-byte the original. Copy the `ui/extensibility` relationship across, follow
    it to whatever it references, and add back any part or content type that did not
    survive. A workbook that already has the relationship - a template without a
    ribbon, or a future openpyxl that keeps it - is returned untouched.
    """
    with zipfile.ZipFile(io.BytesIO(template)) as tpl:
        if ROOT_RELS not in tpl.namelist():
            return saved
        ribbon = [r for r in _REL.findall(tpl.read(ROOT_RELS).decode("utf-8"))
                  if UI_EXTENSIBILITY in r]
        if not ribbon:
            return saved

        with zipfile.ZipFile(io.BytesIO(saved)) as out:
            rels = out.read(ROOT_RELS).decode("utf-8")
            if UI_EXTENSIBILITY in rels:
                return saved
            present, in_template = set(out.namelist()), set(tpl.namelist())
            content_types = out.read(CONTENT_TYPES).decode("utf-8")

        # every part the ribbon reaches: the customUI xml, its own .rels, its images
        queue = [_part_path("", m.group(1))
                 for m in (_REL_TARGET.search(r) for r in ribbon) if m]
        reached, missing = set(), {}
        while queue:
            part = queue.pop()
            if part in reached:
                continue
            reached.add(part)
            folder, _, leaf = part.rpartition("/")
            sub = f"{folder}/_rels/{leaf}.rels" if folder else f"_rels/{leaf}.rels"
            for name in (part, sub):
                if name in in_template and name not in present:
                    missing[name] = tpl.read(name)
            if sub in in_template:
                queue += [_part_path(folder, m.group(1))
                          for m in _REL_TARGET.finditer(tpl.read(sub).decode("utf-8"))]

        # a part whose extension has no Default entry makes Excel call the file corrupt
        known = {e.lower() for e in _DEFAULT_TYPE.findall(content_types)}
        template_types = tpl.read(CONTENT_TYPES).decode("utf-8")
        added_types = []
        for name in sorted(reached | set(missing)):
            ext = name.rpartition(".")[2].lower()
            if ext in known:
                continue
            for entry in _DEFAULT_TYPE.finditer(template_types):
                if entry.group(1).lower() == ext:
                    added_types.append(entry.group(0))
                    known.add(ext)
                    break
        if added_types:
            content_types = content_types.replace(
                "</Types>", "".join(added_types) + "</Types>")

    used = set(_REL_ID.findall(rels))
    rels = rels.replace("</Relationships>",
                        "".join(_free_id(r, used) for r in ribbon) + "</Relationships>")

    buf = io.BytesIO()
    with zipfile.ZipFile(io.BytesIO(saved)) as out, \
            zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as fixed:
        for item in out.infolist():
            if item.filename == ROOT_RELS:
                fixed.writestr(item, rels)
            elif item.filename == CONTENT_TYPES:
                fixed.writestr(item, content_types)
            else:
                fixed.writestr(item, out.read(item.filename))
        for name, blob in missing.items():
            fixed.writestr(name, blob)
    return buf.getvalue()


def _blank(sheet, first_row: int, columns, last_row: int) -> None:
    """Clear the template's own sample data out of the columns we are about to fill."""
    for row in range(first_row, last_row + 1):
        for col in columns:
            sheet.cell(row=row, column=col).value = None


def export_xlsm(data: dict, template=None) -> tuple[bytes, list[str]]:
    """Project dict -> (.xlsm bytes, notes).

    `template` is a path, raw bytes, or any binary file object; None means the
    reference workbook in the repository. The browser build passes a path inside
    Pyodide's virtual filesystem, which is why this does not insist on a real one.
    Raises ValueError if openpyxl is missing or the template cannot be found.
    """
    try:
        import openpyxl
    except ImportError as e:  # pragma: no cover - environment-dependent
        raise ValueError("openpyxl is required for xlsm export: "
                         "pip install openpyxl") from e

    # the whole template is read into memory rather than streamed: the ribbon repair
    # after the save needs the source package a second time, and a path in Pyodide's
    # virtual filesystem or a caller's file object is not guaranteed to be re-readable
    if isinstance(template, (bytes, bytearray)):
        raw = bytes(template)
    elif template is None or isinstance(template, (str, Path)):
        src = Path(template) if template else TEMPLATE
        if not src.is_file():
            raise ValueError(f"Modbustemplate workbook not found at {src}")
        raw = src.read_bytes()
    else:
        raw = template.read()     # already a file object

    project: Project = load_project(to_yaml_dict(data))
    _refuse_unknown_datatypes(project)
    notes: list[str] = []
    wb = openpyxl.load_workbook(io.BytesIO(raw), keep_vba=True)
    try:
        notes += _sync_workbook_datatypes(wb, project, project_tables(project))
        _write_setup(wb, project, notes)
        _write_groups(wb, project)
        _write_statetexts(wb, project, notes)
        _write_points(wb, project, notes)
        buf = io.BytesIO()
        wb.save(buf)
    finally:
        wb.close()
    return _restore_ribbon(buf.getvalue(), raw), notes


def _write_setup(wb, project: Project, notes: list[str]) -> None:
    main, prot = wb["Main_Setup"], wb["Protocol_Spesific_Setup"]
    o = project.options
    main["B19"] = project.table
    main["B21"] = project.plant
    for name, cell in MAIN_FLAGS.items():
        main[cell] = bool(getattr(o, name))
    for name, cell in PROT_FLAGS.items():
        prot[cell] = bool(getattr(o, name))
    # the reserve rule is a flag plus its text; an empty text means the rule is off
    main["B13"] = o.reserve_text or None
    main["B14"] = bool(o.reserve_text)

    s = project.system
    main["B42"] = bool(s and s.units)
    main["B45"] = bool(s and s.settings)
    if not s:
        return

    units = list(s.unit_list or [])
    first = units[0] if units else s
    main["B48"] = getattr(first, "unit_id", "") or ""
    main["B51"] = getattr(first, "unit_name", "") or ""
    main["B63"] = getattr(first, "driver_addr", "") or ""
    if len(units) > 1:
        kept = getattr(first, "unit_id", "") or "the first device"
        notes.append(f"the workbook holds one device: wrote {kept} and left out "
                     f"{len(units) - 1} more ({', '.join(str(getattr(u, 'unit_id', '?')) for u in units[1:])}). "
                     f"Add them in the plant database, or keep using the JSON project.")
    main["B54"] = s.reg_type or ""
    main["B57"] = s.order_no or ""
    main["B60"] = s.owner or ""
    main["C63"] = s.driver_addr_prefix == "1_"

    c = s.comm
    if not c:
        return
    main["B10"] = c.mode == "rtu"
    main["B69"] = c.ip or ""
    main["B66"] = c.com_port or ""
    main["B72"] = int(c.baudrate or 19200) == 9600
    if int(c.baudrate or 19200) not in (9600, 19200):
        notes.append(f"the workbook's baud rate is a 9600/19200 checkbox, so "
                     f"{c.baudrate} could not be written - it now reads 19200. "
                     f"Set the real rate in the plant database.")
    main["E75"] = c.parity or "even"
    main["B78"] = int(c.stop_bits or 1) == 1
    if c.mode == "tcp" and c.port and int(c.port) != 502:
        notes.append(f"the workbook has no TCP port cell, so port {c.port} was not "
                     f"written (it assumes 502)")


def _write_groups(wb, project: Project) -> None:
    """Fill whichever of the two Groups_Setup tables the auto_groups toggle selects -
    the same choice importer.import_xlsm reads back."""
    gs = wb["Groups_Setup"]
    order_col, ref_col, alias_col = ((12, 13, 14) if project.options.auto_groups
                                     else (3, 4, 5))
    _blank(gs, GROUPS_FIRST_ROW, (order_col, ref_col, alias_col), gs.max_row)
    row = GROUPS_FIRST_ROW
    for i, g in enumerate(project.groups, start=1):
        gs.cell(row=row, column=order_col).value = g.order if g.order else i
        gs.cell(row=row, column=ref_col).value = g.name
        gs.cell(row=row, column=alias_col).value = g.alias or ""
        row += 1


def _write_statetexts(wb, project: Project, notes: list[str]) -> None:
    """Row 2 carries the state numbers; each list is a row keyed by id in column A."""
    js = wb["JSON Setup"]
    number_col = {}
    for cell in js[2]:
        if isinstance(cell.value, int):
            number_col.setdefault(cell.value, cell.column)
    last_col = max(number_col.values(), default=1)
    _blank(js, JSON_FIRST_ROW, [1] + sorted(number_col.values()), js.max_row)

    row = JSON_FIRST_ROW
    for sid, states in sorted(project.statetexts.items()):
        js.cell(row=row, column=1).value = int(sid)
        missing = []
        for number, word in sorted(states.items(), key=lambda kv: int(kv[0])):
            col = number_col.get(int(number))
            if col is None:
                missing.append(int(number))
                continue
            js.cell(row=row, column=col).value = word
        if missing:
            notes.append(f"state list {sid}: the sheet only has columns for states "
                         f"0-{max(number_col, default=0)}, so {missing} were left out")
        row += 1
    if project.statetexts and not project.options.use_json:
        notes.append("state texts were written but use_json is off, so the workbook "
                     "will ignore them until that toggle is on")
    _ = last_col


def _write_points(wb, project: Project, notes: list[str]) -> None:
    work = wb["Work"]
    columns = sorted(COL.values())
    # the template ships with an empty Work sheet, but an export of an export is
    # still a real case - clear whatever input cells are there before writing
    _blank(work, WORK_FIRST_ROW, columns, min(work.max_row, ROW_CAP))

    written = 0
    for i, p in enumerate(project.points):
        if p.synthesized:
            continue            # motherwords are the macro's to synthesize, not ours
        row = WORK_FIRST_ROW + written
        if row > ROW_CAP:
            notes.append(f"the workbook's macros only scan to row {ROW_CAP}, so "
                         f"{len(project.points) - i} point(s) were left out")
            break
        def put(name, value, _row=row):
            work.cell(row=_row, column=COL[name]).value = value

        put("group", p.group or None)
        put("datatype", p.datatype)
        put("addr", p.addr)
        put("bit", p.bit if p.bit not in ("", None) else None)
        for name in ("element_id", "system_no", "tag", "extra", "text", "unit",
                     "scale", "menu"):
            put(name, getattr(p, name) or None)
        put("alarm", (p.alarm or "").upper() or None)
        put("rw", p.rw or "r")
        put("online", 1 if p.online else None)
        put("active", p.active if p.active in (0, 1) else None)
        put("no_group", "x" if p.no_group else None)
        put("decimals", p.decimals if p.decimals is not None else None)
        put("range_min", p.range_min or None)
        put("range_max", p.range_max or None)
        put("statetext", p.statetext if p.statetext else None)
        written += 1

    dropped = sum(1 for p in project.points if p.synthesized)
    if dropped:
        notes.append(f"left out {dropped} synthesized motherword row(s) - the "
                     f"workbook's macros create those themselves")
    if any(p.update_freq for p in project.points):
        notes.append("update_freq has no column in the workbook and was dropped; "
                     "the JSON project keeps it")


def default_filename(project_table: str, plant: str) -> str:
    stem = "_".join(x for x in (plant, project_table) if x) or "modbus"
    return f"Modbustemplate_{stem}.xlsm"
