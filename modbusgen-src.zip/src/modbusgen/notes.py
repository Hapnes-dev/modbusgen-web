"""What an importer says about a conversion.

An importer note is the provenance of a converted list: what was dropped, what was
defaulted, and what the reader still has to do. Until 2026-08-26 all three were the
same thing - an undifferentiated string in one list - which had three consequences.

A note that repeats per row **floods**. Sixty points whose Read/Write column is blank
produced sixty notes saying one thing, and the GUI renders one line each; the Hyco
delivery is 1 619 points. Some families were already aggregated ("skipped N rows") and
some were not, so the treatment was inconsistent as well as loud.

A note that says **you must do something next** looked exactly like one saying a
default was applied. `plant number is not stored in SQL - set it before generating` is
not a remark: a list generated without acting on it carries the wrong plant.

And nothing could group, count or filter them, because the only structure was English.

`Note` is a `str` subclass on purpose. Every existing caller - the CLI's `print`, the
GUI's one-div-per-note, `json.dumps`, the tests that check a substring - keeps working
unchanged, while anything that wants the structure reads `.code`, `.kind` and the rest.
"""
from __future__ import annotations

# What the reader is expected to do about a note, in descending order of urgency.
DROPPED = "dropped"     # source data did not make it into the project
ACTION = "action"       # the list is not finished until the reader does something
REPAIRED = "repaired"   # the importer filled or corrected something, and says so
INFO = "info"           # context; nothing to do

KINDS = (DROPPED, ACTION, REPAIRED, INFO)


class Note(str):
    """One importer note, which is still exactly the string it always was."""

    code: str
    kind: str
    count: int
    addrs: tuple[int, ...]
    advice: str

    def __new__(cls, message: str, *, code: str, kind: str = INFO, count: int = 1,
                addrs: tuple[int, ...] = (), advice: str = "") -> "Note":
        if kind not in KINDS:
            raise ValueError(f"unknown note kind {kind!r}")
        self = super().__new__(cls, message)
        self.code = code
        self.kind = kind
        self.count = count
        self.addrs = tuple(addrs)
        self.advice = advice
        return self

    def as_dict(self) -> dict:
        return {"code": self.code, "kind": self.kind, "message": str(self),
                "count": self.count, "addrs": list(self.addrs), "advice": self.advice}


def as_dicts(notes) -> list[dict]:
    """The structured form of a note list, for callers that can use it.

    Plain strings are carried through as `info` with no code: an importer that has not
    been converted yet, or a note added by a caller, still appears in the list rather
    than vanishing from it.
    """
    out = []
    for n in notes:
        out.append(n.as_dict() if isinstance(n, Note)
                   else {"code": "", "kind": INFO, "message": str(n), "count": 1,
                         "addrs": [], "advice": ""})
    return out


def where(addrs, limit: int = 8) -> str:
    """`addr 100, 101, 102 (+57 more)` - the first few, and an honest count.

    The addresses go in the note itself because they are what the reader searches for;
    the whole set travels in `Note.addrs`, so the ones past the limit are still
    reachable rather than merely mentioned.
    """
    shown = ", ".join(str(a) for a in list(addrs)[:limit])
    more = f" (+{len(addrs) - limit} more)" if len(addrs) > limit else ""
    return f"addr {shown}{more}"
