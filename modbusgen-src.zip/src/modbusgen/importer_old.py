"""Importer for old-generation Modbustemplate workbooks (sheet set
param/group/set/Work/Variabler/Statistikk - e.g. Grundfos Magna3, Nibe, Piigab).

The old Work sheet carries inputs in columns 1-18 and the generated param/set/group
records in columns 19-39, 52-61 and 63-69. Reconstruction works from the *generated*
columns because they are complete and unambiguous: driver_id encodes function/address/
bit, driver_id_extra encodes raw type + swap + write function, and the set block holds
the hand-tuned polling. Addresses are therefore protocol addresses - the project is
written with subtract_one: false so regeneration reproduces the same driver_ids.

Datatype recovery: (read function, raw type, swap, application) -> canonical name,
resolved against data/tables/datatypes.csv. Old 32-bit rows whose extra says write
function 10 map to the same canonical datatype (the canonical table says 6/16); a note
reports how many rows carried the old '10'.
"""
from __future__ import annotations

import json
import re
from pathlib import Path

from .notes import ACTION, DROPPED, INFO, REPAIRED, Note
from .tables import Tables, unknown_datatype_notes

# generated-column indexes on the old Work sheet (1-based)
G = {"element_id": 20, "driver_id": 21, "alias_text": 22, "menu": 23,
     "application": 24, "parameter_type": 25, "att": 28, "eng_unit": 29,
     "format": 30, "range_min": 31, "range_max": 32, "scale": 33, "raw_min": 34,
     "raw_max": 35, "eng_min": 36, "eng_max": 37, "driver_id_extra": 38,
     "format_extra": 39,
     "active": 54, "onl_ind": 55, "update_freq": 56, "plant_pri": 59,
     "group_ref": 66}
IN = {"group": 1, "grp_no": 2, "alarm": 8, "no_group": 14, "decimals": 16}

REQUIRED_SHEETS = ["Work", "Variabler"]


def _s(v) -> str:
    if v is None:
        return ""
    if isinstance(v, float) and v.is_integer():
        return str(int(v))
    return str(v).strip()


def _reverse_units(tables: Tables) -> dict:
    out = {}
    for u in tables.units.values():
        out.setdefault(u.iwmac_unit.casefold(), u.unit)
    return out


def _reverse_scaling(tables: Tables) -> dict:
    out = {}
    for s in tables.scaling.values():
        key = (s.scale, s.raw_min, s.raw_max, s.eng_min, s.eng_max)
        out.setdefault(key, s.key)
    return out


def _datatype_name(read_func: str, raw: str, swap: str, application: str,
                   has_bit: bool, tables: Tables) -> str | None:
    """Reverse the canonical naming scheme and verify against the table."""
    if has_bit:
        name = {"3": "Bit_Hold", "4": "Bit_Input"}.get(read_func)
    elif read_func == "1":
        name = f"Coil_X_{swap or 'N'}"
    elif read_func == "2":
        name = f"Digital_X_{swap or 'N'}"
    elif read_func == "0":
        name = "Virt"
    else:
        table = {"3": "Hold", "4": "Input"}.get(read_func)
        pres = {"Analog values": "A", "Integral values": "I",
                "String values": "STRING"}.get(application)
        if not table or not pres:
            return None
        if pres == "STRING":
            name = "STRING"
        else:
            name = f"{pres}_{table}_{raw}_{swap or 'N'}"
    return name if name and name in tables.datatypes else None


def import_old_xlsm(path: Path) -> tuple[dict, list[str]]:
    try:
        import openpyxl
    except ImportError as e:
        raise ValueError("openpyxl is required for import: pip install openpyxl") from e

    wb = openpyxl.load_workbook(path, data_only=True, read_only=True)
    missing = [s for s in REQUIRED_SHEETS if s not in wb.sheetnames]
    if missing:
        raise ValueError(f"not an old-format Modbustemplate - missing sheet(s): "
                         f"{', '.join(missing)}")
    notes: list[str] = []
    tables = Tables()
    rev_units = _reverse_units(tables)
    rev_scale = _reverse_scaling(tables)

    var = wb["Variabler"]
    vrows = list(var.iter_rows(min_row=1, max_row=min(var.max_row, 200),
                               max_col=19, values_only=True))

    def vcell(r, c):
        return _s(vrows[r - 1][c - 1]) if r <= len(vrows) and c <= len(vrows[r - 1]) else ""

    table = ""
    plant = ""
    for i, r in enumerate(vrows, 1):
        if vcell(i, 10) == "iw_par":
            table = vcell(i, 11).lower()
        if vcell(i, 10).startswith("Eks ") or vcell(i, 10) == "Plantnummer":
            cand = vcell(i, 11) or (vcell(i + 1, 11) if i < len(vrows) else "")
            if cand and not plant:
                plant = cand
    if not re.fullmatch(r"[a-z0-9_]+", table or ""):
        fallback = re.sub(r"[^a-z0-9_]+", "_", Path(path).stem.lower()).strip("_")
        notes.append(Note(f"table name not found in Variabler - using '{fallback}'",
            code="table-name-derived", kind=REPAIRED,
            advice="Check the derived table name against the plant's existing iw_par_ tables before generating."))
        table = fallback
    if not plant:
        notes.append(Note("plant number not found in Variabler - set it before generating",
            code="plant-number-missing", kind=ACTION,
            advice="Set the plant number before generating; the old workbook did not carry one."))

    # group aliases live in Variabler cols 14-19 (date/type/view_order/ref/no/value)
    groups: dict[str, dict] = {}
    for i, r in enumerate(vrows, 1):
        if vcell(i, 15) == "group_alias" and vcell(i, 17):
            order = vcell(i, 16)
            groups[vcell(i, 17)] = {"alias": vcell(i, 19),
                                    "order": int(order) if order.isdigit() else len(groups) + 1}

    ws = wb["Work"]
    first = next(ws.iter_rows(min_row=1, max_row=1, max_col=10, values_only=True))
    if any("Mbus" in _s(v) or "grunn" in _s(v) for v in first):
        notes.append(Note("this is the Piigab M-Bus gateway variant of the old template - "
                     "its shifted column layout is not supported; only the group "
                     "aliases were imported",
            code="piigab-variant", kind=INFO,
            advice="Nothing to do. The layout differs from the standard old template and was read accordingly."))
    points: list[dict] = []
    statetexts: dict[int, dict[int, str]] = {}
    json_ids: dict[str, int] = {}
    skipped = 0
    old_write10 = 0
    membership: set[str] = set()

    for row in ws.iter_rows(min_row=2, max_row=min(ws.max_row, 5000), max_col=69,
                            values_only=True):
        def g(name, m=G):
            col = m[name]
            return _s(row[col - 1]) if len(row) >= col else ""
        did = g("driver_id")
        if not re.fullmatch(r"0_\d+_\d+(\.[\d#]+)?", did):
            if g("element_id") or _s(row[0]):
                skipped += 1
            continue
        m = re.fullmatch(r"0_(\d+)_(\d+)(?:\.([\d#]+))?", did)
        read_func, addr, bit = m.group(1), int(m.group(2)), m.group(3)

        extra = g("driver_id_extra")
        raw = swap = ""
        xm = re.fullmatch(r"\d+_\d+_([A-Z0-9]+)_([A-Z])_(.+)", extra or "")
        if xm:
            raw, swap = xm.group(1), xm.group(2)
            if re.match(r"10_", xm.group(3)):
                old_write10 += 1
        datatype = _datatype_name(read_func, raw or "I16", swap or "N",
                                  g("application"), bit is not None, tables)
        if datatype is None:
            skipped += 1
            notes_key = f"row with driver_id {did}: unresolvable datatype (func " \
                        f"{read_func}, raw {raw or '?'}, app {g('application') or '?'})"
            notes.append(notes_key)
            continue

        group = g("group_ref") or _s(row[IN["group"] - 1])
        p: dict = {"group": group, "datatype": datatype, "addr": addr,
                   "text": g("alias_text")}
        if bit is not None:
            p["bit"] = int(bit) if bit.isdigit() else bit
        att = g("att").lower()
        p["rw"] = "rw" if att in ("rw", "vrw") else "r"
        default_eid = f"{group}_{did}"
        if g("element_id") and g("element_id") != default_eid:
            p["element_id"] = g("element_id")
        if g("menu"):
            p["menu"] = g("menu")
        alarm = (g("plant_pri") or _s(row[IN["alarm"] - 1])).upper()
        if alarm in ("A", "B", "C", "N"):
            p["alarm"] = alarm
        if g("eng_unit"):
            unit = rev_units.get(g("eng_unit").casefold())
            if unit:
                p["unit"] = unit
            else:
                notes.append(Note(f"{p['text'] or did}: eng_unit '{g('eng_unit')}' not in "
                             f"the unit table - left empty",
                    code="unit-unmapped", kind=DROPPED,
                    advice="The unit is gone from that point. Add the spelling to data/tables/units.csv if it is real, or set an existing key meaning the same thing."))
        fm = re.fullmatch(r"%\.(\d)f", g("format"))
        if fm and int(fm.group(1)) <= 3:
            p["decimals"] = int(fm.group(1))
        scale_key = rev_scale.get((g("scale"), g("raw_min"), g("raw_max"),
                                   g("eng_min"), g("eng_max")))
        if scale_key:
            p["scale"] = scale_key
        elif g("scale"):
            notes.append(Note(f"{p['text'] or did}: scaling "
                         f"({g('scale')},{g('raw_min')}..{g('raw_max')} -> "
                         f"{g('eng_min')}..{g('eng_max')}) has no table key - dropped",
                code="scale-unmapped", kind=DROPPED,
                advice="That point now reads raw. Add the factor to data/tables/scaling.csv, or check whether the delivered scaling was itself wrong."))
        for name, col in (("range_min", G["range_min"]), ("range_max", G["range_max"])):
            if len(row) >= col and _s(row[col - 1]):
                p[name] = _s(row[col - 1])
        if g("onl_ind") == "1":
            p["online"] = True
        if g("active") == "0":
            p["active"] = 0
        # keep hand-tuned polling when it differs from the derived value
        derived = "slow" if p["rw"] == "rw" or datatype.startswith(
            ("Coil", "Digital", "Bit")) else "norm"
        if g("update_freq") and g("update_freq") != derived:
            p["update_freq"] = g("update_freq")
        if _s(row[IN["no_group"] - 1]).lower() == "x" or not g("group_ref"):
            if not g("group_ref"):
                p["no_group"] = True
        else:
            membership.add(default_eid)
        fx = g("format_extra")
        if fx.startswith("{"):
            if fx not in json_ids:
                try:
                    states = {int(n): v["t"] for n, v in
                              json.loads(fx)["v"].items()}
                    sid = len(json_ids) + 1
                    json_ids[fx] = sid
                    statetexts[sid] = states
                except Exception:
                    notes.append(Note(f"{p['text'] or did}: unparseable format_extra "
                                 f"JSON - dropped",
                        code="statetext-unparseable", kind=DROPPED,
                        advice="That point lost its state texts and will show raw numbers. Re-author the list in `statetexts` from the device document."))
                    json_ids[fx] = 0
            if json_ids[fx]:
                p["statetext"] = json_ids[fx]
        points.append(p)
    wb.close()

    # old lists pair Motherword rows with value rows on the same register (same
    # element_id - only one survived the DB unique key anyway), and sometimes repeat
    # the Motherword itself; keep value rows, keep the first motherword only when no
    # value row shares the register
    seen_words: dict[int, str] = {}
    for p in points:
        if "bit" not in p:
            kind = "value" if p.get("text") != "Motherword" else "mother"
            if seen_words.get(p["addr"]) != "value":
                seen_words[p["addr"]] = kind if seen_words.get(p["addr"]) != "value" else "value"
            if kind == "value":
                seen_words[p["addr"]] = "value"
    kept, dropped = [], 0
    used_mother_addr: set[int] = set()
    for p in points:
        if p.get("text") == "Motherword" and "bit" not in p:
            if seen_words.get(p["addr"]) == "value" or p["addr"] in used_mother_addr:
                dropped += 1
                continue
            used_mother_addr.add(p["addr"])
        kept.append(p)
    points = kept
    if dropped:
        notes.append(Note(f"dropped {dropped} redundant Motherword row(s) (duplicate of a "
                     f"value row or a repeated motherword on the same register)",
            code="motherwords-dropped", kind=REPAIRED,
            advice="Nothing to do. modbusgen synthesizes motherwords, so the delivered duplicates were not needed."))

    if skipped:
        notes.append(Note(f"skipped {skipped} row(s) without a valid generated driver_id "
                     f"(#N/A leftovers or never-generated rows)",
            code="rows-skipped", kind=DROPPED,
            advice="Reconcile that count against the source workbook before claiming the list is complete (docs/11 coverage accounting)."))
    if old_write10:
        notes.append(Note(f"{old_write10} 32-bit row(s) used the old tool's write function "
                     f"10; regeneration will write function 6/16 per the canonical "
                     f"datatype table",
            code="write-function-corrected", kind=REPAIRED,
            advice="The old tool wrote 10 where the driver wants 16, and 16 is correct (docs/15). The regenerated script will differ from the delivered one on those rows, deliberately."))
    notes.append(Note("addresses imported as protocol addresses (from driver_id); "
                 "subtract_one is set to false",
        code="addresses-are-protocol", kind=ACTION,
        advice="subtract_one is false because the driver_id already holds protocol addresses. Do not turn it on and do not adjust the addresses by hand."))

    used = {p["group"] for p in points if p.get("group")}
    for name in sorted(used - set(groups)):
        groups[name] = {"alias": name, "order": len(groups) + 1}
        notes.append(Note(f"group '{name}' had no alias row in Variabler - added with its "
                     f"own name as alias",
            code="group-alias-added", kind=REPAIRED,
            advice="The key is standing in as the operator-facing name. Rename each alias before shipping."))

    options = {"subtract_one": False,
               "force_active": not any(p.get("active") == 0 for p in points),
               "proper_case_states": False}   # state words are already display-ready
    notes += unknown_datatype_notes(points)

    data = {"table": table, "plant": plant, "options": options, "system": None,
            "groups": groups, "statetexts": statetexts, "points": points}
    return data, notes
