"""Importer for old-generation Modbustemplate workbooks (sheet set
param/group/set/Work/Variabler/Statistikk - e.g. Grundfos Magna3, Nibe, Piigab).

The old Work sheet carries inputs in columns 1-18 and the generated param/set/group
records in columns 19-39, 52-61 and 63-69. Reconstruction works from the *generated*
columns because they are complete and unambiguous: driver_id encodes function/address/
bit, driver_id_extra encodes raw type + swap + write function, and the set block holds
the hand-tuned polling. Addresses are therefore protocol addresses - the project is
written with subtract_one: false so regeneration reproduces the same driver_ids.

Datatype recovery: the row of data/tables/datatypes.csv that agrees with every column
the generated record carries - read function, raw type and swaps, write function,
application, parameter type (_match_datatype). Old 32-bit rows whose extra says write
function 10 map to the same canonical datatype (the canonical table says 6/16); a note
reports how many rows carried the old '10'. A record no shipped row agrees with is
rebuilt as a project datatype row from those same columns (rebuild_datatype), and only a
record holding a value the driver cannot read is dropped - counted once, as unresolvable.
"""
from __future__ import annotations

import dataclasses
import json
import re
from pathlib import Path

from .model import Point
from .notes import ACTION, DROPPED, INFO, REPAIRED, Note
from .rules import update_freq as derive_update_freq
from .tables import Datatype, Tables, unknown_datatype_notes

# generated-column indexes on the old Work sheet (1-based)
G = {"element_id": 20, "driver_id": 21, "alias_text": 22, "menu": 23,
     "application": 24, "parameter_type": 25, "att": 28, "eng_unit": 29,
     "format": 30, "range_min": 31, "range_max": 32, "scale": 33, "raw_min": 34,
     "raw_max": 35, "eng_min": 36, "eng_max": 37, "driver_id_extra": 38,
     "format_extra": 39,
     "active": 54, "onl_ind": 55, "update_freq": 56, "plant_pri": 59,
     "group_ref": 66}
IN = {"group": 1, "grp_no": 2, "alarm": 8, "no_group": 14, "decimals": 16}

REQUIRED_SHEETS = ["Work", "Variabler"]


def _s(v) -> str:
    if v is None:
        return ""
    if isinstance(v, float) and v.is_integer():
        return str(int(v))
    return str(v).strip()


def _reverse_units(tables: Tables) -> dict:
    out = {}
    for u in tables.units.values():
        out.setdefault(u.iwmac_unit.casefold(), u.unit)
    return out


def _reverse_scaling(tables: Tables) -> dict:
    out = {}
    for s in tables.scaling.values():
        key = (s.scale, s.raw_min, s.raw_max, s.eng_min, s.eng_max)
        out.setdefault(key, s.key)
    return out


# driver_id_extra as rules.driver_id_extra writes it: the read half
# <func>_<addr>_<raw>_<swap>, then the write half <func>_<addr>_<raw>_<swap> for a
# writable row or -_-_-_- for a read-only one. Bit rows and non-bit vr/vrw rows have none.
# Raw types are not all upper case (rU16, rI16).
_EXTRA = re.compile(r"\d+_\d+_([A-Za-z0-9]+)_([A-Za-z])_"
                    r"(?:(\d+)_\d+_[A-Za-z0-9]+_([A-Za-z])|-_-_-_-)")


def parse_extra(extra: str) -> dict:
    """The datatype columns a driver_id_extra carries, {} when it carries none."""
    m = _EXTRA.fullmatch(extra or "")
    if not m:
        return {}
    facts = {"raw": m.group(1), "read_swap": m.group(2)}
    if m.group(3) is not None:
        facts.update(write_func=m.group(3), write_swap=m.group(4))
    return facts


def _bit_only(dt) -> bool:
    """Bit_* and Nibble_*: register rows with no raw type of their own."""
    return dt.read_func in ("3", "4") and not dt.raw_type


def _match_datatype(tables: Tables, read_func: str, application: str, *,
                    bit: str | None = None, parameter_type: str | None = None,
                    raw: str | None = None, read_swap: str | None = None,
                    write_func: str | None = None,
                    write_swap: str | None = None) -> tuple[str | None, list[str]]:
    """The datatype a generated record came from -> (key, columns it disagrees on).

    A generated row carries most of its datatype's table row: the read function in
    driver_id, raw type and swaps (and the write function, when writable) in
    driver_id_extra, application and parameter type as columns of their own. The key
    used to be rebuilt from the naming pattern instead, and 22 of the 136 rows have
    names the pattern cannot produce - STR8 came back as STRING (function 3, I16),
    rU16 as I16, a nibble as Bit_*, all silently. So the row is chosen by what the
    record says, never by its name.

    Read function, raw type, read swap and application must agree, or nothing
    matches and the caller reports the row unresolvable rather than guessing a key.
    Parameter type and the write half may disagree - the Excel template writes
    function 6 and older tools 10 on 32-bit rows where the table says 16 - and the
    closest row wins, with the columns it differs on returned so the caller can say
    the regenerated row will differ there.

    What the record does not carry is settled by preference, then table order: a bit
    row is a Bit_* row, or a Nibble_* row when the bit carries '#' (start#length); a
    row with no extra reads I16 without swap, as it always did; and the table's own
    duplicates (FLOAT is A_Hold_I16_N in every column but the name) resolve to the
    first, canonically named row - nothing in the SQL can tell them apart.
    """
    has_bit = bit is not None
    nibble = has_bit and "#" in bit
    found = []
    for index, dt in enumerate(tables.datatypes.values()):
        if dt.read_func != read_func or dt.application != application:
            continue
        if not has_bit and _bit_only(dt):
            continue
        # a row with no raw type of its own (Bit_*, Nibble_*, Virt) is not refuted by
        # an extra's raw type - generated bit rows carry none, but a hand-made one may
        if raw is not None and dt.raw_type and (dt.raw_type, dt.read_swap) != (raw, read_swap):
            continue
        differs = [label for label, mine, theirs in (
            ("parameter type", dt.parameter_type, parameter_type),
            ("write function", dt.write_func, write_func),
            ("write swap", dt.write_swap, write_swap)) if theirs is not None and mine != theirs]
        if has_bit and _bit_only(dt):
            # the one of Bit_*/Nibble_* the '#' asks for; any other register row - a bit
            # read out of an I_Hold_* word - before the other one
            preference = 0 if dt.name.casefold().startswith("nibble") == nibble else 2
        elif has_bit:
            preference = 1
        else:
            preference = 0 if (raw is not None
                               or (dt.raw_type, dt.read_swap) == ("I16", "N")) else 1
        found.append((len(differs), preference, index, dt.name, differs))
    if not found:
        return None, []
    _n, _pref, _index, name, differs = min(found)
    return name, differs


def few(values, limit: int = 6) -> str:
    """The distinct values, a few of them, and an honest count of the rest."""
    seen = sorted(set(values))
    head = ", ".join(seen[:limit])
    return head + (f" (+{len(seen) - limit} more)" if len(seen) > limit else "")


# What a rebuilt datatype row may say: the values the IWMAC driver's own configuration
# string carries (docs/15 sections 2-3) and the four applications the tables know. A
# record outside them is not a datatype nobody named but a row nothing can read, and
# stays unresolvable.
_READ_FUNCS = {"0", "1", "2", "3", "4"}
_WRITE_FUNCS = {"", "5", "6", "15", "16"}
_SWAPS = {"", "N", "R", "W"}
_APPLICATION_LETTER = {"Analog values": "A", "Integral values": "I", "Digital IO": "D",
                       "String values": "S"}
_AREA = {"0": "Virt", "1": "Coil", "2": "Digital", "3": "Hold", "4": "Input"}


def rebuild_datatype(tables: Tables, rebuilt: dict[str, Datatype], read_func: str,
                     application: str, parameter_type: str, facts: dict) -> str | None:
    """A project datatype row for a record no shipped row describes -> its name.

    A project may define datatypes of its own (the `datatypes` block), and its script
    then carries rows no shipped key matches. They used to be dropped as unresolvable,
    so a list that generated could not be read back (review, 2026-10-24). The record
    carries every column that reaches the script - the read function in driver_id, raw
    type, swaps and write function in driver_id_extra, application and parameter type as
    columns - so the row is rebuilt from them, as import-xlsm carries a workbook's own
    rows. Only the name is not in the script: it is built the house way,
    <application>_<area>_<raw>_<swap> (D_Hold_U16_N), with a suffix where that is taken.

    A read-only record says nothing about the write half, so it joins a row that has one;
    a writable record gives a row rebuilt from read-only records its write half. Returns
    None, and adds nothing, when a column holds a value the driver cannot read.
    """
    raw, read_swap = facts.get("raw", ""), facts.get("read_swap", "")
    knows_write = "write_func" in facts
    write_func = facts.get("write_func", "") if knows_write else ""
    write_swap = facts.get("write_swap", "") if knows_write else ""
    raws = {dt.raw_type for dt in tables.datatypes.values()}
    if (read_func not in _READ_FUNCS or application not in _APPLICATION_LETTER
            or raw not in raws or write_func not in _WRITE_FUNCS
            or read_swap not in _SWAPS or write_swap not in _SWAPS):
        return None
    for name, dt in rebuilt.items():
        if (dt.read_func, dt.raw_type, dt.read_swap, dt.application, dt.parameter_type) != \
                (read_func, raw, read_swap, application, parameter_type):
            continue
        if not knows_write or (dt.write_func, dt.write_swap) == (write_func, write_swap):
            return name
        if not dt.write_func and not dt.write_swap:
            rebuilt[name] = dataclasses.replace(dt, write_func=write_func,
                                                write_swap=write_swap, rw_hint="rw")
            return name
    base = (f"{_APPLICATION_LETTER[application]}_{_AREA[read_func]}_{raw or 'X'}_"
            f"{read_swap or 'N'}")
    name, n = base, 1
    taken = {k.casefold() for k in rebuilt}
    while name in tables.datatypes or name.casefold() in taken:
        n += 1
        name = f"{base}_{n}"
    rebuilt[name] = Datatype(name=name, read_func=read_func, write_func=write_func,
                             raw_type=raw, read_swap=read_swap, write_swap=write_swap,
                             application=application, parameter_type=parameter_type,
                             rw_hint="rw" if write_func else "r",
                             default_group="dio" if application == "Digital IO" else "aio")
    return name


def datatype_rows(rebuilt: dict[str, Datatype]) -> dict[str, dict]:
    """The project's `datatypes` block for the rebuilt rows - every column but the name,
    which is the key."""
    return {name: {f.name: getattr(dt, f.name) for f in dataclasses.fields(Datatype)
                   if f.name != "name"} for name, dt in rebuilt.items()}


def rebuilt_datatypes_note(rows: dict[str, list[str]], source: str) -> Note | None:
    """One note for the rows rebuild_datatype carried: which key, and which records."""
    if not rows:
        return None
    n = sum(len(v) for v in rows.values())
    detail = "; ".join(f"{name} (driver_id {few(dids, 3)})" for name, dids in rows.items())
    return Note(
        f"{n} row(s) matched no shipped datatype and were rebuilt from their own {source} "
        f"columns as {len(rows)} project datatype row(s) in `datatypes`: {detail}",
        code="datatypes-rebuilt", kind=REPAIRED, count=n,
        advice="The script carries a datatype's columns, not its name, so the name is "
               "built from them. Rename a row if the house has a name for it, and check "
               "it against docs/15 before shipping: it is what was delivered, not proof "
               "that the driver reads it right.")


def unresolvable_note(dids: list[str]) -> Note:
    """The rows that matched no datatype and could not be rebuilt - counted here only,
    never again as skipped rows."""
    return Note(
        f"{len(dids)} row(s) had an unresolvable datatype and were skipped "
        f"- driver_id {few(dids)}", code="datatype-unresolvable",
        kind=DROPPED, count=len(dids),
        advice="Those points are not in the project at all. Their function, raw type, "
               "swap or application is a value the driver does not read, so no datatype "
               "can describe them: re-author them from the device document rather than "
               "guessing a key.")


def formats_dropped_note(lost: list[str]) -> Note:
    """Display formats with no decimals equivalent - one note for the family."""
    return Note(
        f"{len(lost)} point(s) had a display format with no decimals "
        f"equivalent - dropped ({few(lost)})", code="format-unmapped",
        kind=DROPPED, count=len(lost),
        advice="Only %.0f to %.3f map onto the decimals field. Those points now "
               "have no display format; set decimals 0-3 where the delivery meant "
               "one.")


def nearest_datatype_note(near: list[tuple[str, list[str]]]) -> Note | None:
    """One note for the rows _match_datatype could only match on the closest row.

    `near` holds (driver_id, columns the chosen row differs on) per row."""
    if not near:
        return None
    by_column: dict[str, list[str]] = {}
    for did, differs in near:
        for column in differs:
            by_column.setdefault(column, []).append(did)
    detail = "; ".join(f"{column} on {len(dids)} (driver_id {few(dids)})"
                       for column, dids in by_column.items())
    return Note(
        f"{len(near)} row(s) matched no datatype on every column they carry - imported as "
        f"the closest key, so the regenerated rows take the table's value for: {detail}",
        code="datatype-nearest", kind=REPAIRED, count=len(near),
        advice="The delivery and data/tables/datatypes.csv disagree on those columns. "
               "Check the device document for which is right before generating: the "
               "regenerated rows follow the table, not the delivery.")


def rw_from_att(att: str, has_bit: bool) -> str:
    """A point's rw from a delivered att.

    A bit row's att is derived - vr or vrw from r or rw (rules.att) - so it maps back.
    On any other row att is the rw column verbatim, and a vr or vrw there is what the
    author wrote: reading it as r or rw changed the regenerated att, freq and save
    columns of the row."""
    att = (att or "").strip().lower()
    if not has_bit and att in ("r", "rw", "vr", "vrw"):
        return att
    return "rw" if "w" in att else "r"


def drop_redundant_motherwords(points: list[dict], tables: Tables) -> tuple[list[dict], int]:
    """Old lists pair Motherword rows with value rows on the same register - same
    driver_id, often the same element_id, so only one survived the database's unique
    key anyway - and sometimes repeat the Motherword itself. Keep value rows, and the
    first Motherword of a register only when no value row polls it; validation
    rejects the pair as a duplicate driver_id otherwise. A register is its read
    function and address: holding 10 and input 10 are two words."""
    def word(p):
        dt = tables.datatypes.get(p.get("datatype", ""))
        return (dt.read_func if dt else "", p["addr"])

    valued = {word(p) for p in points
              if "bit" not in p and p.get("text") != "Motherword"}
    kept, dropped, mothered = [], 0, set()
    for p in points:
        if p.get("text") == "Motherword" and "bit" not in p:
            if word(p) in valued or word(p) in mothered:
                dropped += 1
                continue
            mothered.add(word(p))
        kept.append(p)
    return kept, dropped


def motherwords_dropped_note(dropped: int) -> Note:
    return Note(f"dropped {dropped} redundant Motherword row(s) (duplicate of a "
                f"value row or a repeated motherword on the same register)",
                code="motherwords-dropped", kind=REPAIRED, count=dropped,
                advice="Nothing to do. modbusgen synthesizes motherwords, so the "
                       "delivered duplicates were not needed.")


def keep_unit(eng_unit: str, rev_units: dict, tables: Tables,
              custom: list[str], respelled: list[str]) -> str:
    """The project unit for a delivered eng_unit.

    The table's own spelling maps back to its key. Anything else is kept as typed:
    generation writes a unit the table does not know verbatim (rules.generate), so a
    custom unit is a legitimate value and dropping it lost data for nothing. The one
    thing generation cannot write back is text that is itself a table key spelled
    differently in the table - a delivered 'C' regenerates as '&deg;C' - so those are
    collected apart from the plain custom units."""
    key = rev_units.get(eng_unit.casefold())
    if key:
        return key
    known = tables.units.get(eng_unit)
    if known is not None and known.iwmac_unit != eng_unit:
        respelled.append(f"'{eng_unit}' -> '{known.iwmac_unit}'")
    else:
        custom.append(eng_unit)
    return eng_unit


def unit_notes(custom: list[str], respelled: list[str]) -> list[Note]:
    """The notes for what keep_unit collected - one per family, not one per point."""
    notes = []
    if custom:
        notes.append(Note(
            f"{len(custom)} point(s) had an eng_unit outside the unit table - kept as a "
            f"custom unit ({few(custom)})", code="unit-unmapped", kind=INFO,
            count=len(custom),
            advice="Nothing to do: generation writes a custom unit as typed. Add the "
                   "spelling to data/tables/units.csv if it is a unit the house uses."))
    if respelled:
        notes.append(Note(
            f"{len(respelled)} point(s) had an eng_unit that is a unit-table key, which "
            f"generation writes in the table's spelling ({few(respelled)})",
            code="unit-respelled", kind=REPAIRED, count=len(respelled),
            advice="The regenerated rows carry the table's spelling, not the delivered "
                   "one. That is normally the intended unit; check it if the plant reads "
                   "the delivered text."))
    return notes


def import_old_xlsm(path: Path) -> tuple[dict, list[str]]:
    try:
        import openpyxl
    except ImportError as e:
        raise ValueError("openpyxl is required for import: pip install openpyxl") from e

    wb = openpyxl.load_workbook(path, data_only=True, read_only=True)
    missing = [s for s in REQUIRED_SHEETS if s not in wb.sheetnames]
    if missing:
        raise ValueError(f"not an old-format Modbustemplate - missing sheet(s): "
                         f"{', '.join(missing)}")
    notes: list[str] = []
    tables = Tables()
    rev_units = _reverse_units(tables)
    rev_scale = _reverse_scaling(tables)

    var = wb["Variabler"]
    vrows = list(var.iter_rows(min_row=1, max_row=min(var.max_row, 200),
                               max_col=19, values_only=True))

    def vcell(r, c):
        return _s(vrows[r - 1][c - 1]) if r <= len(vrows) and c <= len(vrows[r - 1]) else ""

    table = ""
    plant = ""
    for i, r in enumerate(vrows, 1):
        if vcell(i, 10) == "iw_par":
            table = vcell(i, 11).lower()
        if vcell(i, 10).startswith("Eks ") or vcell(i, 10) == "Plantnummer":
            cand = vcell(i, 11) or (vcell(i + 1, 11) if i < len(vrows) else "")
            if cand and not plant:
                plant = cand
    if not re.fullmatch(r"[a-z0-9_]+", table or ""):
        fallback = re.sub(r"[^a-z0-9_]+", "_", Path(path).stem.lower()).strip("_")
        notes.append(Note(f"table name not found in Variabler - using '{fallback}'",
            code="table-name-derived", kind=REPAIRED,
            advice="Check the derived table name against the plant's existing iw_par_ tables before generating."))
        table = fallback
    if not plant:
        notes.append(Note("plant number not found in Variabler - set it before generating",
            code="plant-number-missing", kind=ACTION,
            advice="Set the plant number before generating; the old workbook did not carry one."))

    # group aliases live in Variabler cols 14-19 (date/type/view_order/ref/no/value)
    groups: dict[str, dict] = {}
    for i, r in enumerate(vrows, 1):
        if vcell(i, 15) == "group_alias" and vcell(i, 17):
            order = vcell(i, 16)
            groups[vcell(i, 17)] = {"alias": vcell(i, 19),
                                    "order": int(order) if order.isdigit() else len(groups) + 1}

    ws = wb["Work"]
    first = next(ws.iter_rows(min_row=1, max_row=1, max_col=10, values_only=True))
    if any("Mbus" in _s(v) or "grunn" in _s(v) for v in first):
        notes.append(Note("this is the Piigab M-Bus gateway variant of the old template - "
                     "its shifted column layout is not supported; only the group "
                     "aliases were imported",
            code="piigab-variant", kind=INFO,
            advice="Nothing to do. The layout differs from the standard old template and was read accordingly."))
    points: list[dict] = []
    statetexts: dict[int, dict[int, str]] = {}
    json_ids: dict[str, int] = {}
    skipped = 0
    old_write10 = 0
    near: list[tuple[str, list[str]]] = []
    custom_units: list[str] = []
    respelled_units: list[str] = []
    membership: set[str] = set()
    unresolved: list[str] = []
    rebuilt: dict = {}
    rebuilt_rows: dict[str, list[str]] = {}
    lost_formats: list[str] = []

    for row in ws.iter_rows(min_row=2, max_row=min(ws.max_row, 5000), max_col=69,
                            values_only=True):
        def g(name, m=G):
            col = m[name]
            return _s(row[col - 1]) if len(row) >= col else ""
        did = g("driver_id")
        if not re.fullmatch(r"0_\d+_\d+(\.[\d#]+)?", did):
            if g("element_id") or _s(row[0]):
                skipped += 1
            continue
        m = re.fullmatch(r"0_(\d+)_(\d+)(?:\.([\d#]+))?", did)
        read_func, addr, bit = m.group(1), int(m.group(2)), m.group(3)

        facts = parse_extra(g("driver_id_extra"))
        if facts.get("write_func") == "10":
            old_write10 += 1
        datatype, differs = _match_datatype(
            tables, read_func, g("application"), bit=bit,
            parameter_type=g("parameter_type") or None, **facts)
        if datatype is None:
            # counted once: as a rebuilt row, or as unresolvable - never also as skipped,
            # which used to report one row twice (review, 2026-10-24)
            datatype = rebuild_datatype(tables, rebuilt, read_func, g("application"),
                                        g("parameter_type"), facts)
            if datatype is None:
                unresolved.append(did)
                continue
            rebuilt_rows.setdefault(datatype, []).append(did)
        if facts.get("write_func") == "10":       # write-function-corrected says it
            differs = [d for d in differs if d != "write function"]
        if differs:
            near.append((did, differs))

        group = g("group_ref") or _s(row[IN["group"] - 1])
        p: dict = {"group": group, "datatype": datatype, "addr": addr,
                   "text": g("alias_text")}
        if bit is not None:
            p["bit"] = int(bit) if bit.isdigit() else bit
        p["rw"] = rw_from_att(g("att"), bit is not None)
        default_eid = f"{group}_{did}"
        if g("element_id") and g("element_id") != default_eid:
            p["element_id"] = g("element_id")
        if g("menu"):
            p["menu"] = g("menu")
        alarm = (g("plant_pri") or _s(row[IN["alarm"] - 1])).upper()
        if alarm in ("A", "B", "C", "N"):
            p["alarm"] = alarm
        if g("eng_unit"):
            p["unit"] = keep_unit(g("eng_unit"), rev_units, tables,
                                  custom_units, respelled_units)
        fm = re.fullmatch(r"%\.(\d)f", g("format"))
        if fm and int(fm.group(1)) <= 3:
            p["decimals"] = int(fm.group(1))
        elif g("format"):
            lost_formats.append(g("format"))       # as sqlimport says it, not silently
        scale_key = rev_scale.get((g("scale"), g("raw_min"), g("raw_max"),
                                   g("eng_min"), g("eng_max")))
        if scale_key:
            p["scale"] = scale_key
        elif g("scale"):
            notes.append(Note(f"{p['text'] or did}: scaling "
                         f"({g('scale')},{g('raw_min')}..{g('raw_max')} -> "
                         f"{g('eng_min')}..{g('eng_max')}) has no table key - dropped",
                code="scale-unmapped", kind=DROPPED,
                advice="That point now reads raw. Add the factor to data/tables/scaling.csv, or check whether the delivered scaling was itself wrong."))
        for name, col in (("range_min", G["range_min"]), ("range_max", G["range_max"])):
            if len(row) >= col and _s(row[col - 1]):
                p[name] = _s(row[col - 1])
        if g("onl_ind") == "1":
            p["online"] = True
        if g("active") == "0":
            p["active"] = 0
        # keep hand-tuned polling when it differs from the derived value - derived the
        # way generate derives it, so a string row (no freq) or a vrw row (slow) is not
        # read as an override, and a real one is not mistaken for the default
        stub = Point(addr=addr, rw=p["rw"], bit=p.get("bit"), text=p["text"])
        dt = tables.datatypes.get(datatype) or rebuilt[datatype]
        derived = derive_update_freq(stub, dt.application)
        if g("update_freq") and g("update_freq") != derived:
            p["update_freq"] = g("update_freq")
        if _s(row[IN["no_group"] - 1]).lower() == "x" or not g("group_ref"):
            if not g("group_ref"):
                p["no_group"] = True
        else:
            membership.add(default_eid)
        fx = g("format_extra")
        if fx.startswith("{"):
            if fx not in json_ids:
                try:
                    states = {int(n): v["t"] for n, v in
                              json.loads(fx)["v"].items()}
                    sid = len(json_ids) + 1
                    json_ids[fx] = sid
                    statetexts[sid] = states
                except Exception:
                    notes.append(Note(f"{p['text'] or did}: unparseable format_extra "
                                 f"JSON - dropped",
                        code="statetext-unparseable", kind=DROPPED,
                        advice="That point lost its state texts and will show raw numbers. Re-author the list in `statetexts` from the device document."))
                    json_ids[fx] = 0
            if json_ids[fx]:
                p["statetext"] = json_ids[fx]
        points.append(p)
    wb.close()

    # the rebuilt rows join the lookups below, or their points would read as unknown
    known = tables.extended(rebuilt)
    points, dropped = drop_redundant_motherwords(points, known)
    if dropped:
        notes.append(motherwords_dropped_note(dropped))
    notes += unit_notes(custom_units, respelled_units)
    if (note := nearest_datatype_note(near)):
        notes.append(note)
    if unresolved:
        notes.append(unresolvable_note(unresolved))
    if (note := rebuilt_datatypes_note(rebuilt_rows, "generated")):
        notes.append(note)
    if lost_formats:
        notes.append(formats_dropped_note(lost_formats))

    if skipped:
        notes.append(Note(f"skipped {skipped} row(s) without a valid generated driver_id "
                     f"(#N/A leftovers or never-generated rows)",
            code="rows-skipped", kind=DROPPED,
            advice="Reconcile that count against the source workbook before claiming the list is complete (docs/11 coverage accounting)."))
    if old_write10:
        notes.append(Note(f"{old_write10} 32-bit row(s) used the old tool's write function "
                     f"10; regeneration will write function 6/16 per the canonical "
                     f"datatype table",
            code="write-function-corrected", kind=REPAIRED,
            advice="The old tool wrote 10 where the driver wants 16, and 16 is correct (docs/15). The regenerated script will differ from the delivered one on those rows, deliberately."))
    notes.append(Note("addresses imported as protocol addresses (from driver_id); "
                 "subtract_one is set to false",
        code="addresses-are-protocol", kind=ACTION,
        advice="subtract_one is false because the driver_id already holds protocol addresses. Do not turn it on and do not adjust the addresses by hand."))

    used = {p["group"] for p in points if p.get("group")}
    for name in sorted(used - set(groups)):
        groups[name] = {"alias": name, "order": len(groups) + 1}
        notes.append(Note(f"group '{name}' had no alias row in Variabler - added with its "
                     f"own name as alias",
            code="group-alias-added", kind=REPAIRED,
            advice="The key is standing in as the operator-facing name. Rename each alias before shipping."))

    options = {"subtract_one": False,
               "force_active": not any(p.get("active") == 0 for p in points),
               "proper_case_states": False}   # state words are already display-ready
    # the ranges were carried and then never written: generation writes range_min and
    # range_max only with include_minmax (Prot!B42), as sqlimport already knew
    if any("range_min" in p or "range_max" in p for p in points):
        options["include_minmax"] = True
    notes += unknown_datatype_notes(points, known)

    data = {"table": table, "plant": plant, "options": options, "system": None,
            "groups": groups, "statetexts": statetexts,
            "datatypes": datatype_rows(rebuilt), "points": points}
    return data, notes
