"""Derivation rules: one Work row -> param / set / group records.

Direct reimplementation of Update_work_param_grp_set and its helpers
(docs/04-generation-rules.md). Deliberate divergences from the Excel tool are marked
DIVERGENCE and catalogued in docs/10-generator-tool.md.
"""
from __future__ import annotations

from dataclasses import dataclass

from .model import Point, Project
from .statetext import state_json, state_plain
from .tables import Tables


@dataclass
class ParamRecord:      # iw_par_<t>_param, column order = SQL order (docs/03)
    row_date: str
    element_id: str
    driver_id: str
    alias_text: str
    menu: str
    application: str
    parameter_type: str
    factory_setting: str
    grp: str
    att: str
    eng_unit: str
    format: str
    range_min: str
    range_max: str
    scale: str
    raw_min: str
    raw_max: str
    eng_min: str
    eng_max: str
    driver_id_extra: str
    format_extra: str


@dataclass
class SetRecord:        # iw_set_<t>
    row_date: str
    element_id: str
    active: str
    onl_ind: str
    update_freq: str
    save_data: str
    save_freq: str
    plant_pri: str
    sys_pri: str
    alarm_type: str


@dataclass
class GroupRecord:      # iw_par_<t>_groups
    row_date: str
    type: str
    view_order: str
    ref: str
    value: str


@dataclass
class RunResult:
    params: list[ParamRecord]
    sets: list[SetRecord]
    groups: list[GroupRecord]          # per-point membership rows
    group_aliases: list[GroupRecord]   # default_link + group_alias rows
    points: list[Point]                # points after auto-fill/synthesis (for reporting)


MOTHER_DATATYPE_BY_READ_FUNC = {"3": "I_Hold_U16_N", "4": "I_Input_U16_N"}


def apply_auto_groups(project: Project, tables: Tables) -> None:
    """find_auto_groups: fill empty group from the datatype's default group;
    optionally move alarm rows to 'alm' (docs/04 section 4.4)."""
    if not project.options.auto_groups:
        return
    for p in project.points:
        dt = tables.datatypes.get(p.datatype)
        if dt is None:
            continue
        if not p.group:
            p.group = dt.default_group
        if project.options.alarms_to_alm and (p.alarm or "") in ("A", "B", "C", "N"):
            p.group = "alm"


def synthesize_motherwords(project: Project, tables: Tables) -> list[Point]:
    """Create the motherword row for every bit-addressed word that lacks one.

    The Excel tool only *validates* motherwords (docs/06 section 6.3); creating them was
    manual. DIVERGENCE: with options.auto_motherwords (default) they are generated.
    """
    if not project.options.auto_motherwords:
        return []
    existing = set()
    for p in project.points:
        if p.bit is None and p.is_motherword:
            dt = tables.datatypes.get(p.datatype)
            if dt:
                existing.add((dt.read_func, p.addr))
    created: list[Point] = []
    seen: set[tuple[str, int]] = set()
    out: list[Point] = []
    for p in project.points:
        if p.bit is not None:
            dt = tables.datatypes.get(p.datatype)
            key = (dt.read_func, p.addr) if dt else None
            if key and key not in existing and key not in seen:
                seen.add(key)
                mother_dt = MOTHER_DATATYPE_BY_READ_FUNC.get(dt.read_func)
                if mother_dt:
                    mother = Point(group=p.group, datatype=mother_dt, addr=p.addr,
                                   text="Motherword", rw="r", synthesized=True)
                    out.append(mother)
                    created.append(mother)
        out.append(p)
    project.points = out
    return created


def build_alias(p: Point, project: Project) -> str:
    o = project.options
    parts = []
    if o.use_system_no and p.system_no:
        parts.append(str(p.system_no))
    if o.use_tag and p.tag:
        parts.append(str(p.tag))
    parts.append(p.text)
    alias = "-".join(parts)
    if o.use_extra and p.extra:
        alias += f"-({p.extra})"
    return alias


def driver_id(p: Point, project: Project, tables: Tables) -> str:
    dt = tables.datatypes[p.datatype]
    addr = p.addr - 1 if project.options.subtract_one else p.addr
    base = f"0_{dt.read_func}_{addr}"
    return f"{base}.{p.bit}" if p.bit is not None else base


def driver_id_extra(p: Point, project: Project, tables: Tables) -> str:
    if p.bit is not None or p.rw not in ("r", "rw"):
        return ""
    dt = tables.datatypes[p.datatype]
    addr = p.addr - 1 if project.options.subtract_one else p.addr
    read_half = f"{dt.read_func}_{addr}_{dt.raw_type}_{dt.read_swap}"
    if p.rw == "rw":
        return f"{read_half}_{dt.write_func}_{addr}_{dt.raw_type}_{dt.write_swap}"
    return f"{read_half}_-_-_-_-"


def att(p: Point) -> str:
    if p.bit is not None:
        return "vrw" if p.rw in ("rw", "vrw") else "vr"
    return p.rw


def fmt(p: Point) -> str:
    if p.decimals is None:
        return ""
    return f"%.{int(p.decimals)}f"


def update_freq(p: Point, application: str) -> str:
    if p.update_freq is not None:               # per-point hand override (EM270 style)
        return p.update_freq
    if application in ("Analog values", "Integral values"):
        return "slow" if p.rw in ("rw", "vrw") else "norm"
    if application == "Digital IO":
        return "slow"
    return ""


def save_fields(freq: str, att_val: str, application: str) -> tuple[str, str]:
    """House rule (confirmed 2026-08-18): measured points - read-only analog/integral
    values - log min/1 even when polled slow; setpoints (rw), digitals and
    once/never stay on change-logging."""
    measured = att_val in ("r", "vr") and application in ("Analog values",
                                                         "Integral values")
    if freq in ("norm", "fast"):
        return "min", "1"
    if freq == "slow":
        return ("min", "1") if measured else ("change", "")
    if freq in ("once", "never"):
        return "change", ""
    return "", ""


def active(p: Point, project: Project) -> str:
    o = project.options
    # DIVERGENCE: in Excel, force_active overwrites the Reserve. rule (docs/08 item 11).
    # Here Reserve. wins - a spare row stays inactive even with force_active on.
    # An empty reserve_text disables the rule (the workbook's Main!B14 off state).
    if o.reserve_text and p.text == o.reserve_text:
        return "0"
    if o.force_active:
        return "1"
    return "1" if p.active is None else str(int(p.active))


def statetext_fields(p: Point, project: Project) -> tuple[str, str | None]:
    """Return (format_extra, extra_override)."""
    o = project.options
    if p.statetext is None:
        return "", None
    states = project.statetexts[p.statetext]
    js = state_json(states, o.proper_case_states)
    plain = state_plain(states, o.proper_case_states)
    if o.statetext_only_rw and p.rw not in ("rw", "vrw"):
        js = ""
    # DIVERGENCE: with statetext_in_alias off, Excel *clears* the extra text of matched
    # rows (docs/07 section 7.3); here the user's extra is left untouched.
    extra_override = plain if o.statetext_in_alias else None
    return js, extra_override


def generate(project: Project, tables: Tables, timestamp: str) -> RunResult:
    apply_auto_groups(project, tables)
    synthesize_motherwords(project, tables)

    params: list[ParamRecord] = []
    sets: list[SetRecord] = []
    groups: list[GroupRecord] = []
    view_order: dict[str, int] = {}

    for p in project.points:
        dt = tables.datatypes[p.datatype]
        fx, extra_override = statetext_fields(p, project)
        if extra_override is not None:
            p.extra = extra_override

        did = driver_id(p, project, tables)
        eid = p.element_id if p.element_id else f"{p.group}_{did}"

        eng_unit = ""
        if p.unit:
            eng_unit = tables.units[p.unit].iwmac_unit

        scale = raw_min = raw_max = eng_min = eng_max = ""
        if p.scale:
            s = tables.scaling[p.scale]
            scale, raw_min, raw_max = s.scale, s.raw_min, s.raw_max
            eng_min, eng_max = s.eng_min, s.eng_max

        params.append(ParamRecord(
            row_date=timestamp, element_id=eid, driver_id=did,
            alias_text=build_alias(p, project), menu=p.menu or "",
            application=dt.application, parameter_type=dt.parameter_type,
            factory_setting="", grp="-1", att=att(p), eng_unit=eng_unit,
            format=fmt(p),
            range_min=str(p.range_min) if project.options.include_minmax and p.range_min is not None else "",
            range_max=str(p.range_max) if project.options.include_minmax and p.range_max is not None else "",
            scale=scale, raw_min=raw_min, raw_max=raw_max,
            eng_min=eng_min, eng_max=eng_max,
            driver_id_extra=driver_id_extra(p, project, tables), format_extra=fx,
        ))

        freq = update_freq(p, dt.application)
        save_data, save_freq = save_fields(freq, att(p), dt.application)
        sets.append(SetRecord(
            row_date=timestamp, element_id=eid, active=active(p, project),
            onl_ind="1" if p.online else "0", update_freq=freq,
            save_data=save_data, save_freq=save_freq,
            plant_pri=p.alarm or "", sys_pri="", alarm_type="0",
        ))

        skip_group = p.no_group or (
            project.options.exclude_motherwords_from_groups and p.is_motherword)
        if not skip_group and " | " not in p.group:
            vo = view_order.get(p.group, 0) + 3
            view_order[p.group] = vo
            groups.append(GroupRecord(row_date=timestamp, type="group",
                                      view_order=str(vo), ref=p.group, value=eid))

    aliases = [GroupRecord(row_date=timestamp, type="default_link", view_order="1",
                           ref="", value="")]
    for g in project.groups:
        aliases.append(GroupRecord(row_date=timestamp, type="group_alias",
                                   view_order=str(g.order), ref=g.name, value=g.alias))

    return RunResult(params=params, sets=sets, groups=groups, group_aliases=aliases,
                     points=project.points)
