"""modbusgen - IWMAC Modbus list generator (replacement for the INAS Modbus Excel tool)."""

__version__ = "0.1.0"
