"""Importer for generated SQL scripts: rebuilds an editable project from the
iw_par_*_param / iw_par_*_groups / iw_set_* (and optional iw_sys_*) statements of an
existing list. Accepts both output dialects - the modern REPLACE INTO house style and
the Excel tool's legacy single-line INSERTs - so old plant scripts can be migrated
without the source workbook.

Reconstruction follows importer_old.py: the generated records are complete and
unambiguous (driver_id encodes function/address/bit, driver_id_extra encodes raw type
and swap, the set block holds the hand-tuned polling), so the project is rebuilt from
them and written with subtract_one: false - regeneration reproduces the same
driver_ids. The plant number never appears inside the SQL and must be set afterwards.
"""
from __future__ import annotations

import json
import re

from .importer_old import _datatype_name, _reverse_units, _reverse_scaling
from .model import Point
from .rules import att as point_att, save_fields, update_freq as derive_update_freq
from .tables import Tables

# canonical column orders (docs/03) for legacy INSERTs that carry no column list
PARAM_COLS = ["row_date", "element_id", "driver_id", "alias_text", "menu",
              "application", "parameter_type", "factory_setting", "grp", "att",
              "eng_unit", "format", "range_min", "range_max", "scale", "raw_min",
              "raw_max", "eng_min", "eng_max", "driver_id_extra", "format_extra"]
SET_COLS = ["row_date", "element_id", "active", "onl_ind", "update_freq",
            "save_data", "save_freq", "plant_pri", "sys_pri", "alarm_type"]
GROUP_COLS = ["row_date", "type", "view_order", "ref", "value"]

PARITY_NAME = {"0": "none", "1": "odd", "2": "even"}


class SqlImportError(ValueError):
    """The text is not a usable generated Modbus list."""


# ---------------------------------------------------------------------------
# SQL statement scanning (quote-aware; '' escapes, -- comments, ; separators)
# ---------------------------------------------------------------------------

def _statements(text: str) -> list[str]:
    out: list[str] = []
    buf: list[str] = []
    i, n = 0, len(text)
    in_quote = False
    while i < n:
        c = text[i]
        if in_quote:
            buf.append(c)
            if c == "'":
                if i + 1 < n and text[i + 1] == "'":
                    buf.append("'")
                    i += 2
                    continue
                in_quote = False
            i += 1
        elif c == "'":
            in_quote = True
            buf.append(c)
            i += 1
        elif c == "-" and text.startswith("--", i):
            while i < n and text[i] not in "\r\n":
                i += 1
        elif c == ";":
            s = "".join(buf).strip()
            if s:
                out.append(s)
            buf = []
            i += 1
        else:
            buf.append(c)
            i += 1
    s = "".join(buf).strip()
    if s:
        out.append(s)
    return out


_HEAD = re.compile(r"(INSERT|REPLACE)\s+INTO\s+`?(\w+)`?\s*(?:\(([^)]*)\))?\s*"
                   r"VALUES\s*(.*)", re.IGNORECASE | re.DOTALL)
_NOW = re.compile(r"NOW\s*\(\s*\)", re.IGNORECASE)


def _parse_values(text: str) -> list[list[str]]:
    """All parenthesized value tuples of one statement. Strings keep their content
    (quotes removed, '' unescaped); bare tokens (ints, NOW()) come back verbatim."""
    rows: list[list[str]] = []
    i, n = 0, len(text)
    while i < n:
        if text[i] != "(":
            i += 1
            continue
        i += 1
        row: list[str] = []
        while i < n:
            while i < n and text[i] in " \t\r\n,":
                i += 1
            if i >= n:
                break
            if text[i] == ")":
                i += 1
                break
            if text[i] == "'":
                i += 1
                parts: list[str] = []
                while i < n:
                    if text[i] == "'":
                        if i + 1 < n and text[i + 1] == "'":
                            parts.append("'")
                            i += 2
                            continue
                        i += 1
                        break
                    parts.append(text[i])
                    i += 1
                row.append("".join(parts))
            else:
                m = _NOW.match(text, i)
                if m:
                    row.append("NOW()")
                    i = m.end()
                else:
                    j = i
                    while j < n and text[j] not in ",)":
                        j += 1
                    row.append(text[i:j].strip())
                    i = j
        rows.append(row)
    return rows


def _scan(text: str):
    """Group every INSERT/REPLACE row by target table.
    Returns ({table_name: [row dict]}, legacy_seen)."""
    by_table: dict[str, list[dict]] = {}
    legacy = False
    for st in _statements(text):
        m = _HEAD.match(st)
        if not m:
            continue                      # SET / CREATE TABLE / TRUNCATE noise
        verb, table, collist, values = m.groups()
        if verb.upper() == "INSERT" and table.startswith("iw_par_"):
            legacy = True
        if collist:
            names = [c.strip().strip("`").lower() for c in collist.split(",")]
        elif table.endswith("_param"):
            names = PARAM_COLS
        elif table.endswith("_groups"):
            names = GROUP_COLS
        elif table.startswith("iw_set_"):
            names = SET_COLS
        else:
            continue                      # positional insert into an unknown table
        rows = by_table.setdefault(table, [])
        for vals in _parse_values(values):
            if len(vals) < len(names):    # tolerate truncated legacy rows
                vals = vals + [""] * (len(names) - len(vals))
            rows.append(dict(zip(names, vals)))
    return by_table, legacy


# ---------------------------------------------------------------------------
# reconstruction
# ---------------------------------------------------------------------------

def _system_block(by_table: dict, table: str, notes: list[str]) -> dict | None:
    units = by_table.get("iw_sys_plant_units", [])
    settings = {r.get("setting", ""): r.get("value", "")
                for r in reversed(by_table.get("iw_sys_plant_settings", []))}
    if not units and not settings:
        return None

    sys: dict = {"units": bool(units), "settings": bool(settings)}
    owner = ""
    if units:
        prefixes = set()
        rows = []
        for u in units:
            addr = u.get("driver_addr", "")
            pm = re.fullmatch(r"([01]_)(.*)", addr)
            prefixes.add(pm.group(1) if pm else "")
            vo = u.get("view_order", "0")
            rows.append({"unit_id": u.get("unit_id", ""),
                         "unit_name": u.get("unit_name", ""),
                         "driver_addr": pm.group(2) if pm else addr,
                         "view_order": int(vo) if str(vo).isdigit() else 0})
        if len(prefixes) == 1:
            sys["driver_addr_prefix"] = prefixes.pop()
        else:                            # mixed prefixes: keep full addresses
            sys["driver_addr_prefix"] = ""
            rows = [dict(r, driver_addr=u.get("driver_addr", ""))
                    for r, u in zip(rows, units)]
        sys["unit_list"] = rows
        first = units[0]
        owner = first.get("driver_type", "")
        sys["reg_type"] = first.get("regulator_type", "")
        sys["order_no"] = first.get("order_no", "")
        grp = first.get("grp_name", "")
        if grp and grp != table:
            notes.append(f"iw_sys_plant_units grp_name '{grp}' differs from the "
                         f"table name '{table}'")
    if not sys.get("order_no"):
        order_rows = by_table.get("iw_sys_order_no", [])
        if order_rows:
            sys["order_no"] = order_rows[0].get("order_no", "")
    if not owner:
        srows = by_table.get("iw_sys_plant_settings", [])
        if srows:
            owner = srows[0].get("owner", "")
    if not owner:
        proc = by_table.get("iw_sys_processes", [])
        if proc:
            owner = proc[0].get("process_name", "")
    sys["owner"] = owner

    if settings:
        comm: dict = {}
        comm["mode"] = "rtu" if settings.get("mb_mode") == "0" else "tcp"
        comm["com_port"] = settings.get("comm_port", "")
        par = settings.get("comm_parity", "")
        comm["parity"] = PARITY_NAME.get(par, par.lower() or "even")
        for key, name in (("comm_data_bits", "data_bits"),
                          ("comm_stop_bits", "stop_bits"),
                          ("comm_baudrate", "baudrate")):
            v = settings.get(key, "")
            if str(v).lstrip("-").isdigit():
                comm[name] = int(v)
        servers = settings.get("mb_tcp_servers", "")
        parts = servers.replace("\\r\\n", "").split(";")
        if len(parts) >= 3:
            if parts[1] and "XXX" not in parts[1].upper():
                comm["ip"] = parts[1]
            if parts[2].isdigit():
                comm["port"] = int(parts[2])
        sys["comm"] = comm
    return sys


def import_sql(text: str) -> tuple[dict, list[str]]:
    """Generated SQL text -> (project dict, notes). Raises SqlImportError when the
    text holds no recognizable generated list."""
    notes: list[str] = []
    tables = Tables()
    rev_units = _reverse_units(tables)
    rev_scale = _reverse_scaling(tables)
    by_table, legacy = _scan(text)

    param_tables = [t for t in by_table
                    if t.startswith("iw_par_") and t.endswith("_param")]
    if not param_tables:
        raise SqlImportError("no iw_par_<table>_param INSERT/REPLACE found - "
                             "this is not a generated Modbus list script")
    if len(param_tables) > 1:
        raise SqlImportError(f"script fills more than one list "
                             f"({', '.join(sorted(param_tables))}) - split it first")
    table = param_tables[0][len("iw_par_"):-len("_param")]
    if legacy:
        notes.append("legacy INSERT format detected - the project regenerates in the "
                     "modern REPLACE format unless options.sql_format is set to legacy")

    sets = {r.get("element_id", ""): r for r in by_table.get(f"iw_set_{table}", [])}
    membership: dict[str, str] = {}
    groups: dict[str, dict] = {}
    for r in by_table.get(f"iw_par_{table}_groups", []):
        if r.get("type") == "group_alias" and r.get("ref"):
            vo = str(r.get("view_order", ""))
            groups[r["ref"]] = {"alias": r.get("value", ""),
                                "order": int(vo) if vo.isdigit() else len(groups) + 1}
        elif r.get("type") == "group" and r.get("value"):
            membership.setdefault(r["value"], r.get("ref", ""))

    points: list[dict] = []
    statetexts: dict[int, dict[int, str]] = {}
    json_ids: dict[str, int] = {}
    skipped = 0
    no_set = 0
    save_divergent = 0
    alarm_type_seen = 0

    for r in by_table[f"iw_par_{table}_param"]:
        did = r.get("driver_id", "")
        m = re.fullmatch(r"0_(\d+)_(\d+)(?:\.([\d#]+))?", did)
        if not m:
            skipped += 1
            continue
        read_func, addr, bit = m.group(1), int(m.group(2)), m.group(3)

        extra = r.get("driver_id_extra", "")
        raw = swap = ""
        xm = re.fullmatch(r"\d+_\d+_([A-Z0-9]+)_([A-Z])_(.+)", extra or "")
        if xm:
            raw, swap = xm.group(1), xm.group(2)
        datatype = _datatype_name(read_func, raw or "I16", swap or "N",
                                  r.get("application", ""), bit is not None, tables)
        if datatype is None:
            skipped += 1
            notes.append(f"row with driver_id {did}: unresolvable datatype (func "
                         f"{read_func}, raw {raw or '?'}, "
                         f"app {r.get('application') or '?'})")
            continue

        eid = r.get("element_id", "")
        group = membership.get(eid, "")
        if not group and eid.endswith(f"_{did}"):
            group = eid[:-len(did) - 1]
        p: dict = {"group": group, "datatype": datatype, "addr": addr,
                   "text": r.get("alias_text", "")}
        if bit is not None:
            p["bit"] = int(bit) if bit.isdigit() else bit
        att = r.get("att", "").lower()
        p["rw"] = "rw" if "w" in att else "r"
        if eid and eid != f"{group}_{did}":
            p["element_id"] = eid
        if r.get("menu"):
            p["menu"] = r["menu"]
        if r.get("eng_unit"):
            unit = rev_units.get(r["eng_unit"].casefold())
            if unit:
                p["unit"] = unit
            else:
                notes.append(f"{p['text'] or did}: eng_unit '{r['eng_unit']}' not in "
                             f"the unit table - left empty")
        fm = re.fullmatch(r"%\.(\d)f", r.get("format", ""))
        if fm and int(fm.group(1)) <= 3:
            p["decimals"] = int(fm.group(1))
        elif r.get("format"):
            notes.append(f"{p['text'] or did}: format '{r['format']}' has no decimals "
                         f"equivalent - dropped")
        scale_key = rev_scale.get((r.get("scale", ""), r.get("raw_min", ""),
                                   r.get("raw_max", ""), r.get("eng_min", ""),
                                   r.get("eng_max", "")))
        if scale_key:
            p["scale"] = scale_key
        elif r.get("scale"):
            notes.append(f"{p['text'] or did}: scaling "
                         f"({r.get('scale')},{r.get('raw_min')}..{r.get('raw_max')} -> "
                         f"{r.get('eng_min')}..{r.get('eng_max')}) has no table key "
                         f"- dropped")
        for name in ("range_min", "range_max"):
            if r.get(name):
                p[name] = r[name]

        s = sets.get(eid)
        if s is None:
            no_set += 1
        else:
            alarm = s.get("plant_pri", "").upper()
            if alarm in ("A", "B", "C", "N"):
                p["alarm"] = alarm
            if s.get("onl_ind") == "1":
                p["online"] = True
            if s.get("active") == "0":
                p["active"] = 0
            dt = tables.datatypes[datatype]
            stub = Point(addr=addr, rw=p["rw"],
                         bit=p.get("bit"), text=p["text"])
            derived = derive_update_freq(stub, dt.application)
            freq = s.get("update_freq", "")
            if freq != derived and freq in ("fast", "norm", "slow", "once", "never"):
                p["update_freq"] = freq
            eff = freq if freq in ("fast", "norm", "slow", "once", "never") else derived
            if save_fields(eff, point_att(stub), dt.application) != \
                    (s.get("save_data", ""), s.get("save_freq", "")):
                save_divergent += 1
            if s.get("alarm_type", "0").strip("'") not in ("0", ""):
                alarm_type_seen += 1

        fx = r.get("format_extra", "")
        if fx.startswith("{"):
            if fx not in json_ids:
                try:
                    states = {int(n): v["t"]
                              for n, v in json.loads(fx)["v"].items()}
                    sid = len([v for v in json_ids.values() if v]) + 1
                    json_ids[fx] = sid
                    statetexts[sid] = states
                except Exception:
                    notes.append(f"{p['text'] or did}: unparseable format_extra JSON "
                                 f"- dropped")
                    json_ids[fx] = 0
            if json_ids[fx]:
                p["statetext"] = json_ids[fx]

        if eid not in membership and p["text"] != "Motherword":
            p["no_group"] = True
        points.append(p)

    if not points:
        raise SqlImportError(f"iw_par_{table}_param held no usable rows "
                             f"({skipped} skipped)")

    if skipped:
        notes.append(f"skipped {skipped} row(s) without a decodable driver_id")
    if no_set:
        notes.append(f"{no_set} point(s) had no iw_set_{table} row - polling, alarm "
                     f"and active flags fall back to derived values")
    if save_divergent:
        notes.append(f"{save_divergent} point(s) carried save_data/save_freq values "
                     f"the current logging rules will not reproduce (house rule "
                     f"2026-08-18: measured read-only points log min/1)")
    if alarm_type_seen:
        notes.append(f"{alarm_type_seen} iw_set row(s) had a non-zero alarm_type - "
                     f"not representable in a project file, dropped")
    notes.append("addresses imported as protocol addresses (from driver_id); "
                 "subtract_one is set to false")
    notes.append("plant number is not stored in SQL - set it before generating")

    used = {p["group"] for p in points if p.get("group")}
    for name in sorted(used - set(groups)):
        groups[name] = {"alias": name, "order": len(groups) + 1}
        notes.append(f"group '{name}' had no group_alias row - added with its own "
                     f"name as alias")
    ordered = dict(sorted(groups.items(), key=lambda kv: kv[1]["order"]))
    if [g["order"] for g in ordered.values()] != list(range(1, len(ordered) + 1)):
        notes.append("group alias view orders are not contiguous - the GUI renumbers "
                     "them by position on save")

    options = {"subtract_one": False,
               "force_active": not any(p.get("active") == 0 for p in points
                                       if p.get("text") != "Reserve."),
               "proper_case_states": False}
    if any("range_min" in p or "range_max" in p for p in points):
        options["include_minmax"] = True

    data = {"table": table, "plant": "", "options": options,
            "system": _system_block(by_table, table, notes),
            "groups": ordered, "statetexts": statetexts, "points": points}
    return data, notes


def decode_sql_bytes(raw: bytes) -> str:
    """IWMAC scripts are cp1252/latin1; tolerate re-saved UTF-8 copies."""
    try:
        return raw.decode("utf-8-sig")
    except UnicodeDecodeError:
        return raw.decode("cp1252", errors="replace")
