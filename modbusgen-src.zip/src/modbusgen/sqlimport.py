"""Importer for generated SQL scripts: rebuilds an editable project from the
iw_par_*_param / iw_par_*_groups / iw_set_* (and optional iw_sys_*) statements of an
existing list. Accepts both output dialects - the modern REPLACE INTO house style and
the Excel tool's legacy single-line INSERTs - so old plant scripts can be migrated
without the source workbook.

Reconstruction follows importer_old.py: the generated records are complete and
unambiguous (driver_id encodes function/address/bit, driver_id_extra encodes raw type
and swap, the set block holds the hand-tuned polling), so the project is rebuilt from
them and written with subtract_one: false - regeneration reproduces the same
driver_ids. The plant number never appears inside the SQL and must be set afterwards.
"""
from __future__ import annotations

import json
import re

from .notes import ACTION, DROPPED, INFO, REPAIRED, Note
from .importer_old import (_match_datatype, _reverse_scaling, _reverse_units,
                           drop_redundant_motherwords, few, keep_unit,
                           motherwords_dropped_note, nearest_datatype_note, parse_extra,
                           rw_from_att, unit_notes)
from .model import Point
from .rules import att as point_att, save_fields, update_freq as derive_update_freq
from .tables import Tables, unknown_datatype_notes

# canonical column orders (docs/03) for legacy INSERTs that carry no column list
PARAM_COLS = ["row_date", "element_id", "driver_id", "alias_text", "menu",
              "application", "parameter_type", "factory_setting", "grp", "att",
              "eng_unit", "format", "range_min", "range_max", "scale", "raw_min",
              "raw_max", "eng_min", "eng_max", "driver_id_extra", "format_extra"]
SET_COLS = ["row_date", "element_id", "active", "onl_ind", "update_freq",
            "save_data", "save_freq", "plant_pri", "sys_pri", "alarm_type"]
GROUP_COLS = ["row_date", "type", "view_order", "ref", "value"]

PARITY_NAME = {"0": "none", "1": "odd", "2": "even"}


class SqlImportError(ValueError):
    """The text is not a usable generated Modbus list."""


# ---------------------------------------------------------------------------
# SQL statement scanning: MySQL string literals, -- comments, ; separators
# ---------------------------------------------------------------------------
#
# A string is read the way MySQL reads it, because that is what the plant database
# holds. Both escapes stand for one character: a doubled quote (all the Excel tool
# ever wrote) and a backslash (what MySQL itself, phpMyAdmin, and modbusgen's own
# writer write). An escape that is not one of MySQL's is the character itself, except
# \% and \_, which MySQL keeps as written outside a LIKE pattern. "..." is a string as
# well (no ANSI_QUOTES), and a `name` can hold neither escape.

_ESCAPES = {"0": "\0", "b": "\b", "n": "\n", "r": "\r", "t": "\t", "Z": "\x1a"}


def _statements(text: str) -> list[str]:
    out: list[str] = []
    buf: list[str] = []
    i, n = 0, len(text)
    quote = ""
    while i < n:
        c = text[i]
        if quote:
            buf.append(c)
            if c == "\\" and quote != "`" and i + 1 < n:
                buf.append(text[i + 1])           # \' and \\ do not end the string
                i += 2
                continue
            if c == quote:
                if i + 1 < n and text[i + 1] == quote:
                    buf.append(quote)
                    i += 2
                    continue
                quote = ""
            i += 1
        elif c in "'\"`":
            quote = c
            buf.append(c)
            i += 1
        elif c == "-" and text.startswith("--", i):
            while i < n and text[i] not in "\r\n":
                i += 1
        elif c == ";":
            s = "".join(buf).strip()
            if s:
                out.append(s)
            buf = []
            i += 1
        else:
            buf.append(c)
            i += 1
    s = "".join(buf).strip()
    if s:
        out.append(s)
    return out


# INSERT IGNORE is what a dump that must not overwrite writes; the priority words are
# the rest of MySQL's INSERT/REPLACE grammar between the verb and INTO
_HEAD = re.compile(r"(INSERT|REPLACE)\s+(?:(?:LOW_PRIORITY|DELAYED|HIGH_PRIORITY)\s+)?"
                   r"(?:IGNORE\s+)?INTO\s+`?(\w+)`?\s*(?:\(([^)]*)\))?\s*"
                   r"VALUES?\s*(.*)", re.IGNORECASE | re.DOTALL)
_NOW = re.compile(r"NOW\s*\(\s*\)", re.IGNORECASE)
_TRUNCATE = re.compile(r"TRUNCATE\s+(?:TABLE\s+)?`?(\w+)`?\s*$", re.IGNORECASE)
# sqlout.replace_list_sql: the bound rows of every unit in one group go first. A script
# that writes iw_sys_plant_units rows names those units ahead of the subquery,
# "WHERE (`unit_id` IN (...) OR `unit_id` IN (SELECT ...))", so the list is optional. An
# update's DELETE (sqlout.update_bound_sql) reads grp_name IN (...) and never matches.
_REPLACE_LIST = re.compile(
    r"DELETE\s+FROM\s+`?iw_gen_driver_parameters`?\s+WHERE\s+(?:\(.*?\bOR\s+)?"
    r"`?unit_id`?\s+IN\s*\(\s*SELECT\s+`?unit_id`?\s+FROM\s+`?iw_sys_plant_units`?\s+"
    r"WHERE\s+`?grp_name`?\s*=\s*('(?:[^'\\]|''|\\.)*')", re.IGNORECASE | re.DOTALL)


def _string(text: str, i: int) -> tuple[str, int]:
    """The string literal opening at text[i] -> (its value, the index after it)."""
    quote, n = text[i], len(text)
    i += 1
    parts: list[str] = []
    while i < n:
        c = text[i]
        if c == "\\" and i + 1 < n:
            nxt = text[i + 1]
            parts.append("\\" + nxt if nxt in "%_" else _ESCAPES.get(nxt, nxt))
            i += 2
            continue
        if c == quote:
            if i + 1 < n and text[i + 1] == quote:
                parts.append(quote)
                i += 2
                continue
            i += 1
            break
        parts.append(c)
        i += 1
    return "".join(parts), i


def _parse_values(text: str) -> list[list[str]]:
    """All parenthesized value tuples of one statement. Strings keep their content
    (quotes removed, escapes resolved); NULL is the empty string - every column these
    tables have is NOT NULL text, and an absent value reads as one; other bare tokens
    (ints, NOW()) come back verbatim. The list ends at the first thing after a tuple
    that is not another tuple, so a trailing ON DUPLICATE KEY UPDATE adds no rows."""
    rows: list[list[str]] = []
    i, n = 0, len(text)
    while True:
        while i < n and text[i] in " \t\r\n,":
            i += 1
        if i >= n or text[i] != "(":
            break
        i += 1
        row: list[str] = []
        while i < n:
            while i < n and text[i] in " \t\r\n,":
                i += 1
            if i >= n:
                break
            if text[i] == ")":
                i += 1
                break
            if text[i] in "'\"":
                value, i = _string(text, i)
                row.append(value)
            else:
                m = _NOW.match(text, i)
                if m:
                    row.append("NOW()")
                    i = m.end()
                else:
                    j = i
                    while j < n and text[j] not in ",)":
                        j += 1
                    token = text[i:j].strip()
                    row.append("" if token.upper() == "NULL" else token)
                    i = j
        rows.append(row)
    return rows


def _scan(text: str):
    """Group every INSERT/REPLACE row by target table, and note what else the script
    does to the list. Returns ({table_name: [row dict]}, legacy_seen, the tables it
    truncates, the grp_names whose bound rows it deletes first - replace_list)."""
    by_table: dict[str, list[dict]] = {}
    legacy = False
    truncated: set[str] = set()
    deletes: list[str] = []
    for st in _statements(text):
        m = _HEAD.match(st)
        if not m:
            t = _TRUNCATE.match(st)
            if t:
                truncated.add(t.group(1))
            d = _REPLACE_LIST.match(st)
            if d:
                deletes.append(_string(d.group(1), 0)[0])
            continue                      # SET / CREATE TABLE noise
        verb, table, collist, values = m.groups()
        if verb.upper() == "INSERT" and table.startswith("iw_par_"):
            legacy = True
        if collist:
            names = [c.strip().strip("`").lower() for c in collist.split(",")]
        elif table.endswith("_param"):
            names = PARAM_COLS
        elif table.endswith("_groups"):
            names = GROUP_COLS
        elif table.startswith("iw_set_"):
            names = SET_COLS
        else:
            continue                      # positional insert into an unknown table
        rows = by_table.setdefault(table, [])
        for vals in _parse_values(values):
            if len(vals) < len(names):    # tolerate truncated legacy rows
                vals = vals + [""] * (len(names) - len(vals))
            rows.append(dict(zip(names, vals)))
    return by_table, legacy, truncated, deletes


# ---------------------------------------------------------------------------
# reconstruction
# ---------------------------------------------------------------------------

def _system_block(by_table: dict, table: str, notes: list[str]) -> dict | None:
    units = by_table.get("iw_sys_plant_units", [])
    settings = {r.get("setting", ""): r.get("value", "")
                for r in reversed(by_table.get("iw_sys_plant_settings", []))}
    if not units and not settings:
        return None

    sys: dict = {"units": bool(units), "settings": bool(settings)}
    owner = ""
    if units:
        prefixes = set()
        rows = []
        for u in units:
            addr = u.get("driver_addr", "")
            pm = re.fullmatch(r"([01]_)(.*)", addr)
            prefixes.add(pm.group(1) if pm else "")
            vo = u.get("view_order", "0")
            rows.append({"unit_id": u.get("unit_id", ""),
                         "unit_name": u.get("unit_name", ""),
                         "driver_addr": pm.group(2) if pm else addr,
                         "view_order": int(vo) if str(vo).isdigit() else 0})
        if len(prefixes) == 1:
            sys["driver_addr_prefix"] = prefixes.pop()
        else:                            # mixed prefixes: keep full addresses
            sys["driver_addr_prefix"] = ""
            rows = [dict(r, driver_addr=u.get("driver_addr", ""))
                    for r, u in zip(rows, units)]
        sys["unit_list"] = rows
        first = units[0]
        owner = first.get("driver_type", "")
        sys["reg_type"] = first.get("regulator_type", "")
        sys["order_no"] = first.get("order_no", "")
        grp = first.get("grp_name", "")
        if grp and grp != table:
            notes.append(Note(
                f"iw_sys_plant_units grp_name '{grp}' differs from the "
                f"table name '{table}'", code="unit-grp-name-differs", kind=REPAIRED,
                advice="Check which name the plant database actually uses; the two "
                       "disagreed in the delivery and the table name won."))
    if not sys.get("order_no"):
        order_rows = by_table.get("iw_sys_order_no", [])
        if order_rows:
            sys["order_no"] = order_rows[0].get("order_no", "")
    if not owner:
        srows = by_table.get("iw_sys_plant_settings", [])
        if srows:
            owner = srows[0].get("owner", "")
    if not owner:
        proc = by_table.get("iw_sys_processes", [])
        if proc:
            owner = proc[0].get("process_name", "")
    sys["owner"] = owner

    if settings:
        comm: dict = {}
        comm["mode"] = "rtu" if settings.get("mb_mode") == "0" else "tcp"
        comm["com_port"] = settings.get("comm_port", "")
        par = settings.get("comm_parity", "")
        comm["parity"] = PARITY_NAME.get(par, par.lower() or "even")
        for key, name in (("comm_data_bits", "data_bits"),
                          ("comm_stop_bits", "stop_bits"),
                          ("comm_baudrate", "baudrate")):
            v = settings.get(key, "")
            if str(v).lstrip("-").isdigit():
                comm[name] = int(v)
        # one server per line, ID;IPadr;IPport;ConnTout;ConnRetries;RequestTout. The
        # legacy writer ends the line with \r\n, which MySQL - and so this reader - turns
        # into a real line break; written with the backslash escaped it stays literal
        # text. Either separates two servers.
        servers = settings.get("mb_tcp_servers", "")
        lines = [ln.strip() for ln in re.split(r"\r\n|\r|\n|\\r\\n|\\n", servers)
                 if ln.strip()]
        parts = lines[0].split(";") if lines else []
        if len(parts) >= 3:
            if parts[1] and "XXX" not in parts[1].upper():
                comm["ip"] = parts[1]
            if parts[2].isdigit():
                comm["port"] = int(parts[2])
        if len(lines) > 1:
            notes.append(Note(
                f"mb_tcp_servers lists {len(lines)} servers and a project holds one - kept "
                f"the first ({lines[0]}), dropped {'; '.join(repr(ln) for ln in lines[1:])}",
                code="tcp-servers-dropped", kind=DROPPED, count=len(lines) - 1,
                advice="system.comm has one ip and port, so the regenerated script "
                       "registers only the first server. Add the others to the plant's "
                       "iw_sys_plant_settings by hand after importing the script."))
        sys["comm"] = comm
    return sys


def _carry_clean_out(table: str, truncated: set[str], deletes: list[str],
                     options: dict, notes: list) -> None:
    """What the script does to the old list before writing the new one, as options.

    Both used to parse and vanish: a script that emptied its three tables, or deleted
    the old list's bound rows first (sqlout.replace_list_sql), came back as a project
    whose script did neither, so rows the list had dropped stayed on the plant.
    """
    three = {f"iw_par_{table}_groups", f"iw_par_{table}_param", f"iw_set_{table}"}
    replacing = table in deletes
    if replacing:
        options["replace_list"] = True
        notes.append(Note(
            f"the script deletes the old list first - the bound rows of every unit in "
            f"group '{table}' (iw_gen_driver_parameters), then its three tables - so "
            f"options.replace_list is set to true", code="replace-list-carried", kind=INFO,
            advice="The regenerated script deletes them too. Back the plant up before "
                   "running it, or switch replace_list off to only add and overwrite rows."))
    foreign = sorted(set(deletes) - {table})
    if foreign:
        notes.append(Note(
            f"the script deletes the bound rows of group(s) {', '.join(foreign)} - not this "
            f"list's '{table}', so not carried", code="delete-not-carried", kind=DROPPED,
            count=len(foreign),
            advice="A project clears only its own list. Delete those rows by hand if that "
                   "is still wanted."))
    if truncated >= three and not replacing:      # replace_list implies the truncation
        options["truncate"] = True
        notes.append(Note(
            f"the script empties {', '.join(sorted(three))} before writing them - "
            f"options.truncate is set to true", code="truncate-carried", kind=INFO,
            advice="The regenerated script empties them too, so rows the list no longer "
                   "has leave the template. Switch truncate off to keep them instead."))
    lost = sorted(truncated - three) if truncated >= three else sorted(truncated)
    if lost:
        notes.append(Note(
            f"the script truncates {', '.join(lost)}, which a project cannot say - it "
            f"empties its own three tables together or not at all - so not carried",
            code="truncate-not-carried", kind=DROPPED, count=len(lost),
            advice="The regenerated script leaves those tables as they are. Empty them by "
                   "hand if the plant needs it, or set truncate to empty all three."))


def import_sql(text: str) -> tuple[dict, list[str]]:
    """Generated SQL text -> (project dict, notes). Raises SqlImportError when the
    text holds no recognizable generated list."""
    notes: list[str] = []
    tables = Tables()
    rev_units = _reverse_units(tables)
    rev_scale = _reverse_scaling(tables)
    by_table, legacy, truncated, deletes = _scan(text)

    param_tables = [t for t in by_table
                    if t.startswith("iw_par_") and t.endswith("_param")]
    if not param_tables:
        raise SqlImportError("no iw_par_<table>_param INSERT/REPLACE found - "
                             "this is not a generated Modbus list script")
    if len(param_tables) > 1:
        raise SqlImportError(f"script fills more than one list "
                             f"({', '.join(sorted(param_tables))}) - split it first")
    table = param_tables[0][len("iw_par_"):-len("_param")]
    if legacy:
        notes.append(Note("legacy INSERT format detected - the project regenerates in the "
                     "modern REPLACE format unless options.sql_format is set to legacy",
            code="legacy-format", kind=INFO,
            advice="Nothing to do. The project regenerates in the modern REPLACE INTO house style, which is a deliberate divergence (docs/10), not a loss."))

    sets = {r.get("element_id", ""): r for r in by_table.get(f"iw_set_{table}", [])}
    membership: dict[str, str] = {}
    groups: dict[str, dict] = {}
    for r in by_table.get(f"iw_par_{table}_groups", []):
        if r.get("type") == "group_alias" and r.get("ref"):
            vo = str(r.get("view_order", ""))
            groups[r["ref"]] = {"alias": r.get("value", ""),
                                "order": int(vo) if vo.isdigit() else len(groups) + 1}
        elif r.get("type") == "group" and r.get("value"):
            membership.setdefault(r["value"], r.get("ref", ""))

    points: list[dict] = []
    statetexts: dict[int, dict[int, str]] = {}
    json_ids: dict[str, int] = {}
    skipped = 0
    unresolved: list[str] = []
    near: list[tuple[str, list[str]]] = []
    custom_units: list[str] = []
    respelled_units: list[str] = []
    lost_formats: list[str] = []
    lost_scales: list[str] = []
    bad_json: list[str] = []
    no_set = 0
    save_divergent = 0
    alarm_type_seen = 0

    for r in by_table[f"iw_par_{table}_param"]:
        did = r.get("driver_id", "")
        m = re.fullmatch(r"0_(\d+)_(\d+)(?:\.([\d#]+))?", did)
        if not m:
            skipped += 1
            continue
        read_func, addr, bit = m.group(1), int(m.group(2)), m.group(3)

        datatype, differs = _match_datatype(
            tables, read_func, r.get("application", ""), bit=bit,
            parameter_type=r.get("parameter_type") or None,
            **parse_extra(r.get("driver_id_extra", "")))
        if datatype is None:
            skipped += 1
            unresolved.append(str(did))
            continue
        if differs:
            near.append((str(did), differs))

        eid = r.get("element_id", "")
        group = membership.get(eid, "")
        if not group and eid.endswith(f"_{did}"):
            group = eid[:-len(did) - 1]
        p: dict = {"group": group, "datatype": datatype, "addr": addr,
                   "text": r.get("alias_text", "")}
        if bit is not None:
            p["bit"] = int(bit) if bit.isdigit() else bit
        p["rw"] = rw_from_att(r.get("att", ""), bit is not None)
        if eid and eid != f"{group}_{did}":
            p["element_id"] = eid
        if r.get("menu"):
            p["menu"] = r["menu"]
        if r.get("eng_unit"):
            p["unit"] = keep_unit(r["eng_unit"], rev_units, tables,
                                  custom_units, respelled_units)
        fm = re.fullmatch(r"%\.(\d)f", r.get("format", ""))
        if fm and int(fm.group(1)) <= 3:
            p["decimals"] = int(fm.group(1))
        elif r.get("format"):
            lost_formats.append(str(r["format"]))
        scale_key = rev_scale.get((r.get("scale", ""), r.get("raw_min", ""),
                                   r.get("raw_max", ""), r.get("eng_min", ""),
                                   r.get("eng_max", "")))
        if scale_key:
            p["scale"] = scale_key
        elif r.get("scale"):
            lost_scales.append(f"{r.get('scale')},{r.get('raw_min')}.."
                               f"{r.get('raw_max')}->{r.get('eng_min')}.."
                               f"{r.get('eng_max')}")
        for name in ("range_min", "range_max"):
            if r.get(name):
                p[name] = r[name]

        s = sets.get(eid)
        if s is None:
            no_set += 1
        else:
            alarm = s.get("plant_pri", "").upper()
            if alarm in ("A", "B", "C", "N"):
                p["alarm"] = alarm
            if s.get("onl_ind") == "1":
                p["online"] = True
            if s.get("active") == "0":
                p["active"] = 0
            dt = tables.datatypes[datatype]
            stub = Point(addr=addr, rw=p["rw"],
                         bit=p.get("bit"), text=p["text"])
            derived = derive_update_freq(stub, dt.application)
            freq = s.get("update_freq", "")
            if freq != derived and freq in ("fast", "norm", "slow", "once", "never"):
                p["update_freq"] = freq
            eff = freq if freq in ("fast", "norm", "slow", "once", "never") else derived
            if save_fields(eff, point_att(stub), dt.application) != \
                    (s.get("save_data", ""), s.get("save_freq", "")):
                save_divergent += 1
            if s.get("alarm_type", "0").strip("'") not in ("0", ""):
                alarm_type_seen += 1

        fx = r.get("format_extra", "")
        if fx.startswith("{"):
            if fx not in json_ids:
                try:
                    states = {int(n): v["t"]
                              for n, v in json.loads(fx)["v"].items()}
                    sid = len([v for v in json_ids.values() if v]) + 1
                    json_ids[fx] = sid
                    statetexts[sid] = states
                except Exception:
                    bad_json.append(str(did))
                    json_ids[fx] = 0
            if json_ids[fx]:
                p["statetext"] = json_ids[fx]

        if eid not in membership and p["text"] != "Motherword":
            p["no_group"] = True
        points.append(p)

    # an Excel-era list can carry a Motherword row beside the value row of the same
    # register; validation rejects the pair, so they are settled as importer_old does
    points, dropped = drop_redundant_motherwords(points, tables)

    if not points:
        raise SqlImportError(f"iw_par_{table}_param held no usable rows "
                             f"({skipped} skipped)")

    # one note per family: a delivery with 300 unmapped units used to be 300 notes
    if unresolved:
        notes.append(Note(
            f"{len(unresolved)} row(s) had an unresolvable datatype and were skipped "
            f"- driver_id {few(unresolved)}", code="datatype-unresolvable",
            kind=DROPPED, count=len(unresolved),
            advice="Those points are not in the project at all. The function, raw type "
                   "and application in the SQL matched no datatype key, so re-author "
                   "them from the device document rather than guessing a key."))
    if (note := nearest_datatype_note(near)):
        notes.append(note)
    if dropped:
        notes.append(motherwords_dropped_note(dropped))
    notes += unit_notes(custom_units, respelled_units)
    if lost_formats:
        notes.append(Note(
            f"{len(lost_formats)} point(s) had a display format with no decimals "
            f"equivalent - dropped ({few(lost_formats)})", code="format-unmapped",
            kind=DROPPED, count=len(lost_formats),
            advice="Only %.0f to %.3f map onto the decimals field. Those points now "
                   "have no display format; set decimals 0-3 where the delivery meant "
                   "one."))
    if lost_scales:
        notes.append(Note(
            f"{len(lost_scales)} point(s) had a scaling with no table key - dropped "
            f"({few(lost_scales)})", code="scale-unmapped", kind=DROPPED,
            count=len(lost_scales),
            advice="Those points now read raw. Add the factor to "
                   "data/tables/scaling.csv, or check whether the delivered scaling was "
                   "itself wrong - a scale nothing in the table matches is unusual."))
    if bad_json:
        notes.append(Note(
            f"{len(bad_json)} point(s) had unparseable format_extra JSON - dropped "
            f"(driver_id {few(bad_json)})", code="statetext-unparseable",
            kind=DROPPED, count=len(bad_json),
            advice="Those points lost their state texts and will show raw numbers. "
                   "Re-author the lists in `statetexts` from the device document."))
    if skipped:
        notes.append(Note(
            f"skipped {skipped} row(s) without a decodable driver_id",
            code="rows-skipped", kind=DROPPED, count=skipped,
            advice="Reconcile that count against the source script before claiming the "
                   "list is complete (docs/11 coverage accounting)."))
    if no_set:
        notes.append(Note(f"{no_set} point(s) had no iw_set_{table} row - polling, alarm "
                     f"and active flags fall back to derived values",
            code="set-rows-missing", kind=REPAIRED,
            advice="Those points got derived polling, alarm and save settings instead of delivered ones. Check update_freq on anything that was deliberately slow."))
    if save_divergent:
        notes.append(Note(f"{save_divergent} point(s) carried save_data/save_freq values "
                     f"the current logging rules will not reproduce (house rule "
                     f"2026-08-18: measured read-only points log min/1)",
            code="save-values-divergent", kind=INFO,
            advice="The delivery disagreed with the house rule. Keep the derived values unless the plant needs the delivered ones."))
    if alarm_type_seen:
        notes.append(Note(f"{alarm_type_seen} iw_set row(s) had a non-zero alarm_type - "
                     f"not representable in a project file, dropped",
            code="alarm-type-nonzero", kind=INFO,
            advice="alarm_type is derived from the alarm letter, so a non-zero delivered value is not carried. Check the alarm letters on those rows."))
    notes.append(Note("addresses imported as protocol addresses (from driver_id); "
                 "subtract_one is set to false",
        code="addresses-are-protocol", kind=ACTION,
        advice="subtract_one is false because driver_id already holds protocol addresses. Do not turn it on and do not adjust the addresses by hand - either shifts every point."))
    notes.append(Note(
        "plant number is not stored in SQL - set it before generating",
        code="plant-number-missing", kind=ACTION,
        advice="Set the plant number before generating. The SQL never carried it, so "
               "nothing can recover it from the script."))

    used = {p["group"] for p in points if p.get("group")}
    for name in sorted(used - set(groups)):
        groups[name] = {"alias": name, "order": len(groups) + 1}
        notes.append(Note(f"group '{name}' had no group_alias row - added with its own "
                     f"name as alias",
            code="group-alias-added", kind=REPAIRED,
            advice="The key is standing in as the operator-facing name. Rename each alias to what the operator should see before shipping."))
    ordered = dict(sorted(groups.items(), key=lambda kv: kv[1]["order"]))
    if [g["order"] for g in ordered.values()] != list(range(1, len(ordered) + 1)):
        notes.append(Note("group alias view orders are not contiguous - the GUI renumbers "
                     "them by position on save",
            code="group-order-renumbered", kind=INFO,
            advice="Saving from the GUI renumbers them contiguously, which changes display order only, not identity."))

    options = {"subtract_one": False,
               "force_active": not any(p.get("active") == 0 for p in points
                                       if p.get("text") != "Reserve."),
               "proper_case_states": False}
    if any("range_min" in p or "range_max" in p for p in points):
        options["include_minmax"] = True
    _carry_clean_out(table, truncated, deletes, options, notes)

    notes += unknown_datatype_notes(points)

    data = {"table": table, "plant": "", "options": options,
            "system": _system_block(by_table, table, notes),
            "groups": ordered, "statetexts": statetexts, "points": points}
    return data, notes


def decode_sql_bytes(raw: bytes) -> str:
    """IWMAC scripts are cp1252/latin1; tolerate re-saved UTF-8 copies."""
    try:
        return raw.decode("utf-8-sig")
    except UnicodeDecodeError:
        return raw.decode("cp1252", errors="replace")
