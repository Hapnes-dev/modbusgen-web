"""Importer for generated SQL scripts: rebuilds an editable project from the
iw_par_*_param / iw_par_*_groups / iw_set_* (and optional iw_sys_*) statements of an
existing list. Accepts both output dialects - the modern REPLACE INTO house style and
the Excel tool's legacy single-line INSERTs - and a plant's own dump, whose table names
may carry the schema (`iw_plant_server3`.`iw_par_x_param`), so old plant scripts can be
migrated without the source workbook.

Reconstruction follows importer_old.py: the generated records are complete and
unambiguous (driver_id encodes function/address/bit, driver_id_extra encodes raw type
and swap, the set block holds the hand-tuned polling), so the project is rebuilt from
them and written with subtract_one: false - regeneration reproduces the same
driver_ids. The plant number never appears inside the SQL and must be set afterwards.

What the project cannot hold is named, never dropped quietly (review, 2026-10-24): every
statement the importer does not read and every column value the regenerated rows would
not repeat (content-not-carried), each iw_sys value the project has no field for, the
group rows a point cannot have, and the options the rows show the script was written
with - inferred where the rows prove them, said where they cannot.
"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass, field

from .notes import ACTION, DROPPED, INFO, REPAIRED, Note
from .importer_old import (_match_datatype, _reverse_scaling, _reverse_units,
                           datatype_rows, drop_redundant_motherwords, few,
                           formats_dropped_note, keep_unit, motherwords_dropped_note,
                           nearest_datatype_note, parse_extra, rebuild_datatype,
                           rebuilt_datatypes_note, rw_from_att, unit_notes,
                           unresolvable_note)
from .model import Comm, Point
from .rules import att as point_att, save_fields, update_freq as derive_update_freq
from .sqlout import FIXED_SETTINGS, FIXED_SETTINGS_TAIL, MODERN_SETTINGS, PARITY_NUM
from .tables import Tables, unknown_datatype_notes

# canonical column orders (docs/03) for legacy INSERTs that carry no column list
PARAM_COLS = ["row_date", "element_id", "driver_id", "alias_text", "menu",
              "application", "parameter_type", "factory_setting", "grp", "att",
              "eng_unit", "format", "range_min", "range_max", "scale", "raw_min",
              "raw_max", "eng_min", "eng_max", "driver_id_extra", "format_extra"]
SET_COLS = ["row_date", "element_id", "active", "onl_ind", "update_freq",
            "save_data", "save_freq", "plant_pri", "sys_pri", "alarm_type"]
GROUP_COLS = ["row_date", "type", "view_order", "ref", "value"]

PARITY_NAME = {"0": "none", "1": "odd", "2": "even"}
FREQS = ("fast", "norm", "slow", "once", "never")
ALARMS = ("A", "B", "C", "N")

# The iw_sys tables the importer reads. Anything else a script fills is named as unread.
SYS_TABLES = ("iw_sys_plant_units", "iw_sys_plant_settings", "iw_sys_order_no",
              "iw_sys_processes")


class SqlImportError(ValueError):
    """The text is not a usable generated Modbus list."""


# ---------------------------------------------------------------------------
# SQL statement scanning: MySQL string literals, comments, ; separators
# ---------------------------------------------------------------------------
#
# A string is read the way MySQL reads it, because that is what the plant database
# holds. Both escapes stand for one character: a doubled quote (all the Excel tool
# ever wrote) and a backslash (what MySQL itself, phpMyAdmin, and modbusgen's own
# writer write). An escape that is not one of MySQL's is the character itself, except
# \% and \_, which MySQL keeps as written outside a LIKE pattern. "..." is a string as
# well (no ANSI_QUOTES), and a `name` can hold neither escape.
#
# Comments are MySQL's three: `#` and `-- ` (the dashes followed by whitespace) to the
# end of the line, and /* ... */ wherever it closes. Only the second was known until
# 2026-10-24, so an apostrophe in `/* don't touch */` opened a string that swallowed the
# rest of the script: a modern script came back without its set block, a legacy one was
# "not a generated Modbus list".

_ESCAPES = {"0": "\0", "b": "\b", "n": "\n", "r": "\r", "t": "\t", "Z": "\x1a"}


def _unescaped_quote(line: int, what: str, also: str = "") -> SqlImportError:
    return SqlImportError(
        f"line {line}: {what} - which is what an apostrophe inside a text that was not "
        f"doubled does (the Excel tool writes them as typed, docs/08 item 21). Double "
        f"it ('') in that line and import the script again{also}")


def _single_line_insert(buf: list[str]) -> bool:
    """The statement read so far is a legacy INSERT, written one row to a line. Joined
    only when a string meets a line break, which a sound legacy script never does."""
    return "".join(buf).lstrip()[:6].upper() == "INSERT"


def _statements(text: str) -> list[tuple[int, str]]:
    """The script's statements, each with the line it starts on."""
    out: list[tuple[int, str]] = []
    buf: list[str] = []
    i, n = 0, len(text)
    line, start, opened = 1, 0, 0
    quote = ""
    while i < n:
        c = text[i]
        if quote:
            buf.append(c)
            if c == "\n":
                line += 1
                # A legacy INSERT is one line: a string still open at its end is not a
                # text that holds a line break but a quote that closed too early
                if quote != "`" and opened == start and _single_line_insert(buf):
                    raise _unescaped_quote(opened, "a quoted value runs past the end of "
                                                   "the line",
                                           " - or, if the text really holds a line break, "
                                           "join it onto the one line")
            if c == "\\" and quote != "`" and i + 1 < n:
                buf.append(text[i + 1])           # \' and \\ do not end the string
                if text[i + 1] == "\n":
                    line += 1
                i += 2
                continue
            if c == quote:
                if i + 1 < n and text[i + 1] == quote:
                    buf.append(quote)
                    i += 2
                    continue
                quote = ""
            i += 1
        elif c in "'\"`":
            quote, opened = c, line
            start = start or line
            buf.append(c)
            i += 1
        elif c == "#" or (c == "-" and text.startswith("--", i)
                          and (i + 2 >= n or text[i + 2] in " \t\r\n\f\v")):
            while i < n and text[i] != "\n":      # the line break itself is kept
                i += 1
        elif c == "/" and text.startswith("/*", i):
            end = text.find("*/", i + 2)
            stop = n if end < 0 else end + 2
            line += text.count("\n", i, stop)
            buf.append(" ")                       # a comment separates two tokens
            i = stop
        elif c == ";":
            s = "".join(buf).strip()
            if s:
                out.append((start or line, s))
            buf, start = [], 0
            i += 1
        else:
            if c == "\n":
                line += 1
            elif not start and not c.isspace():
                start = line
            buf.append(c)
            i += 1
    s = "".join(buf).strip()
    if s:
        out.append((start or line, s))
    return out


# A table name as MySQL takes it: `name` or name, either one qualified with its schema -
# a plant dump writes `iw_plant_server3`.`iw_par_x_param` (2026-10-24).
_NAME = r"(?:`[^`]*`|\w+)"
_TABLE = rf"(?:{_NAME}\s*\.\s*)?`?(\w+)`?"
# INSERT IGNORE is what a dump that must not overwrite writes; the priority words are
# the rest of MySQL's INSERT/REPLACE grammar between the verb and INTO
_HEAD = re.compile(rf"(INSERT|REPLACE)\s+(?:(?:LOW_PRIORITY|DELAYED|HIGH_PRIORITY)\s+)?"
                   rf"(?:IGNORE\s+)?INTO\s+{_TABLE}\s*(?:\(([^)]*)\))?\s*"
                   r"VALUES?\s*(.*)", re.IGNORECASE | re.DOTALL)
_NOW = re.compile(r"NOW\s*\(\s*\)", re.IGNORECASE)
_TRUNCATE = re.compile(rf"TRUNCATE\s+(?:TABLE\s+)?{_TABLE}\s*$", re.IGNORECASE)
_CREATE = re.compile(rf"CREATE\s+(?:TEMPORARY\s+)?TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?{_TABLE}",
                     re.IGNORECASE)
# sqlout.group_cleanup_sql: a modern script clears its own group rows first, which the
# regenerated script does again - read, not lost
_GROUP_CLEANUP = re.compile(rf"DELETE\s+FROM\s+{_TABLE}\s+WHERE\s+`?type`?\s*=\s*"
                            r"'default_link'", re.IGNORECASE)
# session settings and dump scaffolding: nothing in them is part of a list
_NOISE = re.compile(r"(?:SET|LOCK\s+TABLES?|UNLOCK\s+TABLES?|START\s+TRANSACTION|BEGIN|"
                    r"COMMIT|ROLLBACK|USE)\b", re.IGNORECASE)
# sqlout.replace_list_sql: the bound rows of every unit in one group go first. A script
# that writes iw_sys_plant_units rows names those units ahead of the subquery,
# "WHERE (`unit_id` IN (...) OR `unit_id` IN (SELECT ...))", so the list is optional. An
# update's DELETE (sqlout.update_bound_sql) reads grp_name IN (...) and never matches.
_REPLACE_LIST = re.compile(
    rf"DELETE\s+FROM\s+(?:{_NAME}\s*\.\s*)?`?iw_gen_driver_parameters`?\s+WHERE\s+"
    r"(?:\(.*?\bOR\s+)?`?unit_id`?\s+IN\s*\(\s*SELECT\s+`?unit_id`?\s+FROM\s+"
    rf"(?:{_NAME}\s*\.\s*)?`?iw_sys_plant_units`?\s+"
    r"WHERE\s+`?grp_name`?\s*=\s*('(?:[^'\\]|''|\\.)*')", re.IGNORECASE | re.DOTALL)
# a bare value MySQL takes in a VALUES list; in a legacy INSERT anything else is the
# remains of a text an undoubled apostrophe cut short
_BARE = re.compile(r"[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][-+]?\d+)?|NULL|DEFAULT|TRUE|FALSE"
                   r"|0x[0-9A-Fa-f]+|[xXbB]'[0-9A-Fa-f]*'|CURRENT_\w+|\w+\s*\(\s*\)"
                   r"|_\w+\s*'.*'", re.IGNORECASE | re.DOTALL)


def _string(text: str, i: int) -> tuple[str, int]:
    """The string literal opening at text[i] -> (its value, the index after it)."""
    quote, n = text[i], len(text)
    i += 1
    parts: list[str] = []
    while i < n:
        c = text[i]
        if c == "\\" and i + 1 < n:
            nxt = text[i + 1]
            parts.append("\\" + nxt if nxt in "%_" else _ESCAPES.get(nxt, nxt))
            i += 2
            continue
        if c == quote:
            if i + 1 < n and text[i + 1] == quote:
                parts.append(quote)
                i += 2
                continue
            i += 1
            break
        parts.append(c)
        i += 1
    return "".join(parts), i


def _parse_values(text: str, line: int = 0, strict: bool = False) -> list[list[str]]:
    """All parenthesized value tuples of one statement. Strings keep their content
    (quotes removed, escapes resolved); NULL is the empty string - every column these
    tables have is NOT NULL text, and an absent value reads as one; other bare tokens
    (ints, NOW()) come back verbatim. The list ends at the first thing after a tuple
    that is not another tuple, so a trailing ON DUPLICATE KEY UPDATE adds no rows.
    `strict` (a legacy INSERT) refuses a bare word, naming its line."""
    rows: list[list[str]] = []
    i, n = 0, len(text)
    while True:
        while i < n and text[i] in " \t\r\n,":
            i += 1
        if i >= n or text[i] != "(":
            break
        i += 1
        row: list[str] = []
        while i < n:
            while i < n and text[i] in " \t\r\n,":
                i += 1
            if i >= n:
                break
            if text[i] == ")":
                i += 1
                break
            if text[i] in "'\"":
                value, i = _string(text, i)
                row.append(value)
            else:
                m = _NOW.match(text, i)
                if m:
                    row.append("NOW()")
                    i = m.end()
                else:
                    j = i
                    while j < n and text[j] not in ",)":
                        j += 1
                    token = text[i:j].strip()
                    if strict and token and not _BARE.fullmatch(token):
                        raise _unescaped_quote(line + text.count("\n", 0, i),
                                               f"{token[:40]!r} is neither a quoted text "
                                               f"nor a number")
                    row.append("" if token.upper() == "NULL" else token)
                    i = j
        rows.append(row)
    return rows


@dataclass
class _Script:
    """What _scan found: the rows of every table, and what else the script does."""
    by_table: dict = field(default_factory=dict)     # table -> [row dict]
    statements: dict = field(default_factory=dict)   # table -> [(line, statement)]
    legacy: bool = False
    truncated: set = field(default_factory=set)      # tables it truncates
    deletes: list = field(default_factory=list)      # grp_names replace_list clears
    created: set = field(default_factory=set)        # tables it creates
    unread: list = field(default_factory=list)       # (line, statement) not read at all
    wide: list = field(default_factory=list)         # rows with more values than columns


def _scan(text: str) -> _Script:
    """Group every INSERT/REPLACE row by target table, and note what else the script
    does to the list."""
    sc = _Script()
    for line, st in _statements(text):
        m = _HEAD.match(st)
        if not m:
            if (t := _TRUNCATE.match(st)):
                sc.truncated.add(t.group(1))
            elif (d := _REPLACE_LIST.match(st)):
                sc.deletes.append(_string(d.group(1), 0)[0])
            elif (c := _CREATE.match(st)):
                sc.created.add(c.group(1))
            elif _GROUP_CLEANUP.match(st) or _NOISE.match(st):
                pass
            else:
                sc.unread.append((line, st))
            continue
        verb, table, collist, values = m.groups()
        if verb.upper() == "INSERT" and table.startswith("iw_par_"):
            sc.legacy = True
        if collist:
            names = [c.strip().strip("`").lower() for c in collist.split(",")]
        elif table.startswith("iw_par_") and table.endswith("_param"):
            names = PARAM_COLS
        elif table.startswith("iw_par_") and table.endswith("_groups"):
            names = GROUP_COLS
        elif table.startswith("iw_set_"):
            names = SET_COLS
        else:
            sc.unread.append((line, st))  # positional insert into a table nothing names
            continue
        rows = sc.by_table.setdefault(table, [])
        sc.statements.setdefault(table, []).append((line, st))
        first = line + st[:m.start(4)].count("\n")
        for vals in _parse_values(values, first, strict=verb.upper() == "INSERT"):
            if len(vals) > len(names):
                sc.wide.append(f"line {line}: {len(vals)} values for the {len(names)} "
                               f"columns of {table}")
            if len(vals) < len(names):    # tolerate truncated legacy rows
                vals = vals + [""] * (len(names) - len(vals))
            rows.append(dict(zip(names, vals)))
    return sc


def _clip(statement: str, width: int = 90) -> str:
    one = " ".join(statement.split())
    return one if len(one) <= width else one[:width - 3] + "..."


# ---------------------------------------------------------------------------
# reconstruction
# ---------------------------------------------------------------------------

def _expected_settings(comm: dict) -> dict[str, set[str]]:
    """Every iw_sys_plant_settings value the regenerated script can write, given the
    comm block read back - what sqlout writes, in either format, and nothing else."""
    c = Comm(**comm)
    out: dict[str, set[str]] = {}
    for name, value, _unit, _help in MODERN_SETTINGS:
        if value is not None:
            out.setdefault(name, set()).add(value)
    for name, value, _unit, _help in FIXED_SETTINGS + FIXED_SETTINGS_TAIL:
        out.setdefault(name, set()).add(value)
    parity = str(c.parity)
    out.update({
        "comm_port": {str(c.com_port)},
        "comm_parity": {PARITY_NUM.get(parity.lower(), parity), parity},
        "comm_data_bits": {str(c.data_bits)},
        "comm_stop_bits": {str(c.stop_bits)},
        "comm_baudrate": {str(c.baudrate)},
        "mb_mode": {"0" if c.mode == "rtu" else "2"},
        # the first server line: modern writes a placeholder for no IP, legacy nothing
        "mb_tcp_servers": {f"1;{c.ip or 'XXX.XXX.XXX.XXX'};{c.port};1000;2;1000",
                           f"1;{c.ip};{c.port};1000;2;1000"},
    })
    return out


def _system_block(by_table: dict, table: str, notes: list,
                  legacy: bool = False) -> dict | None:
    units = by_table.get("iw_sys_plant_units", [])
    settings: dict[str, dict] = {}
    repeated: list[str] = []
    for r in by_table.get("iw_sys_plant_settings", []):
        name = r.get("setting", "")
        if name in settings:
            repeated.append(name)         # the first row is the one the script ends with
            continue
        settings[name] = r
    if not units and not settings:
        return None

    sys: dict = {"units": bool(units), "settings": bool(settings)}
    lost: list[str] = []
    owner = ""
    if units:
        first = units[0]
        owner = first.get("driver_type", "")
        reg, order = first.get("regulator_type", ""), first.get("order_no", "")
        sys["reg_type"], sys["order_no"] = reg, order
        # driver_addr is <server or bus>_<slave>. The project holds one prefix for every
        # unit, and only 0_ (RTU) or 1_ (the one TCP server it registers): a unit behind
        # a second server, or a mix, takes the prefix the most units share - and says so
        parsed = []
        for u in units:
            addr = str(u.get("driver_addr", ""))
            pm = re.fullmatch(r"(\d+_)(.*)", addr)
            parsed.append((pm.group(1), pm.group(2)) if pm else ("", addr))
        prefixes = [pfx for pfx, _bare in parsed]
        usable = [pfx for pfx in prefixes if pfx in ("0_", "1_")]
        if len(set(prefixes)) == 1 and prefixes[0] in ("0_", "1_", ""):
            prefix = prefixes[0]
        elif usable:
            prefix = max(dict.fromkeys(usable), key=usable.count)
        else:
            mode = settings.get("mb_mode", {}).get("value", "")
            prefix = "0_" if mode == "0" else "1_"
        sys["driver_addr_prefix"] = prefix
        rows, grp_names = [], []
        for k, (u, (pfx, bare)) in enumerate(zip(units, parsed), start=1):
            uid = u.get("unit_id", "")
            who = f"unit {uid}" if uid else f"unit row {k}"
            if pfx != prefix:
                lost.append(f"{who} driver_addr '{u.get('driver_addr', '')}' -> "
                            f"'{prefix}{bare}'")
            vo = str(u.get("view_order", "0")).strip()
            if not vo.isdigit():
                lost.append(f"{who} view_order '{vo}' -> '0'")
            rows.append({"unit_id": uid, "unit_name": u.get("unit_name", ""),
                         "driver_addr": bare, "view_order": int(vo) if vo.isdigit() else 0})
            # what the generator writes on every unit row, whatever the project says
            for column, want in (("active", "1"), ("blockout", "0"),
                                 ("driver_type", owner), ("regulator_type", reg),
                                 ("order_no", order), ("driver_adr_extra", ""),
                                 ("unit_extra", "")):
                if column in u and str(u[column]) != want:
                    lost.append(f"{who} {column} '{u[column]}' -> '{want}'")
            grp = u.get("grp_name", "")
            if grp and grp != table:
                grp_names.append(f"'{grp}' ({who})")
        sys["unit_list"] = rows
        if grp_names:
            notes.append(Note(
                f"iw_sys_plant_units grp_name {', '.join(grp_names)} differs from the "
                f"table name '{table}'", code="unit-grp-name-differs", kind=REPAIRED,
                count=len(grp_names),
                advice="Check which name the plant database actually uses; the two "
                       "disagreed in the delivery and the table name won."))
    if not sys.get("order_no"):
        order_rows = by_table.get("iw_sys_order_no", [])
        if order_rows:
            sys["order_no"] = order_rows[0].get("order_no", "")
    if not owner and settings:
        owner = next(iter(settings.values())).get("owner", "")
    if not owner:
        proc = by_table.get("iw_sys_processes", [])
        if proc:
            owner = proc[0].get("process_name", "")
    sys["owner"] = owner

    for r in by_table.get("iw_sys_order_no", []):
        if not units:
            lost.append(f"iw_sys_order_no '{r.get('order_no', '')}' (written only with "
                        f"the unit rows)")
            continue
        for column, want in (("order_no", sys.get("order_no", "")),
                             ("db_link", f"{table}_param"), ("group_link", f"{table}_groups")):
            if column in r and str(r[column]) != want:
                lost.append(f"iw_sys_order_no {column} '{r[column]}' -> '{want}'")
    for r in by_table.get("iw_sys_processes", []):
        if not settings:
            lost.append(f"iw_sys_processes '{r.get('process_name', '')}' (written only "
                        f"with the settings)")
            continue
        for column, want in (("process_name", owner), ("path", "iw_mb.exe"),
                             ("man_start", "0")):
            if column in r and str(r[column]) != want:
                lost.append(f"iw_sys_processes {column} '{r[column]}' -> '{want}'")

    if settings:
        comm: dict = {}
        comm["mode"] = "rtu" if settings.get("mb_mode", {}).get("value") == "0" else "tcp"
        comm["com_port"] = settings.get("comm_port", {}).get("value", "")
        par = settings.get("comm_parity", {}).get("value", "")
        comm["parity"] = PARITY_NAME.get(par, par.lower() or "even")
        for key, name in (("comm_data_bits", "data_bits"),
                          ("comm_stop_bits", "stop_bits"),
                          ("comm_baudrate", "baudrate")):
            v = settings.get(key, {}).get("value", "")
            if str(v).lstrip("-").isdigit():
                comm[name] = int(v)
        # one server per line, ID;IPadr;IPport;ConnTout;ConnRetries;RequestTout. The
        # legacy writer ends the line with \r\n, which MySQL - and so this reader - turns
        # into a real line break; written with the backslash escaped it stays literal
        # text. Either separates two servers.
        servers = settings.get("mb_tcp_servers", {}).get("value", "")
        lines = [ln.strip() for ln in re.split(r"\r\n|\r|\n|\\r\\n|\\n", servers)
                 if ln.strip()]
        parts = lines[0].split(";") if lines else []
        if len(parts) >= 3:
            if parts[1] and "XXX" not in parts[1].upper():
                comm["ip"] = parts[1]
            if parts[2].isdigit():
                comm["port"] = int(parts[2])
        if len(lines) > 1:
            notes.append(Note(
                f"mb_tcp_servers lists {len(lines)} servers and a project holds one - kept "
                f"the first ({lines[0]}), dropped {'; '.join(repr(ln) for ln in lines[1:])}",
                code="tcp-servers-dropped", kind=DROPPED, count=len(lines) - 1,
                advice="system.comm has one ip and port, so the regenerated script "
                       "registers only the first server. Add the others to the plant's "
                       "iw_sys_plant_settings by hand after importing the script."))
        sys["comm"] = comm

        # every value the regenerated script would write differently: the tool writes
        # its own timeouts, retries and the rest (sqlout.MODERN_SETTINGS), so a plant's
        # mb_request_timeout 3000 used to come back as 1000 without a word
        expected = _expected_settings(comm)
        for name, r in settings.items():
            value = r.get("value", "")
            if name == "mb_tcp_servers":
                value = lines[0] if lines else ""
            if name not in expected:
                lost.append(f"setting {name} '{value}' (the tool writes no such setting)")
            elif value not in expected[name]:
                want = sorted(expected[name])[0]
                lost.append(f"setting {name} '{value}' -> '{want}'")
            if r.get("owner", owner) != owner:
                lost.append(f"setting {name} owner '{r.get('owner')}' -> '{owner}'")
        for name in repeated:
            lost.append(f"setting {name} repeated (the first row kept)")
        # a legacy script lacks the two settings only modern writes: that is the format,
        # which the legacy-format note already names
        legacy_names = {"comm_port", "mb_tcp_servers", "mb_mode", "comm_parity",
                        "comm_data_bits", "comm_stop_bits", "comm_baudrate"} | {
            name for name, *_rest in FIXED_SETTINGS + FIXED_SETTINGS_TAIL}
        added = [name for name, *_rest in MODERN_SETTINGS if name not in settings
                 and (not legacy or name in legacy_names)]
        if added:
            notes.append(Note(
                f"the script sets {len(settings)} driver setting(s); the regenerated script "
                f"writes all {len(MODERN_SETTINGS)}, so {len(added)} more get the tool's "
                f"own values ({few(added)})", code="settings-added", kind=REPAIRED,
                count=len(added),
                advice="The plant may hold its own values for those settings, which the "
                       "regenerated script overwrites. Check them on the plant before "
                       "running it, or switch system.settings off to leave the driver "
                       "settings alone."))
    if lost:
        shown = "; ".join(lost[:10]) + (f" (+{len(lost) - 10} more)" if len(lost) > 10 else "")
        notes.append(Note(
            f"{len(lost)} iw_sys value(s) the project cannot hold - the regenerated script "
            f"writes its own instead: {shown}", code="system-values-dropped", kind=DROPPED,
            count=len(lost),
            advice="system holds one owner, regulator type and order number for every "
                   "unit, one prefix, one TCP server and the driver settings the tool "
                   "writes itself; a unit's active and blockout flags are the plant's. "
                   "Set those values on the plant by hand after the import, or leave "
                   "system.units and system.settings off so the script does not touch "
                   "them."))
    return sys


def _carry_clean_out(table: str, truncated: set[str], deletes: list[str],
                     options: dict, notes: list) -> None:
    """What the script does to the old list before writing the new one, as options.

    Both used to parse and vanish: a script that emptied its three tables, or deleted
    the old list's bound rows first (sqlout.replace_list_sql), came back as a project
    whose script did neither, so rows the list had dropped stayed on the plant.
    """
    three = {f"iw_par_{table}_groups", f"iw_par_{table}_param", f"iw_set_{table}"}
    replacing = table in deletes
    if replacing:
        options["replace_list"] = True
        notes.append(Note(
            f"the script deletes the old list first - the bound rows of every unit in "
            f"group '{table}' (iw_gen_driver_parameters), then its three tables - so "
            f"options.replace_list is set to true", code="replace-list-carried", kind=INFO,
            advice="The regenerated script deletes them too. Back the plant up before "
                   "running it, or switch replace_list off to only add and overwrite rows."))
    foreign = sorted(set(deletes) - {table})
    if foreign:
        notes.append(Note(
            f"the script deletes the bound rows of group(s) {', '.join(foreign)} - not this "
            f"list's '{table}', so not carried", code="delete-not-carried", kind=DROPPED,
            count=len(foreign),
            advice="A project clears only its own list. Delete those rows by hand if that "
                   "is still wanted."))
    if truncated >= three and not replacing:      # replace_list implies the truncation
        options["truncate"] = True
        notes.append(Note(
            f"the script empties {', '.join(sorted(three))} before writing them - "
            f"options.truncate is set to true", code="truncate-carried", kind=INFO,
            advice="The regenerated script empties them too, so rows the list no longer "
                   "has leave the template. Switch truncate off to keep them instead."))
    lost = sorted(truncated - three) if truncated >= three else sorted(truncated)
    if lost:
        notes.append(Note(
            f"the script truncates {', '.join(lost)}, which a project cannot say - it "
            f"empties its own three tables together or not at all - so not carried",
            code="truncate-not-carried", kind=DROPPED, count=len(lost),
            advice="The regenerated script leaves those tables as they are. Empty them by "
                   "hand if the plant needs it, or set truncate to empty all three."))


def _expected_extra(dt, addr: int, rw: str, bit) -> str:
    """driver_id_extra as rules.driver_id_extra writes it with subtract_one off."""
    if bit is not None or rw not in ("r", "rw"):
        return ""
    read_half = f"{dt.read_func}_{addr}_{dt.raw_type}_{dt.read_swap}"
    if rw == "rw":
        return f"{read_half}_{dt.write_func}_{addr}_{dt.raw_type}_{dt.write_swap}"
    return f"{read_half}_-_-_-_-"


def _extra_explained(expected: str, delivered: str, differs: list[str]) -> bool:
    """Whether the datatype-nearest note already says why the extras differ: only the
    write function or swap, on a row matched to the closest key."""
    ex, de = expected.split("_"), delivered.split("_")
    return (len(ex) == len(de) == 8 and ex[:4] == de[:4] and ex[5:7] == de[5:7]
            and bool({"write function", "write swap"} & set(differs)))


# The function codes and registers driver_id_extra names: what iw_mb.exe reads and
# writes. driver_id names a register as well, but the driver never reads that part of
# it (docs/15 section 2: X_Y_Z is unused), so a list modbusgen did not write can hold
# two different ones. Plant 3487 (2026-10-29) read every point one register below the
# index its driver_id, element_id and menu carried.
_EXTRA_REGISTERS = re.compile(r"(\d+)_(\d+)_[A-Za-z0-9]+_[A-Za-z]_"
                              r"(?:(\d+)_(\d+)_[A-Za-z0-9]+_[A-Za-z]|-_-_-_-)")


def _polled_elsewhere(extra: str, read_func: str, addr: int):
    """(read function, register, write function, write register) from driver_id_extra
    when it reads or writes another register than driver_id names, else None."""
    m = _EXTRA_REGISTERS.fullmatch(extra or "")
    if not m:
        return None
    rc, rr = m.group(1), int(m.group(2))
    wc, wr = m.group(3), (int(m.group(4)) if m.group(4) is not None else None)
    if rc == read_func and rr == addr and wr in (None, addr):
        return None
    return rc, rr, wc, wr


def _as_named(extra: str, want: str) -> str:
    """driver_id_extra with its read function and registers set to what driver_id
    names, so that comparing it with the regenerated one sees only the other columns:
    the register difference has a note of its own."""
    ex, wa = extra.split("_"), want.split("_")
    if len(ex) != 8 or len(wa) != 8:
        return extra
    for i in (0, 1, 5):
        if ex[i] != "-":
            ex[i] = wa[i]
    return "_".join(ex)


def import_sql(text: str) -> tuple[dict, list[str]]:
    """Generated SQL text -> (project dict, notes). Raises SqlImportError when the
    text holds no recognizable generated list."""
    notes: list[str] = []
    tables = Tables()
    rev_units = _reverse_units(tables)
    rev_scale = _reverse_scaling(tables)
    sc = _scan(text)
    by_table = sc.by_table

    param_tables = [t for t in by_table
                    if t.startswith("iw_par_") and t.endswith("_param")]
    if not param_tables:
        raise SqlImportError("no iw_par_<table>_param INSERT/REPLACE found - "
                             "this is not a generated Modbus list script")
    if len(param_tables) > 1:
        raise SqlImportError(f"script fills more than one list "
                             f"({', '.join(sorted(param_tables))}) - split it first")
    table = param_tables[0][len("iw_par_"):-len("_param")]
    own = {f"iw_par_{table}_groups", f"iw_par_{table}_param", f"iw_set_{table}"}
    if sc.legacy:
        notes.append(Note("legacy INSERT format detected - the project regenerates in the "
                     "modern REPLACE format unless options.sql_format is set to legacy",
            code="legacy-format", kind=INFO,
            advice="Nothing to do. The project regenerates in the modern REPLACE INTO house style, which is a deliberate divergence (docs/10), not a loss."))

    # what a point cannot carry: the regenerated rows write something else there
    lost: dict[str, list[str]] = {}

    def lose(column: str, what: str) -> None:
        lost.setdefault(column, []).append(what)

    sets = {r.get("element_id", ""): r for r in by_table.get(f"iw_set_{table}", [])}
    # The groups block: a point belongs to one group, at one position in it. A second
    # membership, a second position, a second alias row or a row of a type the tool
    # never writes cannot come back, and used to vanish (review, 2026-10-24).
    membership: dict[str, tuple[str, int, int]] = {}   # element_id -> (ref, view_order, row)
    groups: dict[str, dict] = {}
    group_lost: list[str] = []
    for k, r in enumerate(by_table.get(f"iw_par_{table}_groups", [])):
        kind, ref, value = r.get("type", ""), r.get("ref", ""), r.get("value", "")
        vo = str(r.get("view_order", "")).strip()
        if kind == "group_alias" and ref:
            if ref in groups:
                group_lost.append(f"a second alias row for group '{ref}' ('{value}')")
                continue
            groups[ref] = {"alias": value,
                           "order": int(vo) if vo.isdigit() else len(groups) + 1}
        elif kind == "group" and value:
            if value in membership:
                where = membership[value][0]
                group_lost.append(f"{value} at a second position in '{ref}'" if where == ref
                                  else f"{value} also in '{ref}' (kept in '{where}')")
                continue
            membership[value] = (ref, int(vo) if re.fullmatch(r"-?\d+", vo) else 0, k)
        elif kind != "default_link":
            group_lost.append(f"a '{kind}' row ({ref} {value})".replace(" )", ")"))

    points: list[dict] = []
    statetexts: dict[int, dict[int, str]] = {}
    json_ids: dict[str, int] = {}
    skipped = 0
    unresolved: list[str] = []
    rebuilt: dict = {}
    rebuilt_rows: dict[str, list[str]] = {}
    near: list[tuple[str, list[str]]] = []
    custom_units: list[str] = []
    respelled_units: list[str] = []
    lost_formats: list[str] = []
    lost_scales: list[str] = []
    bad_json: list[str] = []
    no_set = 0
    save_divergent = 0
    alarm_type_seen = 0
    eid_of: dict[int, str] = {}           # id(point) -> its element_id in the script
    set_of: dict[int, dict] = {}          # id(point) -> its iw_set row
    param_ids: set[str] = set()
    # rows whose driver_id_extra reads or writes another register than driver_id names:
    # (element_id, text, driver_id's read function, driver_id's register, what is polled)
    elsewhere: list[tuple[str, str, str, int, tuple]] = []

    for r in by_table[f"iw_par_{table}_param"]:
        did = r.get("driver_id", "")
        param_ids.add(r.get("element_id", ""))    # a row reported below is not orphaned
        m = re.fullmatch(r"0_(\d+)_(\d+)(?:\.([\d#]+))?", did)
        if not m:
            skipped += 1
            continue
        read_func, addr, bit = m.group(1), int(m.group(2)), m.group(3)

        facts = parse_extra(r.get("driver_id_extra", ""))
        datatype, differs = _match_datatype(
            tables, read_func, r.get("application", ""), bit=bit,
            parameter_type=r.get("parameter_type") or None, **facts)
        if datatype is None:
            # a project's own datatype: rebuilt from the columns, counted once - it used
            # to be counted again among the rows "without a decodable driver_id"
            datatype = rebuild_datatype(tables, rebuilt, read_func, r.get("application", ""),
                                        r.get("parameter_type", ""), facts)
            if datatype is None:
                unresolved.append(str(did))
                continue
            rebuilt_rows.setdefault(datatype, []).append(str(did))
        if differs:
            near.append((str(did), differs))
        dt = tables.datatypes.get(datatype) or rebuilt[datatype]

        eid = r.get("element_id", "")
        mem = membership.get(eid)
        group = mem[0] if mem else ""
        if not group and eid.endswith(f"_{did}"):
            group = eid[:-len(did) - 1]
        p: dict = {"group": group, "datatype": datatype, "addr": addr,
                   "text": r.get("alias_text", "")}
        if bit is not None:
            p["bit"] = int(bit) if bit.isdigit() else bit
        p["rw"] = rw_from_att(r.get("att", ""), bit is not None)
        if eid and eid != f"{group}_{did}":
            p["element_id"] = eid
        if r.get("menu"):
            p["menu"] = r["menu"]
        if r.get("eng_unit"):
            p["unit"] = keep_unit(r["eng_unit"], rev_units, tables,
                                  custom_units, respelled_units)
        fm = re.fullmatch(r"%\.(\d)f", r.get("format", ""))
        if fm and int(fm.group(1)) <= 3:
            p["decimals"] = int(fm.group(1))
        elif r.get("format"):
            lost_formats.append(str(r["format"]))
        scale_key = rev_scale.get((r.get("scale", ""), r.get("raw_min", ""),
                                   r.get("raw_max", ""), r.get("eng_min", ""),
                                   r.get("eng_max", "")))
        if scale_key:
            p["scale"] = scale_key
        elif r.get("scale"):
            lost_scales.append(f"{r.get('scale')},{r.get('raw_min')}.."
                               f"{r.get('raw_max')}->{r.get('eng_min')}.."
                               f"{r.get('eng_max')}")
        for name in ("range_min", "range_max"):
            if r.get(name):
                p[name] = r[name]

        # the columns the generator writes the same on every row, or derives
        stub = Point(addr=addr, rw=p["rw"], bit=p.get("bit"), text=p["text"])
        if r.get("factory_setting", ""):
            lose("factory_setting", f"{eid} '{r['factory_setting']}' -> ''")
        if r.get("grp", "-1") != "-1":
            lose("grp", f"{eid} '{r.get('grp')}' -> '-1'")
        if (got := r.get("att", "")) != (want := point_att(stub)):
            lose("att", f"{eid} '{got}' -> '{want}'")
        extra = r.get("driver_id_extra", "")
        want = _expected_extra(dt, addr, p["rw"], bit)
        polled = _polled_elsewhere(extra, read_func, addr)
        if polled:
            elsewhere.append((eid, p["text"], read_func, addr, polled))
        seen = _as_named(extra, want) if polled else extra
        if seen != want and not _extra_explained(want, seen, differs):
            lose("driver_id_extra", f"{eid} '{extra}' -> '{want}'")

        s = sets.get(eid)
        if s is None:
            no_set += 1
        else:
            set_of[id(p)] = s
            alarm = s.get("plant_pri", "")
            if alarm.upper() in ALARMS:
                p["alarm"] = alarm.upper()
            if alarm not in ALARMS + ("",):
                lose("plant_pri", f"{eid} '{alarm}' -> '{p.get('alarm', '')}'")
            onl = s.get("onl_ind", "")
            if onl == "1":
                p["online"] = True
            elif onl != "0":
                lose("onl_ind", f"{eid} '{onl}' -> '0'")
            if s.get("active") == "0":
                p["active"] = 0
            derived = derive_update_freq(stub, dt.application)
            freq = s.get("update_freq", "")
            if freq != derived and freq in FREQS:
                p["update_freq"] = freq
            elif freq != derived:
                # '' on a coil, or a value outside the column's set: a project says one of
                # the five or nothing, and nothing derives slow there
                lose("update_freq", f"{eid} '{freq}' -> '{derived}'")
            eff = freq if freq in FREQS else derived
            if save_fields(eff, point_att(stub), dt.application) != \
                    (s.get("save_data", ""), s.get("save_freq", "")):
                save_divergent += 1
            if s.get("sys_pri", ""):
                lose("sys_pri", f"{eid} '{s['sys_pri']}' -> ''")
            if s.get("alarm_type", "0").strip("'") not in ("0", ""):
                alarm_type_seen += 1

        fx = r.get("format_extra", "")
        if fx.startswith("{"):
            if fx not in json_ids:
                try:
                    states = {int(n): v["t"]
                              for n, v in json.loads(fx)["v"].items()}
                    sid = len([v for v in json_ids.values() if v]) + 1
                    json_ids[fx] = sid
                    statetexts[sid] = states
                except Exception:
                    bad_json.append(str(did))
                    json_ids[fx] = 0
            if json_ids[fx]:
                p["statetext"] = json_ids[fx]
        elif fx:
            lose("format_extra", f"{eid} '{fx[:30]}' -> ''")

        eid_of[id(p)] = eid
        points.append(p)

    for eid in sets:
        if eid not in param_ids:
            lose("iw_set rows with no param row", eid)
    orphans = sorted(e for e in membership if e not in param_ids)
    if orphans:
        group_lost.append(f"{len(orphans)} membership row(s) for element_ids the param "
                          f"block does not have ({few(orphans, 3)})")
    lost_rows = list(sc.wide)

    # the rebuilt rows join every lookup below, or their points would read as unknown
    known = tables.extended(rebuilt)
    # an Excel-era list can carry a Motherword row beside the value row of the same
    # register; validation rejects the pair, so they are settled as importer_old does
    points, dropped = drop_redundant_motherwords(points, known)

    if not points:
        raise SqlImportError(f"iw_par_{table}_param held no usable rows "
                             f"({skipped} skipped, {len(unresolved)} unresolvable)")

    # --- the options the script was written with, from what its rows show ------------
    options: dict = {"subtract_one": False, "proper_case_states": False}
    inferred: list[str] = []

    def member(p) -> tuple[str, int, int] | None:
        return membership.get(eid_of[id(p)])

    # rules.generate leaves a Motherword out of its group unless the option is off
    mothers = [p for p in points if p["text"] == "Motherword"]
    grouped = [p for p in mothers if member(p)]
    if grouped:
        options["exclude_motherwords_from_groups"] = False
        inferred.append(f"exclude_motherwords_from_groups false - {len(grouped)} "
                        f"Motherword row(s) sit in a group")
    for p in points:
        if not member(p) and (p["text"] != "Motherword" or grouped):
            p["no_group"] = True

    def word(p) -> tuple[str, int]:
        dt = known.datatypes.get(p["datatype"])
        return (dt.read_func if dt else "", p["addr"])

    worded = {word(p) for p in points if "bit" not in p}
    bare = sorted({word(p) for p in points if "bit" in p and word(p)[0] in ("3", "4")}
                  - worded)
    if bare:
        options["auto_motherwords"] = False
        inferred.append(f"auto_motherwords false - {len(bare)} bit word(s) have no "
                        f"Motherword row (addr {few([str(a) for _f, a in bare], 4)})")

    # rules.active: a 'Reserve.' row is inactive whatever force_active says. The Excel
    # tool lets force_active win (docs/08 item 11), and a list can switch the rule off
    reserve_on = True
    lit = [p for p in points if p["text"] == "Reserve." and id(p) in set_of
           and set_of[id(p)].get("active") == "1"]
    if lit:
        options["reserve_text"] = ""
        reserve_on = False
        inferred.append(f"reserve_text '' - {len(lit)} 'Reserve.' row(s) are active, so "
                        f"the reserve rule did not apply (off, or overridden by the Excel "
                        f"tool's force_active)")
    off = [p for p in points if p.get("active") == 0
           and not (reserve_on and p["text"] == "Reserve.")]
    options["force_active"] = not off
    for p in points:
        s = set_of.get(id(p))
        if s is None:
            continue
        want = ("0" if reserve_on and p["text"] == "Reserve." else
                "1" if options["force_active"] or p.get("active") != 0 else "0")
        if s.get("active", "") != want:
            lose("active", f"{eid_of[id(p)]} '{s.get('active', '')}' -> '{want}'")

    if any("range_min" in p or "range_max" in p for p in points):
        options["include_minmax"] = True
    if sc.legacy and sc.created & own:
        options["create_tables"] = True
        inferred.append("create_tables true - the legacy script creates its tables "
                        "(Main_Setup!B25)")
    _carry_clean_out(table, sc.truncated, sc.deletes, options, notes)
    if sc.legacy and not (sc.truncated & own) and table not in sc.deletes:
        # legacy truncates unless told not to; modern only when told to. False says both
        options["truncate"] = False
        notes.append(Note(
            "the legacy script does not empty its tables before writing them, as the "
            "Excel tool writes it with Main_Setup!B23 off - options.truncate is set to "
            "false", code="legacy-truncate-off", kind=INFO,
            advice="Nothing to do in the modern format, which never empties them unasked. "
                   "A project file saved in the modern format leaves truncate: false out "
                   "as its default, so set it again if you switch that file to sql_format "
                   "legacy - unset, the legacy script empties the three tables."))

    # --- each group's points in the order its rows give them --------------------------
    # The point order is the param order, and generation numbers each group's points
    # 3, 6, 9 ... in it; the group rows' own view_order used to be ignored, so a list
    # whose groups ran in another order regenerated in param order (review, 2026-10-24)
    slots: dict[str, list[int]] = {}
    for i, p in enumerate(points):
        if member(p) and not p.get("no_group"):
            slots.setdefault(member(p)[0], []).append(i)
    ordered_points = list(points)
    renumbered: list[str] = []
    for ref, idx in slots.items():
        by_position = sorted(idx, key=lambda i: member(points[i])[1:])
        for slot, src in zip(idx, by_position):
            ordered_points[slot] = points[src]
        if [member(points[i])[1] for i in by_position] != \
                list(range(3, 3 * len(idx) + 1, 3)):
            renumbered.append(ref)
    points = ordered_points

    # one note per family: a delivery with 300 unmapped units used to be 300 notes
    if unresolved:
        notes.append(unresolvable_note(unresolved))
    if (note := rebuilt_datatypes_note(rebuilt_rows, "SQL")):
        notes.append(note)
    if (note := nearest_datatype_note(near)):
        notes.append(note)
    if dropped:
        notes.append(motherwords_dropped_note(dropped))
    notes += unit_notes(custom_units, respelled_units)
    if lost_formats:
        notes.append(formats_dropped_note(lost_formats))
    if lost_scales:
        notes.append(Note(
            f"{len(lost_scales)} point(s) had a scaling with no table key - dropped "
            f"({few(lost_scales)})", code="scale-unmapped", kind=DROPPED,
            count=len(lost_scales),
            advice="Those points now read raw. Add the factor to "
                   "data/tables/scaling.csv, or check whether the delivered scaling was "
                   "itself wrong - a scale nothing in the table matches is unusual."))
    if bad_json:
        notes.append(Note(
            f"{len(bad_json)} point(s) had unparseable format_extra JSON - dropped "
            f"(driver_id {few(bad_json)})", code="statetext-unparseable",
            kind=DROPPED, count=len(bad_json),
            advice="Those points lost their state texts and will show raw numbers. "
                   "Re-author the lists in `statetexts` from the device document."))
    if skipped:
        notes.append(Note(
            f"skipped {skipped} row(s) without a decodable driver_id",
            code="rows-skipped", kind=DROPPED, count=skipped,
            advice="Reconcile that count against the source script before claiming the "
                   "list is complete (docs/11 coverage accounting)."))
    if no_set:
        notes.append(Note(f"{no_set} point(s) had no iw_set_{table} row - polling, alarm "
                     f"and active flags fall back to derived values",
            code="set-rows-missing", kind=REPAIRED,
            advice="Those points got derived polling, alarm and save settings instead of delivered ones. Check update_freq on anything that was deliberately slow."))
    if save_divergent:
        notes.append(Note(f"{save_divergent} point(s) carried save_data/save_freq values "
                     f"the current logging rules will not reproduce (house rule "
                     f"2026-08-18: measured read-only points log min/1)",
            code="save-values-divergent", kind=INFO,
            advice="The delivery disagreed with the house rule. Keep the derived values unless the plant needs the delivered ones."))
    if alarm_type_seen:
        notes.append(Note(f"{alarm_type_seen} iw_set row(s) had a non-zero alarm_type - "
                     f"not representable in a project file, dropped",
            code="alarm-type-nonzero", kind=DROPPED, count=alarm_type_seen,
            advice="modbusgen writes alarm_type 0 on every row and a project has no field "
                   "for it, so the regenerated rows carry 0. Set the delivered values on "
                   "the plant by hand after the import if it relies on them."))
    if elsewhere:
        def polls(rc, rr, wc, wr) -> str:
            return f"FC{rc} {rr}" + (f", writes FC{wc} {wr}" if wc is not None else "")
        shown = "; ".join(f"{eid} '{_clip(text, 40)}' polls {polls(*pl)} where driver_id "
                          f"names FC{rf} {a}" for eid, text, rf, a, pl in elsewhere[:4])
        notes.append(Note(
            f"the plant's driver reads another register than driver_id names on "
            f"{len(elsewhere)} row(s) - iw_mb.exe polls what driver_id_extra says: {shown}"
            + (f" (+{len(elsewhere) - 4} more)" if len(elsewhere) > 4 else ""),
            code="driver-polls-elsewhere", kind=ACTION, count=len(elsewhere),
            addrs=tuple(a for _e, _t, _rf, a, _pl in elsewhere),
            advice="The project is rebuilt from driver_id, so a list generated from it "
                   "polls the registers driver_id names, not the ones the plant has been "
                   "reading: every value, alarm and write IWMAC showed for these points "
                   "came from driver_id_extra. Settle each against the vendor's table "
                   "before generating, and say which was right (docs/15 section 9). An "
                   "audit of what a plant reads compares driver_id_extra, never driver_id, "
                   "element_id or menu: those are labels."))
    notes.append(Note("addresses imported as protocol addresses (from driver_id); "
                 "subtract_one is set to false",
        code="addresses-are-protocol", kind=ACTION,
        advice="subtract_one is false because driver_id already holds protocol addresses. Do not turn it on and do not adjust the addresses by hand - either shifts every point."
               + (f" The {len(elsewhere)} row(s) under driver-polls-elsewhere are the "
                  f"exception: the plant reads them at another register, so settle "
                  f"those first." if elsewhere else "")))
    notes.append(Note(
        "plant number is not stored in SQL - set it before generating",
        code="plant-number-missing", kind=ACTION,
        advice="Set the plant number before generating. The SQL never carried it, so "
               "nothing can recover it from the script."))

    used = {p["group"] for p in points if p.get("group")}
    for name in sorted(used - set(groups)):
        groups[name] = {"alias": name, "order": len(groups) + 1}
        notes.append(Note(f"group '{name}' had no group_alias row - added with its own "
                     f"name as alias",
            code="group-alias-added", kind=REPAIRED,
            advice="The key is standing in as the operator-facing name. Rename each alias to what the operator should see before shipping."))
    ordered = dict(sorted(groups.items(), key=lambda kv: kv[1]["order"]))
    if [g["order"] for g in ordered.values()] != list(range(1, len(ordered) + 1)):
        notes.append(Note("group alias view orders are not contiguous - the GUI renumbers "
                     "them by position on save",
            code="group-order-renumbered", kind=INFO,
            advice="Saving from the GUI renumbers them contiguously, which changes display order only, not identity."))
    if renumbered:
        notes.append(Note(
            f"the group rows of {len(renumbered)} group(s) ({few(renumbered, 4)}) number "
            f"their points other than 3, 6, 9 ... - the points are in the order those rows "
            f"give, and the regenerated rows number them that way",
            code="group-positions-renumbered", kind=INFO, count=len(renumbered),
            advice="Nothing to do: the operator sees the same order. Only the view_order "
                   "numbers in the regenerated group rows differ."))
    if group_lost:
        notes.append(Note(
            f"dropped {len(group_lost)} group row(s) a project cannot hold - a point "
            f"belongs to one group, at one position: {'; '.join(group_lost[:6])}"
            + (f" (+{len(group_lost) - 6} more)" if len(group_lost) > 6 else ""),
            code="group-rows-dropped", kind=DROPPED, count=len(group_lost),
            advice="The regenerated script writes each point into its first group only. "
                   "Add the other memberships on the plant by hand if the operator needs "
                   "a point in two menus, or give it a second point of its own."))

    if inferred:
        notes.append(Note(
            "options the rows show the script was written with: " + "; ".join(inferred),
            code="options-inferred", kind=INFO, count=len(inferred),
            advice="Nothing to do: the regenerated script repeats what the delivered one "
                   "did. Change an option afterwards only to change that behaviour."))

    statements = list(sc.unread)
    for name, entries in sc.statements.items():
        if name not in own and name not in SYS_TABLES:
            statements += entries
    statements.sort()
    if statements or lost or lost_rows:
        parts = []
        if statements:
            shown = "; ".join(f"line {ln}: {_clip(st)}" for ln, st in statements[:5])
            parts.append(f"{len(statements)} statement(s) it does not read ({shown}"
                         + (f"; +{len(statements) - 5} more" if len(statements) > 5 else "")
                         + ")")
        for column, rows in lost.items():
            parts.append(f"{column} on {len(rows)} row(s) ({few(rows, 3)})")
        if lost_rows:
            parts.append(f"{len(lost_rows)} row(s) with more values than columns, the rest "
                         f"ignored ({few(lost_rows, 3)})")
        count = len(statements) + sum(len(v) for v in lost.values()) + len(lost_rows)
        update = any(st.lstrip().upper().startswith("DELETE") for _ln, st in statements)
        notes.append(Note(
            "the project cannot hold everything the script says - not carried: "
            + "; ".join(parts), code="content-not-carried", kind=DROPPED, count=count,
            advice="The regenerated script does not repeat these. Apply each to the plant "
                   "by hand after the import if it is still wanted - an UPDATE or DELETE "
                   "appended to a script is not part of the list."
                   + (" A script generated as an update deletes the previous version's "
                      "rows: run generate --previous to write those deletes again."
                      if update else "")))

    known_points = unknown_datatype_notes(points, known)
    notes += known_points

    data = {"table": table, "plant": "", "options": options,
            "system": _system_block(by_table, table, notes, sc.legacy),
            "groups": ordered, "statetexts": statetexts,
            "datatypes": datatype_rows(rebuilt), "points": points}
    return data, notes


def decode_sql_bytes(raw: bytes) -> str:
    """IWMAC scripts are cp1252/latin1; tolerate re-saved UTF-8 copies."""
    try:
        return raw.decode("utf-8-sig")
    except UnicodeDecodeError:
        return raw.decode("cp1252", errors="replace")
