"""SQL script serialization, matching PrintAsString_Insert_script byte-for-byte where
docs/03-outputs.md specifies it (block order, separators, single-line quoted INSERTs,
CRLF). DIVERGENCE: values are SQL-escaped (apostrophe doubled); the Excel tool does not
escape at all (docs/08 item 21).

Beside the import script (render_sql) this module writes what an update of a list
already on a plant needs: the plan against the previous version (plan_update, read with
previous_from_project / previous_from_data / previous_from_sql), the read-only preview to
run before the import (preview_sql), the read-only verification to run after it
(verify_sql) and the change report a panel relink works from (change_report_csv). Keys
are compared the way the plant's latin1_swedish_ci tables compare them (element_key).
"""
from __future__ import annotations

import csv
import io
import operator
from dataclasses import dataclass, field, fields as dc_fields

from .model import Project
from .notes import DROPPED, INFO, Note
from .rules import GroupRecord, ParamRecord, RunResult, SetRecord

CREATE_GROUPS = ("CREATE TABLE IF NOT EXISTS `iw_par_{t}_groups` (`row_date` datetime "
    "NOT NULL DEFAULT '2004-01-10 00:00:00', `type` varchar(50) NOT NULL DEFAULT '', "
    "`view_order` mediumint(6) NOT NULL DEFAULT '0', `ref` varchar(100) NOT NULL DEFAULT '', "
    "`value` varchar(200) NOT NULL DEFAULT '', UNIQUE KEY `type` "
    "(`type`,`view_order`,`ref`,`value`)) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='2.0.0';")

CREATE_PARAM = ("CREATE TABLE IF NOT EXISTS `iw_par_{t}_param` (`row_date` datetime "
    "NOT NULL DEFAULT '2002-01-10 00:00:00', `element_id` varchar(100) NOT NULL DEFAULT '', "
    "`driver_id` varchar(100) NOT NULL DEFAULT '', `alias_text` text NOT NULL, "
    "`menu` varchar(10) NOT NULL DEFAULT '', `application` text NOT NULL, "
    "`parameter_type` text NOT NULL, `factory_setting` text NOT NULL, `grp` text NOT NULL, "
    "`att` text NOT NULL, `eng_unit` varchar(20) NOT NULL DEFAULT '', "
    "`format` varchar(20) NOT NULL DEFAULT '', `range_min` text NOT NULL, "
    "`range_max` text NOT NULL, `scale` varchar(15) NOT NULL DEFAULT '', "
    "`raw_min` varchar(15) NOT NULL DEFAULT '', `raw_max` varchar(15) NOT NULL DEFAULT '', "
    "`eng_min` varchar(15) NOT NULL DEFAULT '', `eng_max` varchar(15) NOT NULL DEFAULT '', "
    "`driver_id_extra` varchar(255) NOT NULL DEFAULT '', `format_extra` text NOT NULL, "
    "UNIQUE KEY `element_id` (`element_id`)) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='3.2.3';")

CREATE_SET = ("CREATE TABLE IF NOT EXISTS `iw_set_{t}` (`row_date` datetime NOT NULL "
    "DEFAULT '2004-01-10 00:00:00', `element_id` varchar(100) NOT NULL DEFAULT '', "
    "`active` enum('0','1') NOT NULL DEFAULT '0', `onl_ind` enum('0','1') NOT NULL DEFAULT '1', "
    "`update_freq` set('','fast','norm','slow','once','never') NOT NULL DEFAULT 'norm', "
    "`save_data` varchar(20) NOT NULL DEFAULT 'change', `save_freq` varchar(20) NOT NULL "
    "DEFAULT '', `plant_pri` char(1) NOT NULL DEFAULT '', `sys_pri` char(1) NOT NULL "
    "DEFAULT '', `alarm_type` tinyint(3) NOT NULL DEFAULT '0', PRIMARY KEY (`element_id`)) "
    "ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='3.0.0';")

# fixed iw_sys_plant_settings lines: (setting, value, eng_unit, help_text)
FIXED_SETTINGS = [
    ("mb_request_retries", "2", "", ""),
    ("force_word_not_byte", "0", "", "0|1"),
    ("handshake", "0", "", "0|1|2"),
    ("check_rate", "1", "ms", ""),
]
FIXED_SETTINGS_TAIL = [
    ("max_outstanding_packets", "-1", "", ""),
    ("packet_timeout", "1", "sec.", ""),
    ("idle_event_rate", "250", "msec.", ""),
    ("sql_queue_poll_time", "2000", "msec.", ""),
    ("max_error_count", "2", "", ""),
    ("mb_request_timeout", "1000", "ms", ""),
    ("com_error_alarm_delay", "10", "min.", ""),
    ("show_queue_info", "0", "", ""),
    ("speed_index_block", "10", "", ""),
    ("speed_index_offline", "10", "", ""),
    ("speed_index_slow", "1", "", ""),
    ("speed_index_norm", "1", "", ""),
    ("max_param_block_time", "2", "hours", ""),
    ("max_group_count", "1", "", ""),
    ("value_quality_check_limit", "0", "", "0 = disabled"),
    ("mux_settle_time", "1500", "ms",
     "Time for the muxed input to settle. The value shuld be a multiple off 100."),
    ("startup_delay", "15", "Sec.", ""),
    ("alarm_handler", "", "", ""),
    ("mb_tcp_connect_retries_default", "2", "", ""),
    ("mb_tcp_connect_timeout_default", "1000", "ms", ""),
]

# Rows per REPLACE statement. One statement per table used to carry every row: 2 125
# points made a 664 KB parameter REPLACE, 1.14 MB with 16-state texts, over a
# max_allowed_packet of 1M - and with truncate on, the table had already been emptied
# when it failed (review, 2026-10-24). 500 such rows came to 408 KB on MySQL 8.0; the
# character budget keeps long state lists under the same 1M as well. The legacy format
# writes one INSERT per row already.
BATCH_ROWS = 500
BATCH_BYTES = 512 * 1024


def q(value: str) -> str:
    """A MySQL string literal. Backslash is MySQL's escape character unless the session
    sets NO_BACKSLASH_ESCAPES, which these scripts never do - modern even replaces the
    whole SQL_MODE - so it is doubled before the quotes are. Left alone, `C:\\temp`
    stored a tab, and a text ending in a backslash swallowed its closing quote and broke
    the whole multi-row statement (2026-10-23)."""
    return "'" + str(value).replace("\\", "\\\\").replace("'", "''") + "'"


# ---------------------------------------------------------------------------
# How the plant's tables compare keys
# ---------------------------------------------------------------------------

ELEMENT_ID_MAX = 100        # element_id: varchar(100) in the param and set tables
GROUP_NAME_MAX = 100        # the groups table's `ref`: varchar(100)

# latin1_swedish_ci, the collation of every CHARSET=latin1 table these scripts create:
# the weight of each latin1 byte, indexed by the byte. Two texts are equal when their
# weights are, trailing spaces aside (PAD SPACE). This is MySQL's sort_order_latin1,
# and every entry was read back with WEIGHT_STRING(... COLLATE latin1_swedish_ci) from a
# MySQL 8.0.46 server on 2026-10-24, as the reviewer's own table was. In practice: case
# goes, and so do some accents - E, e, É and è are one letter, as are Y, Ü and ý, and
# Ä and Æ share a weight with a backslash, Å with '[' and Ö with ']' - while Ø, ß, Þ and
# everything in 0x80-0xBF (Š and š, Œ and œ, µ ...) are letters of their own.
LATIN1_SWEDISH_CI = (
      0,   1,   2,   3,   4,   5,   6,   7,   8,   9,  10,  11,  12,  13,  14,  15,
     16,  17,  18,  19,  20,  21,  22,  23,  24,  25,  26,  27,  28,  29,  30,  31,
     32,  33,  34,  35,  36,  37,  38,  39,  40,  41,  42,  43,  44,  45,  46,  47,
     48,  49,  50,  51,  52,  53,  54,  55,  56,  57,  58,  59,  60,  61,  62,  63,
     64,  65,  66,  67,  68,  69,  70,  71,  72,  73,  74,  75,  76,  77,  78,  79,
     80,  81,  82,  83,  84,  85,  86,  87,  88,  89,  90,  91,  92,  93,  94,  95,
     96,  65,  66,  67,  68,  69,  70,  71,  72,  73,  74,  75,  76,  77,  78,  79,
     80,  81,  82,  83,  84,  85,  86,  87,  88,  89,  90, 123, 124, 125, 126, 127,
    128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143,
    144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159,
    160, 161, 162, 163, 164, 165, 166, 167, 168, 169, 170, 171, 172, 173, 174, 175,
    176, 177, 178, 179, 180, 181, 182, 183, 184, 185, 186, 187, 188, 189, 190, 191,
     65,  65,  65,  65,  92,  91,  92,  67,  69,  69,  69,  69,  73,  73,  73,  73,
     68,  78,  79,  79,  79,  79,  93, 215, 216,  85,  85,  85,  89,  89, 222, 223,
     65,  65,  65,  65,  92,  91,  92,  67,  69,  69,  69,  69,  73,  73,  73,  73,
     68,  78,  79,  79,  79,  79,  93, 247, 216,  85,  85,  85,  89,  89, 222, 255,
)


def _weights() -> dict[int, str]:
    """Code point -> its weight as a one-character string, for str.translate."""
    table: dict[int, str] = {}
    for byte, weight in enumerate(LATIN1_SWEDISH_CI):
        try:
            ch = bytes([byte]).decode("cp1252")       # MySQL's latin1 is cp1252 ...
        except UnicodeDecodeError:
            ch = chr(byte)                             # ... with its five gaps as C1 codes
        table[ord(ch)] = chr(weight)
    # the other C1 code points are no latin1 character: a weight of their own each, so
    # none can pass for the character whose weight happens to equal its code
    for cp in range(256):
        table.setdefault(cp, chr(0xF0000 + cp))
    return table


_WEIGHT = _weights()


def latin1_key(text) -> str:
    """`text` as a latin1_swedish_ci column compares it: one weight per character, and
    trailing spaces ignored (PAD SPACE) - spaces only, since a tab is a character and
    'fan\\t' is not 'fan'. Two texts are equal on the plant exactly when their keys are.
    A character latin1 has no place for keeps its own code; no script can write it."""
    return str(text).rstrip(" ").translate(_WEIGHT)


def element_key(element_id) -> str:
    """An element_id as the param and set tables key it: cut to varchar(100), then
    compared under latin1_swedish_ci - 'Temp_é' and 'temp_e ' are one row, 'ß' and 'ss'
    are two. The one helper for every "is this the same row" question: the update plan
    here, and validate.py's duplicate check."""
    return latin1_key(str(element_id)[:ELEMENT_ID_MAX])


def clip_element_id(element_id) -> str:
    """The element_id the database stores: its first 100 characters. Every literal that
    names one is clipped, or a DELETE of a 101-character id matches nothing and the row
    it meant stays."""
    return str(element_id)[:ELEMENT_ID_MAX]


def _ids(values) -> list[str]:
    """element_ids for an IN list: clipped, each once."""
    return list(dict.fromkeys(clip_element_id(v) for v in values))


def _same_table(a, b) -> bool:
    """Two table names for one list. Compared without case, as the scripts' own
    `grp_name IN (...)` subqueries compare them on the plant."""
    return str(a).casefold() == str(b).casefold()


# ---------------------------------------------------------------------------
# Units
# ---------------------------------------------------------------------------

def written_units(project: Project) -> list[str]:
    """The unit_ids the script writes an iw_sys_plant_units row for: none unless
    system.units is on, and in the legacy format only the first, which is all that
    format writes (the Excel tool emitted a single unit). Blank ids name no unit.

    The DELETEs that clear bound rows name exactly these units, beside the units whose
    grp_name is the table. Every unit of the list used to be named whatever the script
    wrote, so a unit with units off, a legacy unit 2..N, or a unit the previous version
    named that has since moved to another table lost its rows there (review, 2026-10-24).
    """
    s = project.system
    if s is None or not s.units:
        return []
    units = s.effective_units()
    if project.options.sql_format == "legacy":
        units = units[:1]
    return [str(u.unit_id) for u in units if str(u.unit_id or "").strip()]


def units_not_written(project: Project) -> list[str]:
    """With system.units on, the unit_ids of unit_list the script writes no row for:
    in the legacy format every unit after the first. Empty in the modern format, and
    when units are off (nothing is written then, by choice). For a warning."""
    s = project.system
    if s is None or not s.units:
        return []
    written = set(written_units(project))
    return [str(u.unit_id) for u in s.effective_units()
            if str(u.unit_id or "").strip() and str(u.unit_id) not in written]


# ---------------------------------------------------------------------------
# Rows and lists
# ---------------------------------------------------------------------------

_COLUMNS: dict[type, operator.attrgetter] = {}


def _row(record) -> tuple:
    """A record's column values in SQL order, shallow. dataclasses.astuple deep-copied
    every value on the way: 16.5 to 19 of render_sql_modern's 42 to 46 ms at about 2 000
    points (review, 2026-10-24)."""
    get = _COLUMNS.get(type(record))
    if get is None:
        get = _COLUMNS[type(record)] = operator.attrgetter(
            *(f.name for f in dc_fields(record)))
    return get(record)


def _sql_row(record) -> tuple:
    """_row with the element_id clipped where the database clips it: the param and set
    rows' key, and a membership row's value, which must name the clipped key."""
    row = _row(record)
    if isinstance(record, (ParamRecord, SetRecord)):
        if len(str(row[1])) > ELEMENT_ID_MAX:
            row = row[:1] + (clip_element_id(row[1]),) + row[2:]
    elif isinstance(record, GroupRecord) and record.type == "group" \
            and len(str(row[4])) > ELEMENT_ID_MAX:
        row = row[:4] + (clip_element_id(row[4]),)
    return row


def _values(record) -> str:
    return "(" + ",".join(q(v) for v in _sql_row(record)) + ");"


def _in_list(values, indent: str = "    ", per_line: int = 6) -> list[str]:
    """`(a, b, ..., z)` as SQL, six values a line, for long IN lists. Nothing gives
    `(NULL)`, which matches no row: `IN ()` is a syntax error, and a caller that means
    "every row" has to say so itself."""
    quoted = [q(v) for v in values]
    if not quoted:
        return ["(NULL)"]
    rows = [", ".join(quoted[i:i + per_line]) for i in range(0, len(quoted), per_line)]
    if len(rows) == 1:
        return ["(" + rows[0] + ")"]
    return (["(" + rows[0] + ","] + [indent + r + "," for r in rows[1:-1]]
            + [indent + rows[-1] + ")"])


def _delete_ids_sql(table_name: str, element_ids) -> list[str]:
    ids = _ids(element_ids)
    if not ids:
        return []
    listing = _in_list(ids)
    listing[-1] += ";"
    return [f"DELETE FROM `{table_name}` WHERE `element_id` IN " + listing[0], *listing[1:]]


# ---------------------------------------------------------------------------
# What a script deletes
# ---------------------------------------------------------------------------

def _group_cleanup_conditions(groups, element_ids) -> list[str]:
    out = ["`type` = 'default_link'"]
    if groups:
        out.append("  OR (`type` = 'group_alias' AND `ref` IN ("
                   + ", ".join(q(g) for g in groups) + "))")
    if element_ids:
        ids = [q(e) for e in element_ids]
        rows = [", ".join(ids[i:i + 6]) for i in range(0, len(ids), 6)]
        out.append("  OR (`type` = 'group' AND `value` IN (" + rows[0]
                   + ("," if len(rows) > 1 else "))"))
        for i, row in enumerate(rows[1:], start=2):
            out.append("    " + row + ("," if i < len(rows) else "))"))
    return out


def _cleanup_args(groups, element_ids) -> tuple[list[str], list[str]]:
    return (list(dict.fromkeys(str(g)[:GROUP_NAME_MAX] for g in groups)),
            _ids(element_ids))


def group_cleanup_sql(table: str, groups: list[str], element_ids: list[str]) -> list[str]:
    """The group rows this script writes again, deleted first.

    The groups table's unique key is (type, view_order, ref, value), and a point's
    view_order is its position in its group. So when a point is added, removed or moved
    inside a group, REPLACE INTO cannot replace the old row of every later point: it
    adds a second one at the new position, and the old stays. A review simulating
    re-imports found 33 extra rows from one inserted point (2026-10-23); plant 2313 held
    1279 group rows for 369 template rows. Only this list's own rows go - the link row,
    its groups' alias rows, and the membership rows of its own element_ids - so a list
    that adds a few points to a table leaves the rest alone.

    The callers pass every element_id of the list, not only the grouped ones: a point
    set to no_group, a motherword left out of the groups, or a point in a ` | ` group
    has no row of its own any more, and the one an earlier import wrote used to stay
    (review, 2026-10-24).
    """
    groups, element_ids = _cleanup_args(groups, element_ids)
    cond = _group_cleanup_conditions(groups, element_ids)
    out = ["-- This list's own group rows are cleared first, so a point that moved inside its",
           "-- group does not keep its old position row beside the new one.",
           f"DELETE FROM `iw_par_{table}_groups` WHERE " + cond[0], *cond[1:]]
    out[-1] += ";"
    return out


def _replace_where(table: str, unit_ids, pre: str = "") -> list[str]:
    by_group = (f"`unit_id` IN (SELECT `unit_id` FROM {pre}`iw_sys_plant_units` "
                f"WHERE `grp_name` = {q(table)})")
    return ([f"WHERE (`unit_id` IN ({', '.join(q(u) for u in unit_ids)})", f"   OR {by_group})"]
            if unit_ids else [f"WHERE {by_group}"])


def replace_list_sql(table: str, unit_ids: list[str] | tuple[str, ...] = ()) -> list[str]:
    """options.replace_list: the old list goes before the new one is written.

    An import never deletes (docs/16 section 16.6): REPLACE INTO keys on element_id, so
    a row the new list no longer carries stays, in the template and in the unit's bound
    rows, and the plant goes on showing it. This is section 16.6.4's clean-out, written
    into the script. The bound rows of every unit whose group is this table go first -
    the units the script's own iw_sys_plant_units rows give grp_name = table - keeping
    the two IWMAC adds itself, com_stat and com_error. The three tables are then emptied
    before each block, because replace_list implies Options.truncates. The parameter
    build binds the new rows afterwards.

    The units the script itself writes count too (unit_ids: written_units). Modern
    writes its iw_sys_plant_units rows last, so a unit that moves to this table from an
    older one, or a table that was renamed, has no grp_name = table yet when this runs,
    and the subquery alone deleted nothing (review, 2026-10-23).
    """
    return [
        "-- replace_list: the old list is deleted before this one is written - the bound",
        f"-- rows of every unit whose group is {table} (com_stat and com_error stay), then",
        "-- each table below. Back up first; run Generate Param/Grp/Set afterwards.",
        "DELETE FROM `iw_gen_driver_parameters`",
        *_replace_where(table, list(unit_ids)),
        "  AND `element_id` NOT IN ('com_stat', 'com_error');",
    ]


# ---------------------------------------------------------------------------
# The update from the previous version
# ---------------------------------------------------------------------------

class PreviousMismatch(ValueError):
    """The version given as the previous one cannot be this list's version on the plant,
    so an update from it would delete the wrong rows. Raised instead of a plan.

    A sibling list on another table came out as "42 unchanged, 18 removed" and deleted
    rows on that list's units; an unrelated list as "0 unchanged, 2063 removed", exit 0
    (review, 2026-10-24). `code` names the check: table-differs, renamed-from-mismatch,
    nothing-in-common, no-list (the SQL holds no list), no-list-for-table (it holds
    several, none of them this one)."""

    def __init__(self, message: str, *, code: str, table: str = "",
                 previous_table: str = ""):
        super().__init__(message)
        self.code = code
        self.table = table
        self.previous_table = previous_table


_WHAT_TO_DO = ("Give the version that put this list on the plant. If this list's table "
               "was renamed, pass the old table name as renamed_from; for a list that "
               "replaces another one whole, use replace_list instead.")

# What tells a changed point from an unchanged one: every column the param and set rows
# carry, except the timestamp and the key.
PARAM_COMPARED = ("alias_text", "menu", "application", "parameter_type", "factory_setting",
                  "grp", "att", "eng_unit", "format", "range_min", "range_max", "scale",
                  "raw_min", "raw_max", "eng_min", "eng_max", "driver_id_extra",
                  "format_extra")
SET_COMPARED = ("active", "onl_ind", "update_freq", "save_data", "save_freq", "plant_pri",
                "sys_pri", "alarm_type")


@dataclass
class VersionRow:
    """One parameter row of a list version - what the plant holds for one point."""
    element_id: str
    driver_id: str
    alias_text: str
    group: str = ""                     # its membership row's group; "" for none
    columns: dict[str, str] = field(default_factory=dict)   # PARAM_ and SET_COMPARED


@dataclass
class ListVersion:
    """A version of a list as an update compares it: read from a project
    (previous_from_project, previous_from_data) or straight from the SQL that put it on
    the plant (previous_from_sql)."""
    table: str
    rows: list[VersionRow]
    groups: list[str] = field(default_factory=list)     # its group_alias rows
    units: list[str] = field(default_factory=list)      # the units its script writes
    notes: list = field(default_factory=list)           # notes.Note: what did not make it
    source: str = "project"                             # "project" or "sql"


@dataclass
class Change:
    """One line of the change report: a point of either version, and its partner."""
    status: str             # unchanged, changed, re-addressed, moved, added, removed
    matched_by: str         # element_id, driver_id, alias, or "" when unpaired
    old: VersionRow | None
    new: VersionRow | None
    what: list[str]         # what differs, "field old -> new" or the field alone


@dataclass
class UpdatePlan:
    """What happens on the plant when this list replaces its previous version.

    REPLACE INTO keys on element_id (group + driver id), so a point that was removed,
    moved to another address or another group, or renamed into another group, leaves
    its old row behind in the template and bound to every unit - still polled, and
    still shown (docs/16 section 16.6). replace_list deletes the whole old list, and
    with it every setting made on the plant. Given the previous version, the script can
    delete exactly the rows that are gone, and leave the rest - and their settings -
    alone (2026-10-23).

    Classes, by element_id compared as the plant compares it: added; removed (or moved -
    a new group or address is a new element_id); re-addressed (same element_id, another
    driver_id: unbound, so it binds to the new register); changed (same element_id and
    register, another alias, type, access, unit ...: replaced in place and left bound,
    see plan_update); unchanged.
    """
    previous_table: str
    added: list[str]
    removed: list[str]              # element_ids only the previous version has
    readdressed: list[str]          # in both, with another driver_id
    unchanged: int
    groups_gone: list[str]
    removed_rows: list[tuple[str, str, str]]   # (element_id, driver_id, alias_text)
    units: list[str]                # the units the new script writes (written_units)
    changed: list[str] = field(default_factory=list)   # in both, same register, other columns
    readdressed_rows: list[tuple[str, str, str]] = field(default_factory=list)
    # ^ (element_id, old driver_id, new driver_id)
    table: str = ""
    renamed_from: str | None = None
    previous_units: list[str] = field(default_factory=list)
    changes: list[Change] = field(default_factory=list)  # the change report's lines
    notes: list = field(default_factory=list)            # notes.Note, the previous version's first

    def summary(self) -> str:
        return (f"{len(self.added)} added, {len(self.removed)} removed or moved, "
                f"{len(self.readdressed)} re-addressed, {len(self.changed)} changed, "
                f"{self.unchanged} unchanged")


def _dedupe(rows: list[VersionRow], keep_first: bool) -> tuple[list[VersionRow], int]:
    """One row per key, the one the database keeps: REPLACE INTO keeps the last, a legacy
    INSERT the first (the second fails with 1062)."""
    by_key: dict[str, VersionRow] = {}
    for r in rows:
        k = element_key(r.element_id)
        if k in by_key and keep_first:
            continue
        by_key[k] = r
    return list(by_key.values()), len(rows) - len(by_key)


def _duplicates_note(n: int, keep_first: bool) -> Note:
    return Note(
        f"previous version: {n} row(s) repeat an element_id the plant holds once - the "
        f"update takes the one the database kept ({'the first' if keep_first else 'the last'})",
        code="previous-duplicate-ids", kind=INFO, count=n,
        advice="Nothing to do for the update. The plant holds one row per element_id, "
               "compared without case or trailing spaces.")


def previous_from_project(project: Project, result: RunResult) -> ListVersion:
    """A generated project as a list version: its parameter rows with their group and
    every compared column. The new side of every plan is read this way too."""
    member: dict[str, str] = {}
    for g in result.groups:
        member.setdefault(element_key(g.value), g.ref)
    rows: list[VersionRow] = []
    for i, p in enumerate(result.params):
        s = result.sets[i] if i < len(result.sets) else None
        columns = {c: str(getattr(p, c)) for c in PARAM_COMPARED}
        if s is not None:
            columns.update({c: str(getattr(s, c)) for c in SET_COMPARED})
        rows.append(VersionRow(p.element_id, p.driver_id, p.alias_text,
                               member.get(element_key(p.element_id), ""), columns))
    keep_first = project.options.sql_format == "legacy"
    rows, dups = _dedupe(rows, keep_first)
    return ListVersion(table=project.table, rows=rows,
                       groups=[g.name for g in project.groups],
                       units=written_units(project),
                       notes=[_duplicates_note(dups, keep_first)] if dups else [],
                       source="project")


def previous_from_data(data: dict, tables=None,
                       timestamp: str = "2000-01-01 00:00:00") -> ListVersion:
    """A previous version given as a project file's data (JSON/YAML parsed), generated
    the way the CLI and the page generate it.

    A point whose datatype the tables do not describe - shipped or the file's own - is
    left out and named in a DROPPED note: its rows cannot be built, and generating it
    raised a bare KeyError (review, 2026-10-24). Leaving it out can only leave a row on
    the plant, never delete a wrong one; verify query 2 lists what stayed.
    Raises model.ProjectError when the data is not a project at all.
    """
    from .model import load_project
    from .rules import apply_auto_groups, generate, synthesize_motherwords
    from .tables import default_tables, project_tables
    from .yamlio import to_yaml_dict

    project = load_project(to_yaml_dict(data) if isinstance(data, dict) else data)
    t = project_tables(project, tables or default_tables())
    unknown: dict[str, list[int]] = {}
    kept = []
    for i, p in enumerate(project.points, start=1):
        if t.datatypes.get(p.datatype) is None:
            unknown.setdefault(str(p.datatype or ""), []).append(i)
        else:
            kept.append(p)
    project.points = kept
    apply_auto_groups(project, t)
    synthesize_motherwords(project, t)
    version = previous_from_project(project, generate(project, t, timestamp))
    version.notes[:0] = [Note(
        f"previous version: datatype '{name or '(none)'}' is not in the tables - "
        f"{len(rows)} point(s), first at row {rows[0]}, are left out of the update",
        code="previous-datatype-unknown", kind=DROPPED, count=len(rows),
        advice="If this version no longer has those points, their old rows stay on the "
               "plant: verify query 2 lists them after the import. Add the datatype to the "
               "previous file's datatypes, or give the SQL that put it on the plant "
               "instead - that is read row by row.")
        for name, rows in sorted(unknown.items())]
    return version


def previous_from_sql(text: str, table: str, renamed_from: str | None = None) -> ListVersion:
    """A previous version given as the SQL script that put it on the plant, read row by
    row - not rebuilt into a project first.

    The project route lost rows without a word: import-sql skips a row whose datatype it
    cannot resolve (a project-defined one, say) and settles an Excel-era Motherword
    beside the value row of the same register, so a plan from the SQL deleted nothing
    for them, while the same list given as JSON removed them (review, 2026-10-24). Here
    every parameter row with an element_id is in the version, as the database keeps it.

    When the script fills several lists, the one whose table is `renamed_from` or else
    `table` is taken, and a note says so; when none is, PreviousMismatch. A single list
    is taken whatever its table - plan_update then decides whether it may be used.
    `text` is the script decoded (sqlimport.decode_sql_bytes reads a file's bytes).
    """
    from .sqlimport import _scan          # read-only use of import-sql's statement reader

    scanned = _scan(text)
    by_table, legacy = scanned.by_table, scanned.legacy
    index = {name.casefold(): name for name in by_table}
    lists = [name[len("iw_par_"):-len("_param")] for name in by_table
             if name.startswith("iw_par_") and name.endswith("_param")]
    if not lists:
        raise PreviousMismatch(
            "the previous version's SQL fills no iw_par_<table>_param table - it is not "
            "the script that put a list on the plant. " + _WHAT_TO_DO,
            code="no-list", table=table)
    notes: list = []
    want = renamed_from or table
    if len(lists) == 1:
        chosen = lists[0]
    else:
        matching = [t for t in lists if _same_table(t, want)]
        if not matching:
            raise PreviousMismatch(
                f"the previous version's SQL fills {len(lists)} lists "
                f"({', '.join(lists)}) and none of them is '{want}'. " + _WHAT_TO_DO,
                code="no-list-for-table", table=table)
        chosen = matching[0]
        others = [t for t in lists if t != chosen]
        notes.append(Note(
            f"the previous version's SQL fills {len(lists)} lists - took '{chosen}', the "
            f"one this list {'was' if renamed_from else 'is'}; {', '.join(others)} "
            f"{'is' if len(others) == 1 else 'are'} not part of the update",
            code="previous-several-lists", kind=INFO, count=len(others),
            advice="Nothing to do. The other lists' rows are neither compared nor deleted."))

    def rows_of(name: str) -> list[dict]:
        return by_table.get(index.get(name.casefold(), ""), [])

    sets: dict[str, dict] = {}
    for r in rows_of(f"iw_set_{chosen}"):
        k = element_key(r.get("element_id", ""))
        if not (legacy and k in sets):
            sets[k] = r
    member: dict[str, str] = {}
    groups: dict[str, str] = {}
    for r in rows_of(f"iw_par_{chosen}_groups"):
        if r.get("type") == "group" and r.get("value"):
            member.setdefault(element_key(r["value"]), r.get("ref", ""))
        elif r.get("type") == "group_alias" and r.get("ref"):
            groups.setdefault(latin1_key(str(r["ref"])[:GROUP_NAME_MAX]), r["ref"])
    rows: list[VersionRow] = []
    blank = 0
    for r in rows_of(f"iw_par_{chosen}_param"):
        eid = str(r.get("element_id", ""))
        if not eid.strip():
            blank += 1
            continue
        k = element_key(eid)
        columns = {c: str(r[c]) for c in PARAM_COMPARED if c in r}
        s = sets.get(k)
        if s is not None:
            columns.update({c: str(s[c]) for c in SET_COMPARED if c in s})
        rows.append(VersionRow(eid, str(r.get("driver_id", "")), str(r.get("alias_text", "")),
                               member.get(k, ""), columns))
    rows, dups = _dedupe(rows, keep_first=legacy)
    if dups:
        notes.append(_duplicates_note(dups, legacy))
    if blank:
        notes.append(Note(
            f"previous version: {blank} row(s) of iw_par_{chosen}_param have no "
            f"element_id and are not part of the update",
            code="previous-rows-without-id", kind=DROPPED, count=blank,
            advice="The update cannot name them. Delete them by hand if they are still "
                   "on the plant."))
    units = [str(u.get("unit_id", "")) for u in rows_of("iw_sys_plant_units")
             if str(u.get("unit_id", "")).strip()
             and (len(lists) == 1 or _same_table(u.get("grp_name", ""), chosen))]
    return ListVersion(table=chosen, rows=rows, groups=list(groups.values()),
                       units=list(dict.fromkeys(units)), notes=notes, source="sql")


def _check_table(previous_table: str, table: str, renamed_from: str | None) -> None:
    if _same_table(previous_table, table):
        if renamed_from and not _same_table(renamed_from, table):
            raise PreviousMismatch(
                f"renamed_from names table '{renamed_from}', but the previous version "
                f"already writes '{previous_table}', this list's own table - so it is not "
                f"the version from before the rename. Leave renamed_from out, or give the "
                f"version that wrote '{renamed_from}'.",
                code="renamed-from-mismatch", table=table, previous_table=previous_table)
        return
    if not renamed_from:
        raise PreviousMismatch(
            f"the previous version writes table '{previous_table}' and this list writes "
            f"'{table}' - it is another list's version, and an update from it would delete "
            f"that list's rows on its units. " + _WHAT_TO_DO,
            code="table-differs", table=table, previous_table=previous_table)
    if not _same_table(renamed_from, previous_table):
        raise PreviousMismatch(
            f"renamed_from names table '{renamed_from}', but the previous version writes "
            f"'{previous_table}'. " + _WHAT_TO_DO,
            code="renamed-from-mismatch", table=table, previous_table=previous_table)


def _show(value: str) -> str:
    return value if value != "" else "(blank)"


def _address(driver_id: str) -> str | None:
    parts = str(driver_id).split(".")[0].split("_")
    return parts[2] if len(parts) == 3 and parts[2].isdigit() else None


def _differences(old: VersionRow, new: VersionRow) -> list[str]:
    """What differs between two rows of one point, one item per column. driver_id_extra
    repeats the address, so it is left out when the address is all that moved."""
    what = []

    def item(name: str, a: str, b: str) -> str:
        if len(a) > 40 or len(b) > 40 or "\n" in a + b:
            return name
        return f"{name} {_show(a)} -> {_show(b)}"

    if old.element_id != new.element_id:
        what.append(item("element_id", old.element_id, new.element_id))
    if old.driver_id != new.driver_id:
        what.append(item("driver_id", old.driver_id, new.driver_id))
    if latin1_key(old.group) != latin1_key(new.group):
        what.append(item("group", old.group, new.group))
    was, now = _address(old.driver_id), _address(new.driver_id)
    for name in PARAM_COMPARED + SET_COMPARED:
        a, b = old.columns.get(name), new.columns.get(name)
        if a is None or b is None or a == b:
            continue
        if name == "driver_id_extra" and was and now and was != now \
                and a.replace(f"_{was}_", f"_{now}_") == b:
            continue
        what.append(item(name, a, b))
    return what


def _alias(text: str) -> str:
    return " ".join(str(text).split()).casefold()


_GENERIC_ALIASES = {"motherword", "reserve."}


def _pair_moved(removed: list[VersionRow], added: list[VersionRow]) -> dict[int, tuple]:
    """Removed rows paired with added ones for the change report: by driver identity
    (function, address and bit - the driver_id) first, then by an alias that names one
    point on each side. -> {id(new row): (old row, matched_by)}"""
    paired: dict[int, tuple] = {}
    by_driver: dict[str, list[VersionRow]] = {}
    for n in added:
        by_driver.setdefault(n.driver_id, []).append(n)
    left: list[VersionRow] = []
    for o in removed:
        candidates = [n for n in by_driver.get(o.driver_id, []) if id(n) not in paired]
        if candidates:
            same = [n for n in candidates if _alias(n.alias_text) == _alias(o.alias_text)]
            paired[id((same or candidates)[0])] = (o, "driver_id")
        else:
            left.append(o)
    olds: dict[str, list[VersionRow]] = {}
    for o in left:
        olds.setdefault(_alias(o.alias_text), []).append(o)
    news: dict[str, list[VersionRow]] = {}
    for n in added:
        if id(n) not in paired:
            news.setdefault(_alias(n.alias_text), []).append(n)
    for alias, os_ in olds.items():
        ns = news.get(alias, [])
        if alias and alias not in _GENERIC_ALIASES and len(os_) == 1 and len(ns) == 1:
            paired[id(ns[0])] = (os_[0], "alias")
    return paired


def plan_update(previous: ListVersion, project: Project, result: RunResult, *,
                renamed_from: str | None = None) -> UpdatePlan:
    """The update plan from `previous` (previous_from_project/_data/_sql) to this list.

    Refuses (PreviousMismatch) a version that cannot be this list's: one on another
    table unless `renamed_from` names that table, and one that has no element_id in
    common with this list while the update would delete its rows.

    A changed point - same element_id and register, another alias, raw type, access,
    unit, state text or setting - is replaced in place and stays bound, keeping what was
    set on the plant. Unbinding it as a re-addressed point is unbound would cost those
    settings for what may be a new alias, and could not be made safe to run twice: a
    re-addressed row is deleted only while it still reads the old register, but a changed
    row has no such mark. verify_sql shows bound rows whose register or alias differs
    from the template, and the change report lists every changed point with what changed.
    """
    _check_table(previous.table, project.table, renamed_from)
    new = previous_from_project(project, result)
    old_by = {element_key(r.element_id): r for r in previous.rows}
    new_by = {element_key(r.element_id): r for r in new.rows}

    readdressed, readdressed_rows, changed = [], [], []
    unchanged = 0
    status: dict[str, tuple[str, list[str]]] = {}
    for k, n in new_by.items():
        o = old_by.get(k)
        if o is None:
            continue
        what = _differences(o, n)
        if o.driver_id != n.driver_id:
            readdressed.append(n.element_id)
            readdressed_rows.append((n.element_id, o.driver_id, n.driver_id))
            status[k] = ("re-addressed", what)
        elif what:
            changed.append(n.element_id)
            status[k] = ("changed", what)
        else:
            unchanged += 1
            status[k] = ("unchanged", what)
    removed = [o for k, o in old_by.items() if k not in new_by]
    added = [n for k, n in new_by.items() if k not in old_by]
    if removed and not status:
        raise PreviousMismatch(
            f"the previous version (table '{previous.table}', {len(old_by)} rows) has no "
            f"element_id in common with this list ({len(new_by)} rows): the update would "
            f"delete every one of its rows, so it is not an earlier version of this list. "
            + _WHAT_TO_DO,
            code="nothing-in-common", table=project.table, previous_table=previous.table)

    paired = _pair_moved(removed, added)
    changes: list[Change] = []
    for k, n in new_by.items():
        if k in status:
            changes.append(Change(status[k][0], "element_id", old_by[k], n, status[k][1]))
        elif id(n) in paired:
            o, by = paired[id(n)]
            changes.append(Change("moved", by, o, n, _differences(o, n)))
        else:
            changes.append(Change("added", "", None, n, []))
    moved_old = {id(o) for o, _by in paired.values()}
    changes += [Change("removed", "", o, None, []) for o in removed if id(o) not in moved_old]

    new_groups = {latin1_key(str(g)[:GROUP_NAME_MAX]) for g in new.groups}
    notes = list(previous.notes)
    written = {u.casefold() for u in new.units}
    left_out = [u for u in previous.units if u.casefold() not in written]
    if left_out:
        tables = f"'{project.table}'" + ("" if _same_table(previous.table, project.table)
                                         else f" or '{previous.table}'")
        notes.append(Note(
            f"unit(s) {', '.join(left_out)} are in the previous version's script and not "
            f"in this one: the update deletes their rows only while they sit on table "
            f"{tables}",
            code="previous-units-left-out", kind=INFO, count=len(left_out),
            advice="A unit that moved to another list keeps that list's rows. If the unit "
                   "is gone from the plant, remove it in IWMAC."))
    return UpdatePlan(
        previous_table=previous.table,
        added=[n.element_id for n in added],
        removed=[o.element_id for o in removed],
        readdressed=readdressed,
        unchanged=unchanged,
        groups_gone=[g for g in previous.groups
                     if latin1_key(str(g)[:GROUP_NAME_MAX]) not in new_groups],
        removed_rows=[(o.element_id, o.driver_id, o.alias_text) for o in removed],
        units=new.units,
        changed=changed,
        readdressed_rows=readdressed_rows,
        table=project.table,
        renamed_from=renamed_from or None,
        previous_units=list(previous.units),
        changes=changes,
        notes=notes)


def update_plan(previous: Project, previous_result: RunResult,
                project: Project, result: RunResult, *,
                renamed_from: str | None = None) -> UpdatePlan:
    """plan_update with the previous version as a generated project - the signature the
    CLI and the page have called since 2026-10-23."""
    return plan_update(previous_from_project(previous, previous_result), project, result,
                       renamed_from=renamed_from)


def _bound_where(plan: UpdatePlan, table: str, pre: str = "") -> list[str]:
    tables = [table] + ([] if _same_table(plan.previous_table, table)
                        else [plan.previous_table])
    by_group = (f"`unit_id` IN (SELECT `unit_id` FROM {pre}`iw_sys_plant_units` WHERE "
                f"`grp_name` IN (" + ", ".join(q(t) for t in tables) + "))")
    return ([f"WHERE (`unit_id` IN ({', '.join(q(u) for u in plan.units)})", f"   OR {by_group})"]
            if plan.units else [f"WHERE {by_group}"])


def _bound_ids(plan: UpdatePlan) -> list[str]:
    """The element part of the update's bound DELETE. A re-addressed row goes only while
    its driver_id still ends in the old register: after the update and a parameter
    build it is bound to the new one, and pasting the same script again used to unbind
    it once more (review, 2026-10-24). The bound driver_id is the template's with the
    plant, driver, regulator type and unit address before it (docs/16 section 16.6.1)."""
    moved = plan.readdressed_rows or [(e, "", "") for e in plan.readdressed]
    plain = _ids(plan.removed + [e for e, old, _new in moved if not old])
    conds = [f"(`element_id` = {q(clip_element_id(e))} AND RIGHT(`driver_id`, "
             f"{len(old) + 1}) = {q('_' + old)})" for e, old, _new in moved if old]
    if not conds:
        listing = _in_list(plain)
        return ["  AND `element_id` IN " + listing[0], *listing[1:]]
    if plain:
        listing = _in_list(plain, indent="      ")
        out = ["  AND (`element_id` IN " + listing[0], *listing[1:]]
    else:
        out = ["  AND (" + conds.pop(0)]
    out += ["    OR " + c for c in conds]
    out[-1] += ")"
    return out


def update_bound_sql(plan: UpdatePlan, table: str) -> list[str]:
    """The bound rows of the removed and re-addressed points, on every unit of the list:
    the units the new script writes (plan.units) and every unit whose grp_name is the
    table - or the old table, when it was renamed."""
    head = [f"-- Update from the previous version: {plan.summary()}.",
            "-- Rows the previous version has and this one has not are deleted from every",
            "-- unit on the table; a re-addressed point is unbound while it still reads its",
            "-- old register, so it binds to the new one. Points both versions have - changed",
            "-- ones too - keep their settings on the plant."]
    if not _same_table(plan.previous_table, table):
        head.append(f"-- The previous version wrote table {plan.previous_table}: its own "
                    "tables are left as they are.")
    if not plan.removed and not plan.readdressed:
        return head + ["-- Nothing to delete."]
    out = ["DELETE FROM `iw_gen_driver_parameters`", *_bound_where(plan, table),
           *_bound_ids(plan)]
    out[-1] += ";"
    return head + out


def update_table_sql(plan: UpdatePlan, table_name: str) -> list[str]:
    """The removed points' rows in one template table (param or set)."""
    return _delete_ids_sql(table_name, plan.removed)


# ---------------------------------------------------------------------------
# The change report
# ---------------------------------------------------------------------------

REPORT_COLUMNS = ("status", "matched_by", "alias", "old_alias", "old_element_id",
                  "new_element_id", "old_driver_id", "new_driver_id", "what_changed")


def change_report(plan: UpdatePlan, include_unchanged: bool = True) -> list[dict[str, str]]:
    """Old and new points side by side - the list a panel relink works from.

    Each new point with its partner in the previous version: by element_id first
    (unchanged, changed, re-addressed), then, for a point whose element_id is new, by
    driver identity - the same register under another group - and last by an alias that
    names one point on each side (both "moved"). Then the previous version's points that
    found no partner (removed). Moving three points one register up and fixing one word
    order used to read as 4 removed and 4 added; here each is one line, old register to
    new (review, 2026-10-24). Panels link by driver_id, so a line whose driver_id
    changed is a relink (docs/16 section 16.6.5).
    """
    out = []
    for c in plan.changes:
        if c.status == "unchanged" and not include_unchanged:
            continue
        o, n = c.old, c.new
        out.append({
            "status": c.status, "matched_by": c.matched_by,
            "alias": (n or o).alias_text, "old_alias": o.alias_text if o else "",
            "old_element_id": o.element_id if o else "",
            "new_element_id": n.element_id if n else "",
            "old_driver_id": o.driver_id if o else "",
            "new_driver_id": n.driver_id if n else "",
            "what_changed": "; ".join(c.what)})
    return out


def change_report_csv(plan: UpdatePlan, include_unchanged: bool = True) -> str:
    """change_report as CSV text: a header row, comma-separated, CRLF."""
    buf = io.StringIO()
    writer = csv.DictWriter(buf, fieldnames=REPORT_COLUMNS, lineterminator="\r\n")
    writer.writeheader()
    writer.writerows(change_report(plan, include_unchanged))
    return buf.getvalue()


def report_filename(project: Project) -> str:
    return f"modbusgen-{project.plant}-{project.table}-changes.csv"


# ---------------------------------------------------------------------------
# Read-only SQL: the verification after the import, the preview before it
# ---------------------------------------------------------------------------

def _memberships(result: RunResult) -> dict[str, list[str]]:
    """group -> the element_ids its membership rows name, as the database stores them."""
    out: dict[str, list[str]] = {}
    for g in result.groups:
        out.setdefault(str(g.ref)[:GROUP_NAME_MAX], []).append(clip_element_id(g.value))
    return {ref: list(dict.fromkeys(ids)) for ref, ids in out.items()}


def _group_names(result: RunResult) -> list[str]:
    return list(dict.fromkeys(str(r.ref)[:GROUP_NAME_MAX] for r in result.group_aliases
                              if r.type == "group_alias"))


def _not_members(members: dict[str, list[str]]) -> list[str]:
    """`AND NOT ((ref = a AND value IN (...)) OR ...);` as lines, one group a clause."""
    if not members:
        return []
    out: list[str] = []
    for i, (ref, values) in enumerate(members.items()):
        listing = _in_list(values, indent="      ")
        head = ("  AND NOT (" if i == 0 else "    OR ") + f"(`ref` = {q(ref)} AND `value` IN "
        if len(listing) == 1:
            out.append(head + listing[0] + ")")
        else:
            out += [head + listing[0], *listing[1:-1], listing[-1] + ")"]
    out[-1] += ");"
    return out


def verify_sql(project: Project, result: RunResult, schema: str = "") -> str:
    """Read-only checks to paste into the plant's SQL tool after the import.

    Every statement is a SELECT. Each lists problems, so an empty result is a pass;
    the first shows the bound count per unit against what this list expects, and the
    last is information. They are docs/16 section 16.6.2's diagnostics, filled in with
    this list's table, element_ids and units instead of placeholders, plus the leftovers
    those could not see (2026-10-23): group rows that are not this list's grouped points,
    alias rows of groups it does not have, and bound rows on another register than the
    template - a re-addressed point the build kept on its old row (2026-10-24).
    A list with no parameter rows leaves out the checks against its element_ids.
    """
    t = project.table
    pre = f"`{schema}`." if schema else ""
    ids = _ids(r.element_id for r in result.params)
    units = written_units(project)
    on_table = f"u.`grp_name` = {q(t)}" + (
        f" OR u.`unit_id` IN ({', '.join(q(u) for u in units)})" if units else "")
    in_ids = _in_list(ids, indent="      ")
    members = _memberships(result)
    groups = _group_names(result)

    def block(title: str, *sql: str) -> list[str]:
        return ["", f"-- {title}", *sql]

    def with_ids(prefix: str, suffix: str = "") -> list[str]:
        first, *rest = in_ids
        if not rest:
            return [prefix + first + suffix]
        return [prefix + first, *rest[:-1], rest[-1] + suffix]

    lines = [f"-- modbusgen verification for table {t}: {len(ids)} parameter rows, so "
             f"{len(ids) + 2} bound rows per unit with com_stat and com_error.",
             "-- Paste it into the plant's SQL tool after the import and Generate "
             "Param/Grp/Set. Every statement is a SELECT and changes nothing.",
             "-- Each query lists problems - an empty result is a pass - except 1, which "
             "shows the count per unit, and 12, which is information.",
             "-- If the tool answers \"No database selected\", run USE iw_plant_server3; first."]
    if ids:
        lines += block(f"1. Units on {t}: bound rows from this list (expected {len(ids)})",
                       "SELECT u.`unit_id`, u.`unit_name`,",
                       *with_ids("       SUM(g.`element_id` IN ", ") AS `from_this_list`,"),
                       f"       {len(ids)} AS `expected`, COUNT(g.`element_id`) AS `all_bound`",
                       f"FROM {pre}`iw_sys_plant_units` u",
                       f"LEFT JOIN {pre}`iw_gen_driver_parameters` g ON g.`unit_id` = u.`unit_id`",
                       f"WHERE {on_table}",
                       "GROUP BY u.`unit_id`, u.`unit_name`;")
        lines += block("2. Bound rows this list does not have - left by an earlier version, "
                       "still polled",
                       "SELECT g.`unit_id`, g.`element_id`, g.`driver_id`, g.`alias_text`",
                       f"FROM {pre}`iw_gen_driver_parameters` g",
                       f"JOIN {pre}`iw_sys_plant_units` u ON u.`unit_id` = g.`unit_id`",
                       f"WHERE ({on_table})",
                       "  AND g.`element_id` NOT IN ('com_stat', 'com_error')",
                       *with_ids("  AND g.`element_id` NOT IN ", ";"))
        lines += block("3. This list's rows that a unit has not bound - the parameter build "
                       "has not run, or an older row holds the register",
                       "SELECT u.`unit_id`, p.`element_id`, p.`driver_id`, p.`alias_text`",
                       f"FROM {pre}`iw_sys_plant_units` u",
                       f"CROSS JOIN {pre}`iw_par_{t}_param` p",
                       f"LEFT JOIN {pre}`iw_gen_driver_parameters` g",
                       "  ON g.`unit_id` = u.`unit_id` AND g.`element_id` = p.`element_id`",
                       f"WHERE ({on_table}) AND g.`element_id` IS NULL",
                       *with_ids("  AND p.`element_id` IN ", ";"))
        lines += block("4. Template rows this list does not have",
                       f"SELECT `element_id`, `driver_id`, `alias_text` FROM {pre}`iw_par_{t}_param`",
                       *with_ids("WHERE `element_id` NOT IN ", ";"))
    else:
        lines += ["", "-- This list has no parameter rows: the checks against its "
                      "element_ids (1 to 4 and 6) are left out."]
    lines += block("5. Two template rows for one register",
                   "SELECT `driver_id`, COUNT(*) AS `n`, GROUP_CONCAT(`element_id`) AS `element_ids`",
                   f"FROM {pre}`iw_par_{t}_param` GROUP BY `driver_id` HAVING COUNT(*) > 1;")
    if ids:
        lines += block("6. Setting rows this list does not have",
                       f"SELECT `element_id` FROM {pre}`iw_set_{t}`",
                       *with_ids("WHERE `element_id` NOT IN ", ";"))
    lines += block("7. A point in its group more than once - an old position row",
                   "SELECT `ref` AS `group_name`, `value` AS `element_id`, COUNT(*) AS `n`",
                   f"FROM {pre}`iw_par_{t}_groups` WHERE `type` = 'group'",
                   "GROUP BY `ref`, `value` HAVING COUNT(*) > 1;")
    if units:
        lines += block("8. Units this script writes that still sit on another table - its "
                       "iw_sys_plant_units rows did not import",
                       f"SELECT `unit_id`, `grp_name` FROM {pre}`iw_sys_plant_units`",
                       f"WHERE `unit_id` IN ({', '.join(q(u) for u in units)}) "
                       f"AND `grp_name` <> {q(t)};")
    where9 = f"FROM {pre}`iw_par_{t}_groups` WHERE `type` = 'group'"
    lines += block("9. Group rows that are not a grouped point of this list - a point that "
                   "left its group or the list, or another list's row",
                   "SELECT `ref` AS `group_name`, `value` AS `element_id`, `view_order`",
                   *([where9, *_not_members(members)] if members else [where9 + ";"]))
    where10 = f"FROM {pre}`iw_par_{t}_groups` WHERE `type` = 'group_alias'"
    lines += block("10. Group alias rows of groups this list does not have",
                   "SELECT `ref` AS `group_name`, `value` AS `alias`",
                   where10 + (f" AND `ref` NOT IN ({', '.join(q(g) for g in groups)});"
                              if groups else ";"))
    joined = [f"FROM {pre}`iw_gen_driver_parameters` g",
              f"JOIN {pre}`iw_sys_plant_units` u ON u.`unit_id` = g.`unit_id`",
              f"JOIN {pre}`iw_par_{t}_param` p ON p.`element_id` = g.`element_id`",
              f"WHERE ({on_table})"]
    lines += block("11. Bound rows on another register than their template row - an old "
                   "binding the build kept, such as a re-addressed point's",
                   "SELECT g.`unit_id`, g.`element_id`, g.`driver_id` AS `bound_driver_id`, "
                   "p.`driver_id` AS `template_driver_id`",
                   *joined,
                   "  AND RIGHT(g.`driver_id`, CHAR_LENGTH(p.`driver_id`) + 1) "
                   "<> CONCAT('_', p.`driver_id`);")
    lines += block("12. Information, not a fault: bound alias texts that differ from the "
                   "template's - the build has not refreshed them",
                   "SELECT g.`unit_id`, g.`element_id`, g.`alias_text` AS `bound_alias`, "
                   "p.`alias_text` AS `template_alias`",
                   *joined,
                   "  AND g.`alias_text` <> p.`alias_text`;")
    return "\r\n".join(lines) + "\r\n"


def verify_filename(project: Project) -> str:
    return f"modbusgen-{project.plant}-{project.table}-verify.sql"


def _written_group_rows(project: Project, result: RunResult) -> list[tuple]:
    """(type, view_order, ref, value) of every groups row the script writes back."""
    legacy = project.options.sql_format == "legacy"
    rows = [] if legacy else [("default_link", 2, "", "")]
    for rec in result.group_aliases:
        if rec.type == "default_link" and legacy:
            rows.append(("default_link", int(rec.view_order), str(rec.ref), str(rec.value)))
        elif rec.type == "group_alias":
            rows.append(("group_alias", int(rec.view_order), str(rec.ref)[:GROUP_NAME_MAX],
                         str(rec.value)[:200]))
    for rec in result.groups:
        rows.append(("group", int(rec.view_order), str(rec.ref)[:GROUP_NAME_MAX],
                     clip_element_id(rec.value)))
    return rows


def _tuple_list(rows: list[tuple]) -> list[str]:
    """`(...), (...)` three tuples a line, for a row-constructor NOT IN."""
    parts = ["(" + ", ".join(str(v) if isinstance(v, int) else q(v) for v in r) + ")"
             for r in rows]
    lines = [", ".join(parts[i:i + 3]) for i in range(0, len(parts), 3)]
    return ["    " + ln + ("," if i < len(lines) - 1 else "") for i, ln in enumerate(lines)]


def preview_sql(project: Project, result: RunResult, plan: UpdatePlan | None = None,
                schema: str = "") -> str:
    """Read-only SELECTs to run before the import: what the script's DELETEs and
    TRUNCATEs would take, per unit for the bound rows, and the units its
    iw_sys_plant_units rows would move here from another table.

    Verify query 8 cannot answer that once the import has run - the script's own REPLACE
    has set grp_name by then (review, 2026-10-24). Pass the same plan render_sql gets;
    `schema` qualifies every table as verify_sql's does.
    """
    t = project.table
    o = project.options
    pre = f"`{schema}`." if schema else ""
    legacy = o.sql_format == "legacy"
    units = written_units(project)
    lines = [f"-- modbusgen preview for table {t}: what the import script deletes, before "
             "you run it.",
             "-- Paste it into the plant's SQL tool BEFORE the import. Every statement is a "
             "SELECT and changes nothing.",
             "-- The list's own tables come last: before a first import they do not exist, "
             "the tool answers \"doesn't exist\" (ERROR 1146), and nothing of them is deleted.",
             "-- If the tool answers \"No database selected\", run USE iw_plant_server3; first."]
    count = 0

    def block(title: str, *sql: str) -> None:
        nonlocal count
        count += 1
        lines.extend(["", f"-- P{count}. {title}", *sql])

    if units:
        block(f"Units this script writes that sit on another table now - the import moves "
              f"them to {t}",
              f"SELECT `unit_id`, `unit_name`, `grp_name` FROM {pre}`iw_sys_plant_units`",
              f"WHERE `unit_id` IN ({', '.join(q(u) for u in units)}) AND `grp_name` <> {q(t)};")
    informative = count
    if o.replace_list:
        block("replace_list: bound rows deleted, per unit (com_stat and com_error stay)",
              "SELECT `unit_id`, COUNT(*) AS `rows_deleted`",
              f"FROM {pre}`iw_gen_driver_parameters`",
              *_replace_where(t, units, pre),
              "  AND `element_id` NOT IN ('com_stat', 'com_error')",
              "GROUP BY `unit_id`;")
    elif plan is not None and (plan.removed or plan.readdressed):
        where = [*_bound_where(plan, t, pre), *_bound_ids(plan)]
        block("Update: bound rows deleted, per unit - removed points, and re-addressed "
              "points still on their old register",
              "SELECT `unit_id`, COUNT(*) AS `rows_deleted`",
              f"FROM {pre}`iw_gen_driver_parameters`", *where, "GROUP BY `unit_id`;")
        block("Update: the same bound rows, one by one",
              "SELECT `unit_id`, `element_id`, `driver_id`, `alias_text`",
              f"FROM {pre}`iw_gen_driver_parameters`", *where,
              "ORDER BY `unit_id`, `element_id`;")
    if o.truncates:
        why = "replace_list" if o.replace_list else "truncate"
        for name, n in ((f"iw_par_{t}_groups", len(_written_group_rows(project, result))),
                        (f"iw_par_{t}_param", len(result.params)),
                        (f"iw_set_{t}", len(result.sets))):
            block(f"{why}: every row of {name} is deleted - the script writes {n} back",
                  f"SELECT COUNT(*) AS `rows_deleted` FROM {pre}`{name}`;")
    else:
        if not legacy or plan is not None:
            groups, ids = _cleanup_args(
                _group_names(result) + (plan.groups_gone if plan is not None else []),
                [r.element_id for r in result.params]
                + (plan.removed if plan is not None else []))
            where = _group_cleanup_conditions(groups, ids)
            where[0] = "WHERE (" + where[0]
            where[-1] += ")"
            written = _written_group_rows(project, result)
            block("Group rows the clean-up deletes and the script does not write back - "
                  "old positions, points that left their group, groups that are gone",
                  "SELECT `type`, `view_order`, `ref`, `value`",
                  f"FROM {pre}`iw_par_{t}_groups`", *where,
                  *(["  AND (`type`, `view_order`, `ref`, `value`) NOT IN (",
                     *_tuple_list(written), "  );"] if written else [";"]))
        if plan is not None and plan.removed:
            removed = _in_list(_ids(plan.removed))
            removed[-1] += ";"
            block("Update: template rows of the removed points",
                  f"SELECT `element_id`, `driver_id`, `alias_text` FROM {pre}`iw_par_{t}_param`",
                  "WHERE `element_id` IN " + removed[0], *removed[1:])
            block("Update: setting rows of the removed points",
                  f"SELECT `element_id` FROM {pre}`iw_set_{t}`",
                  "WHERE `element_id` IN " + removed[0], *removed[1:])
    if count == informative:
        lines += ["", "-- This script deletes nothing: it only adds and replaces rows."]
    return "\r\n".join(lines) + "\r\n"


def preview_filename(project: Project) -> str:
    return f"modbusgen-{project.plant}-{project.table}-preview.sql"


def render_sql(project: Project, result: RunResult, plan: UpdatePlan | None = None) -> str:
    """The import script. With `plan` (plan_update against the previous version), it also
    deletes the rows that version had and this one has not."""
    if project.options.sql_format == "legacy":
        return render_sql_legacy(project, result, plan)
    return render_sql_modern(project, result, plan)


def render_sql_legacy(project: Project, result: RunResult,
                      plan: UpdatePlan | None = None) -> str:
    t = project.table
    o = project.options
    lines: list[str] = []
    add = lines.append

    if project.system and project.system.units:
        s = project.system
        u = s.effective_units()[0]           # the legacy tool emitted a single unit
        addr = f"{s.driver_addr_prefix}{u.driver_addr}"
        # REPLACE, not the Excel tool's INSERT: the unit, order-number, process and
        # settings rows have keys of their own, and a second import of the same legacy
        # script stopped at the first of them with ERROR 1062 (review, 2026-10-24). The
        # modern format writes these four with REPLACE INTO already.
        add("-- iw_sys_plant_units")
        add("REPLACE INTO `iw_sys_plant_units` (`row_date`, `active`, `blockout`, "
            "`unit_id`, `unit_name`, `grp_name`, `driver_type`, `driver_addr`, "
            "`regulator_type`, `order_no`, `view_order`, `driver_adr_extra`) VALUES")
        add(f"(NOW() ,  '1',  '0',  {q(u.unit_id)},  {q(u.unit_name)},  {q(t)},  "
            f"{q(s.owner)},  {q(addr)},  {q(s.reg_type)},  {q(s.order_no)},  '0',  '');")
        add("--")
        add("-- iw_sys_plant_orderno")
        add(f"REPLACE INTO `iw_sys_order_no` (`row_date`, `order_no`, `db_link`, "
            f"`group_link`) VALUES (NOW(), {q(s.order_no)}, {q(t + '_param')}, "
            f"{q(t + '_groups')});")
        add("--")

    if project.system and project.system.settings:
        s = project.system
        c = s.comm
        add("-- iw_sys_processes")
        add("REPLACE INTO `iw_sys_processes` (`row_date`, `man_start`, `path`, "
            f"`process_name`, `process_id`, `process_status`) VALUES (NOW(), '0', "
            f"'iw_mb.exe', {q(s.owner)}, '', '');")
        add("--")
        add("-- iw_sys_plant_settings")
        add("REPLACE INTO `iw_sys_plant_settings` (`row_date`, `setting`, `owner`, "
            "`value`, `eng_unit`, `help_text`, `help_link`) VALUES")

        def setting(name, value, eng_unit="", help_text="", last=False, escape_tail=""):
            # escape_tail goes inside the quotes as written: the Excel tool's server line
            # ends in the escape sequence \r\n, which q() would otherwise double
            end = ";" if last else ","
            add(f"(NOW(), {q(name)}, {q(s.owner)}, {q(value)[:-1]}{escape_tail}', "
                f"{q(eng_unit)}, {q(help_text)}, ''){end}")

        setting("comm_port", c.com_port)
        setting("mb_tcp_servers", f"1;{c.ip};{c.port};1000;2;1000", "",
                "ID;IPadr;IPport;ConnTout;ConnRetries;RequestTout", escape_tail="\\r\\n")
        setting("mb_mode", "0" if c.mode == "rtu" else "2", "", "0=RTU|1=ASCII|2=TCP")
        for name, value, eng_unit, help_text in FIXED_SETTINGS:
            setting(name, value, eng_unit, help_text)
        setting("comm_parity", c.parity, "", "0=N|1=O|2=E|3=M|4=S")
        setting("comm_data_bits", str(c.data_bits))
        # DIVERGENCE: Excel always writes stop bits '1' (docs/08 item 20)
        setting("comm_stop_bits", str(c.stop_bits))
        setting("comm_baudrate", str(c.baudrate))
        for i, (name, value, eng_unit, help_text) in enumerate(FIXED_SETTINGS_TAIL):
            setting(name, value, eng_unit, help_text,
                    last=(i == len(FIXED_SETTINGS_TAIL) - 1))

    # Without truncate the INSERTs cannot go over the rows the list already has: an
    # update from 39 to 14 points gave 44 times ERROR 1062 and a re-addressed point kept
    # its old row, and a plain second import of the same script stopped the same way. So
    # this list's own rows (and, in an update, the removed ones) are deleted in each
    # block, after its CREATE TABLE - a DELETE ahead of the CREATE of a renamed table
    # failed with 1146 (review, 2026-10-24).
    clean = not o.truncates                           # replace_list truncates too
    gone = plan.removed if plan is not None else []
    gone_groups = plan.groups_gone if plan is not None else []
    own = [r.element_id for r in result.params] + gone
    if o.replace_list:
        add("--")
        lines.extend(replace_list_sql(t, written_units(project)))
    elif plan is not None:
        add("--")
        lines.extend(update_bound_sql(plan, t))
    add("--")
    add("-- Group")
    add("--")
    if o.create_tables:
        add(CREATE_GROUPS.format(t=t))
        add("--")
    if o.truncates:
        add(f"TRUNCATE TABLE iw_par_{t}_groups;")
        add("--")
    elif clean:
        lines.extend(group_cleanup_sql(t, _group_names(result) + gone_groups, own))
        add("--")
    for rec in result.group_aliases:
        add(f"INSERT INTO `iw_par_{t}_groups` VALUES " + _values(rec))
    for rec in result.groups:
        add(f"INSERT INTO `iw_par_{t}_groups` VALUES " + _values(rec))

    add("--")
    add("-- Param")
    add("--")
    if o.create_tables:
        add(CREATE_PARAM.format(t=t))
        add("--")
    if o.truncates:
        add(f"TRUNCATE TABLE iw_par_{t}_param;")
        add("--")
    elif clean:
        lines.extend(_delete_ids_sql(f"iw_par_{t}_param", own))
        add("--")
    for rec in result.params:
        add(f"INSERT INTO `iw_par_{t}_param` VALUES " + _values(rec))

    add("--")
    add("-- Set")
    add("--")
    if o.create_tables:
        add(CREATE_SET.format(t=t))
        add("--")
    if o.truncates:
        add(f"TRUNCATE TABLE iw_set_{t};")
        add("--")
    elif clean:
        lines.extend(_delete_ids_sql(f"iw_set_{t}", own))
        add("--")
    for rec in result.sets:
        add(f"INSERT INTO `iw_set_{t}` VALUES " + _values(rec))

    return "\r\n".join(lines) + "\r\n"


def default_filename(project: Project) -> str:
    return f"modbusgen-{project.plant}-{project.table}-SQL File.txt"


# ---------------------------------------------------------------------------
# Modern house style ("REPLACE INTO", schema 4.3.4) - modelled on the 2026
# reference export CarloGavazzi_EM270-v2.sql. Idempotent re-import: REPLACE
# INTO instead of TRUNCATE+INSERT, CREATE TABLE IF NOT EXISTS always emitted,
# iw_sys_* blocks at the end.
# ---------------------------------------------------------------------------

CREATE_GROUPS_MODERN = """CREATE TABLE IF NOT EXISTS `iw_par_{t}_groups` (
  `row_date` datetime NOT NULL DEFAULT '2021-01-01 00:00:00',
  `type` varchar(50) NOT NULL DEFAULT '',
  `view_order` mediumint(6) NOT NULL DEFAULT '0',
  `ref` varchar(100) NOT NULL DEFAULT '',
  `value` varchar(200) NOT NULL DEFAULT '',
  UNIQUE KEY `type` (`type`,`view_order`,`ref`,`value`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='4.3.4';"""

CREATE_PARAM_MODERN = """CREATE TABLE IF NOT EXISTS `iw_par_{t}_param` (
  `row_date` datetime NOT NULL DEFAULT '2021-01-01 00:00:00',
  `element_id` varchar(100) NOT NULL DEFAULT '',
  `driver_id` varchar(100) NOT NULL DEFAULT '',
  `alias_text` text NOT NULL,
  `menu` varchar(10) NOT NULL DEFAULT '',
  `application` text NOT NULL,
  `parameter_type` text NOT NULL,
  `factory_setting` text NOT NULL,
  `grp` text NOT NULL,
  `att` text NOT NULL,
  `eng_unit` varchar(20) NOT NULL DEFAULT '',
  `format` varchar(20) NOT NULL DEFAULT '',
  `range_min` text NOT NULL,
  `range_max` text NOT NULL,
  `scale` varchar(15) NOT NULL DEFAULT '',
  `raw_min` varchar(15) NOT NULL DEFAULT '',
  `raw_max` varchar(15) NOT NULL DEFAULT '',
  `eng_min` varchar(15) NOT NULL DEFAULT '',
  `eng_max` varchar(15) NOT NULL DEFAULT '',
  `driver_id_extra` varchar(255) NOT NULL DEFAULT '',
  `format_extra` text NOT NULL,
  UNIQUE KEY `element_id` (`element_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='4.3.4';"""

CREATE_SET_MODERN = """CREATE TABLE IF NOT EXISTS `iw_set_{t}` (
  `row_date` datetime NOT NULL DEFAULT '2021-01-01 00:00:00',
  `element_id` varchar(100) NOT NULL DEFAULT '',
  `active` enum('0','1') NOT NULL DEFAULT '0',
  `onl_ind` enum('0','1') NOT NULL DEFAULT '1',
  `update_freq` set('','fast','norm','slow','once','never') NOT NULL DEFAULT 'norm',
  `save_data` varchar(20) NOT NULL DEFAULT 'change',
  `save_freq` varchar(20) NOT NULL DEFAULT '',
  `plant_pri` char(1) NOT NULL DEFAULT '',
  `sys_pri` char(1) NOT NULL DEFAULT '',
  `alarm_type` tinyint(3) NOT NULL DEFAULT '0',
  PRIMARY KEY (`element_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='4.3.4';"""

GROUP_COLS_M = "(`row_date`, `type`, `view_order`, `ref`, `value`)"
PARAM_COLS_M = ("(`row_date`, `element_id`, `driver_id`, `alias_text`, `menu`, "
                "`application`, `parameter_type`, `factory_setting`, `grp`, `att`, "
                "`eng_unit`, `format`, `range_min`, `range_max`, `scale`, `raw_min`, "
                "`raw_max`, `eng_min`, `eng_max`, `driver_id_extra`, `format_extra`)")
SET_COLS_M = ("(`row_date`, `element_id`, `active`, `onl_ind`, `update_freq`, "
              "`save_data`, `save_freq`, `plant_pri`, `sys_pri`, `alarm_type`)")

PARITY_NUM = {"none": "0", "odd": "1", "even": "2"}

# (setting, fixed-value-or-None-for-dynamic, eng_unit, help_text) in EM270 order
MODERN_SETTINGS = [
    ("comm_port", None, "", ""),
    ("comm_parity", None, "", "0=N|1=O|2=E|3=M|4=S"),
    ("comm_data_bits", None, "", ""),
    ("comm_stop_bits", None, "", ""),
    ("comm_baudrate", None, "", ""),
    ("mb_mode", None, "", "0=RTU|1=ASCII|2=TCP"),
    ("force_word_not_byte", "0", "", "0|1"),
    ("handshake", "0", "", "0|1|2"),
    ("check_rate", "1", "ms", ""),
    ("max_outstanding_packets", "-1", "", ""),
    ("packet_timeout", "1", "sec.", ""),
    ("idle_event_rate", "250", "msec.", ""),
    ("sql_queue_poll_time", "2000", "msec.", ""),
    ("max_error_count", "2", "", ""),
    ("mb_request_timeout", "1000", "ms", ""),
    ("mb_request_retries", "2", "", ""),
    ("com_error_alarm_delay", "10", "min.", ""),
    ("show_queue_info", "0", "", ""),
    ("speed_index_block", "10", "", ""),
    ("speed_index_offline", "10", "", ""),
    ("speed_index_slow", "1", "", ""),
    ("speed_index_norm", "1", "", ""),
    ("max_param_block_time", "2", "hours", ""),
    ("max_group_count", "1", "", ""),
    ("value_quality_check_limit", "0", "", "0 = disabled"),
    ("mb_tcp_servers", None, "", "ID;IPadr;IPport;ConnTout;ConnRetries;RequestTout"),
    ("mux_settle_time", "1500", "ms",
     "Time for the muxed input to settle. The value shuld be a multiple off 100."),
    ("startup_delay", "15", "Sec.", ""),
    ("allow_crc_swap", "0", "", "Default 0"),
    ("enablers485mode", "0", "", "0=OFF|0 < delay in ms and ON"),
    ("alarm_handler", "", "", ""),
]


def _mrow(values, last=False) -> str:
    """One VALUES row, EM270 style: quoted strings, bare ints, ', ' separators."""
    parts = [str(v) if isinstance(v, int) else q(v) for v in values]
    return "(" + ", ".join(parts) + (");" if last else "),")


def _mblock(lines, header, rows, batch: int = BATCH_ROWS, budget: int = BATCH_BYTES):
    """The rows as REPLACE statements of at most `batch` rows and `budget` characters
    each (BATCH_ROWS, BATCH_BYTES) - a single row longer than the budget still gets its
    own statement."""
    # No rows, no statement: a bare "REPLACE INTO ... VALUES" is a syntax error, and with
    # truncate or replace_list on it failed after the tables had already been emptied
    texts = [_mrow(row) for row in rows]
    start = 0
    while start < len(texts):
        size, end = len(header) + 9, start
        while end < len(texts) and end - start < batch \
                and (end == start or size + len(texts[end]) + 2 <= budget):
            size += len(texts[end]) + 2
            end += 1
        lines.append(header + " VALUES")
        lines.extend(texts[start:end - 1])
        lines.append(texts[end - 1][:-1] + ";")
        start = end


def render_sql_modern(project: Project, result: RunResult,
                      plan: UpdatePlan | None = None) -> str:
    t = project.table
    ts = result.params[0].row_date if result.params else \
        (result.group_aliases[0].row_date if result.group_aliases else "")
    lines: list[str] = []
    add = lines.append

    add('SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";')
    add("")
    add("-- If duplicates: The parameter list (_group, _param and set_) is from the "
        "first/top 'selected rows'")
    add("")
    add("")

    if project.options.replace_list:
        lines.extend(replace_list_sql(t, written_units(project)))
        add("")
        add("")
    elif plan is not None:
        lines.extend(update_bound_sql(plan, t))
        add("")
        add("")

    add(CREATE_GROUPS_MODERN.format(t=t))
    add("")
    if project.options.truncates:
        add(f"TRUNCATE TABLE `iw_par_{t}_groups`;")
        add("")
    else:
        lines.extend(group_cleanup_sql(
            t, _group_names(result) + (plan.groups_gone if plan is not None else []),
            [r.element_id for r in result.params] + (plan.removed if plan is not None else [])))
        add("")
    group_rows = [(ts, "default_link", 2, "", "")]
    for rec in result.group_aliases:
        if rec.type == "group_alias":
            group_rows.append((ts, "group_alias", int(rec.view_order), rec.ref,
                               rec.value))
    for rec in result.groups:
        group_rows.append((ts, "group", int(rec.view_order), rec.ref,
                           clip_element_id(rec.value)))
    _mblock(lines, f"REPLACE INTO `iw_par_{t}_groups` {GROUP_COLS_M}", group_rows)
    add("")
    add("")

    add(CREATE_PARAM_MODERN.format(t=t))
    add("")
    if project.options.truncates:
        add(f"TRUNCATE TABLE `iw_par_{t}_param`;")
        add("")
    elif plan is not None and plan.removed:
        lines.extend(update_table_sql(plan, f"iw_par_{t}_param"))
        add("")
    _mblock(lines, f"REPLACE INTO `iw_par_{t}_param` {PARAM_COLS_M}",
            [_sql_row(rec) for rec in result.params])
    add("")
    add("")

    add(CREATE_SET_MODERN.format(t=t))
    add("")
    if project.options.truncates:
        add(f"TRUNCATE TABLE `iw_set_{t}`;")
        add("")
    elif plan is not None and plan.removed:
        lines.extend(update_table_sql(plan, f"iw_set_{t}"))
        add("")
    set_rows = []
    for rec in result.sets:
        vals = _sql_row(rec)
        set_rows.append(vals[:-1] + (int(vals[-1]),))   # alarm_type bare, as in the reference
    _mblock(lines, f"REPLACE INTO `iw_set_{t}` {SET_COLS_M}", set_rows)

    s = project.system
    if s and (s.units or s.settings):
        add("")
        add("")
    if s and s.units:
        add("-- Watch out for duplicate unit_id!")
        add("")
        _mblock(lines, "REPLACE INTO `iw_sys_plant_units` (`row_date`, `active`, "
                "`blockout`, `unit_id`, `unit_name`, `grp_name`, `driver_type`, "
                "`driver_addr`, `regulator_type`, `order_no`, `view_order`, "
                "`driver_adr_extra`, `unit_extra`)",
                [(ts, "1", "0", u.unit_id, u.unit_name, t, s.owner,
                  f"{s.driver_addr_prefix}{u.driver_addr}", s.reg_type, s.order_no,
                  int(u.view_order), "", "")
                 for u in s.effective_units()])
        add("")
        _mblock(lines, "REPLACE INTO `iw_sys_order_no` (`row_date`, `order_no`, "
                "`db_link`, `group_link`)",
                [(ts, s.order_no, f"{t}_param", f"{t}_groups")])
        add("")
    if s and s.settings:
        _mblock(lines, "REPLACE INTO `iw_sys_processes` (`row_date`, `man_start`, "
                "`path`, `process_name`, `process_id`, `process_status`)",
                [(ts, "0", "iw_mb.exe", s.owner, "", "")])
        add("")
        add("-- If duplicates: The iw_sys_plant_settings is from the first/top "
            "'selected rows'")
        add("")
        c = s.comm
        dynamic = {
            "comm_port": str(c.com_port),
            "comm_parity": PARITY_NUM.get(str(c.parity).lower(), str(c.parity)),
            "comm_data_bits": str(c.data_bits),
            "comm_stop_bits": str(c.stop_bits),
            "comm_baudrate": str(c.baudrate),
            "mb_mode": "0" if c.mode == "rtu" else "2",
            "mb_tcp_servers": f"1;{c.ip or 'XXX.XXX.XXX.XXX'};{c.port};1000;2;1000",
        }
        rows = [(ts, name, s.owner,
                 dynamic[name] if fixed is None else fixed, eng, help_, "")
                for name, fixed, eng, help_ in MODERN_SETTINGS]
        _mblock(lines, "REPLACE INTO `iw_sys_plant_settings` (`row_date`, `setting`, "
                "`owner`, `value`, `eng_unit`, `help_text`, `help_link`)", rows)

    return "\r\n".join(lines) + "\r\n"
