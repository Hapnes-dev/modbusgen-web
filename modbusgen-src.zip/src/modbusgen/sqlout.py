"""SQL script serialization, matching PrintAsString_Insert_script byte-for-byte where
docs/03-outputs.md specifies it (block order, separators, single-line quoted INSERTs,
CRLF). DIVERGENCE: values are SQL-escaped (apostrophe doubled); the Excel tool does not
escape at all (docs/08 item 21).
"""
from __future__ import annotations

from dataclasses import astuple

from .model import Project
from .rules import RunResult

CREATE_GROUPS = ("CREATE TABLE IF NOT EXISTS `iw_par_{t}_groups` (`row_date` datetime "
    "NOT NULL DEFAULT '2004-01-10 00:00:00', `type` varchar(50) NOT NULL DEFAULT '', "
    "`view_order` mediumint(6) NOT NULL DEFAULT '0', `ref` varchar(100) NOT NULL DEFAULT '', "
    "`value` varchar(200) NOT NULL DEFAULT '', UNIQUE KEY `type` "
    "(`type`,`view_order`,`ref`,`value`)) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='2.0.0';")

CREATE_PARAM = ("CREATE TABLE IF NOT EXISTS `iw_par_{t}_param` (`row_date` datetime "
    "NOT NULL DEFAULT '2002-01-10 00:00:00', `element_id` varchar(100) NOT NULL DEFAULT '', "
    "`driver_id` varchar(100) NOT NULL DEFAULT '', `alias_text` text NOT NULL, "
    "`menu` varchar(10) NOT NULL DEFAULT '', `application` text NOT NULL, "
    "`parameter_type` text NOT NULL, `factory_setting` text NOT NULL, `grp` text NOT NULL, "
    "`att` text NOT NULL, `eng_unit` varchar(20) NOT NULL DEFAULT '', "
    "`format` varchar(20) NOT NULL DEFAULT '', `range_min` text NOT NULL, "
    "`range_max` text NOT NULL, `scale` varchar(15) NOT NULL DEFAULT '', "
    "`raw_min` varchar(15) NOT NULL DEFAULT '', `raw_max` varchar(15) NOT NULL DEFAULT '', "
    "`eng_min` varchar(15) NOT NULL DEFAULT '', `eng_max` varchar(15) NOT NULL DEFAULT '', "
    "`driver_id_extra` varchar(255) NOT NULL DEFAULT '', `format_extra` text NOT NULL, "
    "UNIQUE KEY `element_id` (`element_id`)) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='3.2.3';")

CREATE_SET = ("CREATE TABLE IF NOT EXISTS `iw_set_{t}` (`row_date` datetime NOT NULL "
    "DEFAULT '2004-01-10 00:00:00', `element_id` varchar(100) NOT NULL DEFAULT '', "
    "`active` enum('0','1') NOT NULL DEFAULT '0', `onl_ind` enum('0','1') NOT NULL DEFAULT '1', "
    "`update_freq` set('','fast','norm','slow','once','never') NOT NULL DEFAULT 'norm', "
    "`save_data` varchar(20) NOT NULL DEFAULT 'change', `save_freq` varchar(20) NOT NULL "
    "DEFAULT '', `plant_pri` char(1) NOT NULL DEFAULT '', `sys_pri` char(1) NOT NULL "
    "DEFAULT '', `alarm_type` tinyint(3) NOT NULL DEFAULT '0', PRIMARY KEY (`element_id`)) "
    "ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='3.0.0';")

# fixed iw_sys_plant_settings lines: (setting, value, eng_unit, help_text)
FIXED_SETTINGS = [
    ("mb_request_retries", "2", "", ""),
    ("force_word_not_byte", "0", "", "0|1"),
    ("handshake", "0", "", "0|1|2"),
    ("check_rate", "1", "ms", ""),
]
FIXED_SETTINGS_TAIL = [
    ("max_outstanding_packets", "-1", "", ""),
    ("packet_timeout", "1", "sec.", ""),
    ("idle_event_rate", "250", "msec.", ""),
    ("sql_queue_poll_time", "2000", "msec.", ""),
    ("max_error_count", "2", "", ""),
    ("mb_request_timeout", "1000", "ms", ""),
    ("com_error_alarm_delay", "10", "min.", ""),
    ("show_queue_info", "0", "", ""),
    ("speed_index_block", "10", "", ""),
    ("speed_index_offline", "10", "", ""),
    ("speed_index_slow", "1", "", ""),
    ("speed_index_norm", "1", "", ""),
    ("max_param_block_time", "2", "hours", ""),
    ("max_group_count", "1", "", ""),
    ("value_quality_check_limit", "0", "", "0 = disabled"),
    ("mux_settle_time", "1500", "ms",
     "Time for the muxed input to settle. The value shuld be a multiple off 100."),
    ("startup_delay", "15", "Sec.", ""),
    ("alarm_handler", "", "", ""),
    ("mb_tcp_connect_retries_default", "2", "", ""),
    ("mb_tcp_connect_timeout_default", "1000", "ms", ""),
]


def q(value: str) -> str:
    return "'" + str(value).replace("'", "''") + "'"


def _values(record) -> str:
    return "(" + ",".join(q(v) for v in astuple(record)) + ");"


def render_sql(project: Project, result: RunResult) -> str:
    if project.options.sql_format == "legacy":
        return render_sql_legacy(project, result)
    return render_sql_modern(project, result)


def render_sql_legacy(project: Project, result: RunResult) -> str:
    t = project.table
    o = project.options
    lines: list[str] = []
    add = lines.append

    if project.system and project.system.units:
        s = project.system
        u = s.effective_units()[0]           # the legacy tool emitted a single unit
        addr = f"{s.driver_addr_prefix}{u.driver_addr}"
        add("-- iw_sys_plant_units")
        add("INSERT INTO `iw_sys_plant_units` (`row_date`, `active`, `blockout`, "
            "`unit_id`, `unit_name`, `grp_name`, `driver_type`, `driver_addr`, "
            "`regulator_type`, `order_no`, `view_order`, `driver_adr_extra`) VALUES")
        add(f"(NOW() ,  '1',  '0',  {q(u.unit_id)},  {q(u.unit_name)},  {q(t)},  "
            f"{q(s.owner)},  {q(addr)},  {q(s.reg_type)},  {q(s.order_no)},  '0',  '');")
        add("--")
        add("-- iw_sys_plant_orderno")
        add(f"INSERT INTO `iw_sys_order_no` (`row_date`, `order_no`, `db_link`, "
            f"`group_link`) VALUES (NOW(), {q(s.order_no)}, {q(t + '_param')}, "
            f"{q(t + '_groups')});")
        add("--")

    if project.system and project.system.settings:
        s = project.system
        c = s.comm
        add("-- iw_sys_processes")
        add("INSERT INTO `iw_sys_processes` (`row_date`, `man_start`, `path`, "
            f"`process_name`, `process_id`, `process_status`) VALUES (NOW(), '0', "
            f"'iw_mb.exe', {q(s.owner)}, '', '');")
        add("--")
        add("-- iw_sys_plant_settings")
        add("INSERT INTO `iw_sys_plant_settings` (`row_date`, `setting`, `owner`, "
            "`value`, `eng_unit`, `help_text`, `help_link`) VALUES")

        def setting(name, value, eng_unit="", help_text="", last=False):
            end = ";" if last else ","
            add(f"(NOW(), {q(name)}, {q(s.owner)}, {q(value)}, {q(eng_unit)}, "
                f"{q(help_text)}, ''){end}")

        setting("comm_port", c.com_port)
        setting("mb_tcp_servers", f"1;{c.ip};{c.port};1000;2;1000\\r\\n", "",
                "ID;IPadr;IPport;ConnTout;ConnRetries;RequestTout")
        setting("mb_mode", "0" if c.mode == "rtu" else "2", "", "0=RTU|1=ASCII|2=TCP")
        for name, value, eng_unit, help_text in FIXED_SETTINGS:
            setting(name, value, eng_unit, help_text)
        setting("comm_parity", c.parity, "", "0=N|1=O|2=E|3=M|4=S")
        setting("comm_data_bits", str(c.data_bits))
        # DIVERGENCE: Excel always writes stop bits '1' (docs/08 item 20)
        setting("comm_stop_bits", str(c.stop_bits))
        setting("comm_baudrate", str(c.baudrate))
        for i, (name, value, eng_unit, help_text) in enumerate(FIXED_SETTINGS_TAIL):
            setting(name, value, eng_unit, help_text,
                    last=(i == len(FIXED_SETTINGS_TAIL) - 1))

    add("--")
    add("-- Group")
    add("--")
    if o.create_tables:
        add(CREATE_GROUPS.format(t=t))
        add("--")
    if o.truncate:
        add(f"TRUNCATE TABLE iw_par_{t}_groups;")
        add("--")
    for rec in result.group_aliases:
        add(f"INSERT INTO `iw_par_{t}_groups` VALUES " + _values(rec))
    for rec in result.groups:
        add(f"INSERT INTO `iw_par_{t}_groups` VALUES " + _values(rec))

    add("--")
    add("-- Param")
    add("--")
    if o.create_tables:
        add(CREATE_PARAM.format(t=t))
        add("--")
    if o.truncate:
        add(f"TRUNCATE TABLE iw_par_{t}_param;")
        add("--")
    for rec in result.params:
        add(f"INSERT INTO `iw_par_{t}_param` VALUES " + _values(rec))

    add("--")
    add("-- Set")
    add("--")
    if o.create_tables:
        add(CREATE_SET.format(t=t))
        add("--")
    if o.truncate:
        add(f"TRUNCATE TABLE iw_set_{t};")
        add("--")
    for rec in result.sets:
        add(f"INSERT INTO `iw_set_{t}` VALUES " + _values(rec))

    return "\r\n".join(lines) + "\r\n"


def default_filename(project: Project) -> str:
    return f"modbusgen-{project.plant}-{project.table}-SQL File.txt"


# ---------------------------------------------------------------------------
# Modern house style ("REPLACE INTO", schema 4.3.4) - modelled on the 2026
# reference export CarloGavazzi_EM270-v2.sql. Idempotent re-import: REPLACE
# INTO instead of TRUNCATE+INSERT, CREATE TABLE IF NOT EXISTS always emitted,
# iw_sys_* blocks at the end.
# ---------------------------------------------------------------------------

CREATE_GROUPS_MODERN = """CREATE TABLE IF NOT EXISTS `iw_par_{t}_groups` (
  `row_date` datetime NOT NULL DEFAULT '2021-01-01 00:00:00',
  `type` varchar(50) NOT NULL DEFAULT '',
  `view_order` mediumint(6) NOT NULL DEFAULT '0',
  `ref` varchar(100) NOT NULL DEFAULT '',
  `value` varchar(200) NOT NULL DEFAULT '',
  UNIQUE KEY `type` (`type`,`view_order`,`ref`,`value`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='4.3.4';"""

CREATE_PARAM_MODERN = """CREATE TABLE IF NOT EXISTS `iw_par_{t}_param` (
  `row_date` datetime NOT NULL DEFAULT '2021-01-01 00:00:00',
  `element_id` varchar(100) NOT NULL DEFAULT '',
  `driver_id` varchar(100) NOT NULL DEFAULT '',
  `alias_text` text NOT NULL,
  `menu` varchar(10) NOT NULL DEFAULT '',
  `application` text NOT NULL,
  `parameter_type` text NOT NULL,
  `factory_setting` text NOT NULL,
  `grp` text NOT NULL,
  `att` text NOT NULL,
  `eng_unit` varchar(20) NOT NULL DEFAULT '',
  `format` varchar(20) NOT NULL DEFAULT '',
  `range_min` text NOT NULL,
  `range_max` text NOT NULL,
  `scale` varchar(15) NOT NULL DEFAULT '',
  `raw_min` varchar(15) NOT NULL DEFAULT '',
  `raw_max` varchar(15) NOT NULL DEFAULT '',
  `eng_min` varchar(15) NOT NULL DEFAULT '',
  `eng_max` varchar(15) NOT NULL DEFAULT '',
  `driver_id_extra` varchar(255) NOT NULL DEFAULT '',
  `format_extra` text NOT NULL,
  UNIQUE KEY `element_id` (`element_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='4.3.4';"""

CREATE_SET_MODERN = """CREATE TABLE IF NOT EXISTS `iw_set_{t}` (
  `row_date` datetime NOT NULL DEFAULT '2021-01-01 00:00:00',
  `element_id` varchar(100) NOT NULL DEFAULT '',
  `active` enum('0','1') NOT NULL DEFAULT '0',
  `onl_ind` enum('0','1') NOT NULL DEFAULT '1',
  `update_freq` set('','fast','norm','slow','once','never') NOT NULL DEFAULT 'norm',
  `save_data` varchar(20) NOT NULL DEFAULT 'change',
  `save_freq` varchar(20) NOT NULL DEFAULT '',
  `plant_pri` char(1) NOT NULL DEFAULT '',
  `sys_pri` char(1) NOT NULL DEFAULT '',
  `alarm_type` tinyint(3) NOT NULL DEFAULT '0',
  PRIMARY KEY (`element_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='4.3.4';"""

GROUP_COLS_M = "(`row_date`, `type`, `view_order`, `ref`, `value`)"
PARAM_COLS_M = ("(`row_date`, `element_id`, `driver_id`, `alias_text`, `menu`, "
                "`application`, `parameter_type`, `factory_setting`, `grp`, `att`, "
                "`eng_unit`, `format`, `range_min`, `range_max`, `scale`, `raw_min`, "
                "`raw_max`, `eng_min`, `eng_max`, `driver_id_extra`, `format_extra`)")
SET_COLS_M = ("(`row_date`, `element_id`, `active`, `onl_ind`, `update_freq`, "
              "`save_data`, `save_freq`, `plant_pri`, `sys_pri`, `alarm_type`)")

PARITY_NUM = {"none": "0", "odd": "1", "even": "2"}

# (setting, fixed-value-or-None-for-dynamic, eng_unit, help_text) in EM270 order
MODERN_SETTINGS = [
    ("comm_port", None, "", ""),
    ("comm_parity", None, "", "0=N|1=O|2=E|3=M|4=S"),
    ("comm_data_bits", None, "", ""),
    ("comm_stop_bits", None, "", ""),
    ("comm_baudrate", None, "", ""),
    ("mb_mode", None, "", "0=RTU|1=ASCII|2=TCP"),
    ("force_word_not_byte", "0", "", "0|1"),
    ("handshake", "0", "", "0|1|2"),
    ("check_rate", "1", "ms", ""),
    ("max_outstanding_packets", "-1", "", ""),
    ("packet_timeout", "1", "sec.", ""),
    ("idle_event_rate", "250", "msec.", ""),
    ("sql_queue_poll_time", "2000", "msec.", ""),
    ("max_error_count", "2", "", ""),
    ("mb_request_timeout", "1000", "ms", ""),
    ("mb_request_retries", "2", "", ""),
    ("com_error_alarm_delay", "10", "min.", ""),
    ("show_queue_info", "0", "", ""),
    ("speed_index_block", "10", "", ""),
    ("speed_index_offline", "10", "", ""),
    ("speed_index_slow", "1", "", ""),
    ("speed_index_norm", "1", "", ""),
    ("max_param_block_time", "2", "hours", ""),
    ("max_group_count", "1", "", ""),
    ("value_quality_check_limit", "0", "", "0 = disabled"),
    ("mb_tcp_servers", None, "", "ID;IPadr;IPport;ConnTout;ConnRetries;RequestTout"),
    ("mux_settle_time", "1500", "ms",
     "Time for the muxed input to settle. The value shuld be a multiple off 100."),
    ("startup_delay", "15", "Sec.", ""),
    ("allow_crc_swap", "0", "", "Default 0"),
    ("enablers485mode", "0", "", "0=OFF|0 < delay in ms and ON"),
    ("alarm_handler", "", "", ""),
]


def _mrow(values, last=False) -> str:
    """One VALUES row, EM270 style: quoted strings, bare ints, ', ' separators."""
    parts = [str(v) if isinstance(v, int) else q(v) for v in values]
    return "(" + ", ".join(parts) + (");" if last else "),")


def _mblock(lines, header, rows):
    lines.append(header + " VALUES")
    for i, row in enumerate(rows):
        lines.append(_mrow(row, last=(i == len(rows) - 1)))


def render_sql_modern(project: Project, result: RunResult) -> str:
    t = project.table
    ts = result.params[0].row_date if result.params else \
        (result.group_aliases[0].row_date if result.group_aliases else "")
    lines: list[str] = []
    add = lines.append

    add('SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";')
    add("")
    add("-- If duplicates: The parameter list (_group, _param and set_) is from the "
        "first/top 'selected rows'")
    add("")
    add("")

    add(CREATE_GROUPS_MODERN.format(t=t))
    add("")
    group_rows = [(ts, "default_link", 2, "", "")]
    for rec in result.group_aliases:
        if rec.type == "group_alias":
            group_rows.append((ts, "group_alias", int(rec.view_order), rec.ref,
                               rec.value))
    for rec in result.groups:
        group_rows.append((ts, "group", int(rec.view_order), rec.ref, rec.value))
    _mblock(lines, f"REPLACE INTO `iw_par_{t}_groups` {GROUP_COLS_M}", group_rows)
    add("")
    add("")

    add(CREATE_PARAM_MODERN.format(t=t))
    add("")
    _mblock(lines, f"REPLACE INTO `iw_par_{t}_param` {PARAM_COLS_M}",
            [tuple(astuple(rec)) for rec in result.params])
    add("")
    add("")

    add(CREATE_SET_MODERN.format(t=t))
    add("")
    set_rows = []
    for rec in result.sets:
        vals = list(astuple(rec))
        vals[-1] = int(vals[-1])            # alarm_type bare, as in the reference
        set_rows.append(tuple(vals))
    _mblock(lines, f"REPLACE INTO `iw_set_{t}` {SET_COLS_M}", set_rows)

    s = project.system
    if s and (s.units or s.settings):
        add("")
        add("")
    if s and s.units:
        add("-- Watch out for duplicate unit_id!")
        add("")
        _mblock(lines, "REPLACE INTO `iw_sys_plant_units` (`row_date`, `active`, "
                "`blockout`, `unit_id`, `unit_name`, `grp_name`, `driver_type`, "
                "`driver_addr`, `regulator_type`, `order_no`, `view_order`, "
                "`driver_adr_extra`, `unit_extra`)",
                [(ts, "1", "0", u.unit_id, u.unit_name, t, s.owner,
                  f"{s.driver_addr_prefix}{u.driver_addr}", s.reg_type, s.order_no,
                  int(u.view_order), "", "")
                 for u in s.effective_units()])
        add("")
        _mblock(lines, "REPLACE INTO `iw_sys_order_no` (`row_date`, `order_no`, "
                "`db_link`, `group_link`)",
                [(ts, s.order_no, f"{t}_param", f"{t}_groups")])
        add("")
    if s and s.settings:
        _mblock(lines, "REPLACE INTO `iw_sys_processes` (`row_date`, `man_start`, "
                "`path`, `process_name`, `process_id`, `process_status`)",
                [(ts, "0", "iw_mb.exe", s.owner, "", "")])
        add("")
        add("-- If duplicates: The iw_sys_plant_settings is from the first/top "
            "'selected rows'")
        add("")
        c = s.comm
        dynamic = {
            "comm_port": str(c.com_port),
            "comm_parity": PARITY_NUM.get(str(c.parity).lower(), str(c.parity)),
            "comm_data_bits": str(c.data_bits),
            "comm_stop_bits": str(c.stop_bits),
            "comm_baudrate": str(c.baudrate),
            "mb_mode": "0" if c.mode == "rtu" else "2",
            "mb_tcp_servers": f"1;{c.ip or 'XXX.XXX.XXX.XXX'};{c.port};1000;2;1000",
        }
        rows = [(ts, name, s.owner,
                 dynamic[name] if fixed is None else fixed, eng, help_, "")
                for name, fixed, eng, help_ in MODERN_SETTINGS]
        _mblock(lines, "REPLACE INTO `iw_sys_plant_settings` (`row_date`, `setting`, "
                "`owner`, `value`, `eng_unit`, `help_text`, `help_link`)", rows)

    return "\r\n".join(lines) + "\r\n"
