"""SQL script serialization, matching PrintAsString_Insert_script byte-for-byte where
docs/03-outputs.md specifies it (block order, separators, single-line quoted INSERTs,
CRLF). DIVERGENCE: values are SQL-escaped (apostrophe doubled); the Excel tool does not
escape at all (docs/08 item 21).
"""
from __future__ import annotations

from dataclasses import astuple, dataclass

from .model import Project
from .rules import RunResult

CREATE_GROUPS = ("CREATE TABLE IF NOT EXISTS `iw_par_{t}_groups` (`row_date` datetime "
    "NOT NULL DEFAULT '2004-01-10 00:00:00', `type` varchar(50) NOT NULL DEFAULT '', "
    "`view_order` mediumint(6) NOT NULL DEFAULT '0', `ref` varchar(100) NOT NULL DEFAULT '', "
    "`value` varchar(200) NOT NULL DEFAULT '', UNIQUE KEY `type` "
    "(`type`,`view_order`,`ref`,`value`)) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='2.0.0';")

CREATE_PARAM = ("CREATE TABLE IF NOT EXISTS `iw_par_{t}_param` (`row_date` datetime "
    "NOT NULL DEFAULT '2002-01-10 00:00:00', `element_id` varchar(100) NOT NULL DEFAULT '', "
    "`driver_id` varchar(100) NOT NULL DEFAULT '', `alias_text` text NOT NULL, "
    "`menu` varchar(10) NOT NULL DEFAULT '', `application` text NOT NULL, "
    "`parameter_type` text NOT NULL, `factory_setting` text NOT NULL, `grp` text NOT NULL, "
    "`att` text NOT NULL, `eng_unit` varchar(20) NOT NULL DEFAULT '', "
    "`format` varchar(20) NOT NULL DEFAULT '', `range_min` text NOT NULL, "
    "`range_max` text NOT NULL, `scale` varchar(15) NOT NULL DEFAULT '', "
    "`raw_min` varchar(15) NOT NULL DEFAULT '', `raw_max` varchar(15) NOT NULL DEFAULT '', "
    "`eng_min` varchar(15) NOT NULL DEFAULT '', `eng_max` varchar(15) NOT NULL DEFAULT '', "
    "`driver_id_extra` varchar(255) NOT NULL DEFAULT '', `format_extra` text NOT NULL, "
    "UNIQUE KEY `element_id` (`element_id`)) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='3.2.3';")

CREATE_SET = ("CREATE TABLE IF NOT EXISTS `iw_set_{t}` (`row_date` datetime NOT NULL "
    "DEFAULT '2004-01-10 00:00:00', `element_id` varchar(100) NOT NULL DEFAULT '', "
    "`active` enum('0','1') NOT NULL DEFAULT '0', `onl_ind` enum('0','1') NOT NULL DEFAULT '1', "
    "`update_freq` set('','fast','norm','slow','once','never') NOT NULL DEFAULT 'norm', "
    "`save_data` varchar(20) NOT NULL DEFAULT 'change', `save_freq` varchar(20) NOT NULL "
    "DEFAULT '', `plant_pri` char(1) NOT NULL DEFAULT '', `sys_pri` char(1) NOT NULL "
    "DEFAULT '', `alarm_type` tinyint(3) NOT NULL DEFAULT '0', PRIMARY KEY (`element_id`)) "
    "ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='3.0.0';")

# fixed iw_sys_plant_settings lines: (setting, value, eng_unit, help_text)
FIXED_SETTINGS = [
    ("mb_request_retries", "2", "", ""),
    ("force_word_not_byte", "0", "", "0|1"),
    ("handshake", "0", "", "0|1|2"),
    ("check_rate", "1", "ms", ""),
]
FIXED_SETTINGS_TAIL = [
    ("max_outstanding_packets", "-1", "", ""),
    ("packet_timeout", "1", "sec.", ""),
    ("idle_event_rate", "250", "msec.", ""),
    ("sql_queue_poll_time", "2000", "msec.", ""),
    ("max_error_count", "2", "", ""),
    ("mb_request_timeout", "1000", "ms", ""),
    ("com_error_alarm_delay", "10", "min.", ""),
    ("show_queue_info", "0", "", ""),
    ("speed_index_block", "10", "", ""),
    ("speed_index_offline", "10", "", ""),
    ("speed_index_slow", "1", "", ""),
    ("speed_index_norm", "1", "", ""),
    ("max_param_block_time", "2", "hours", ""),
    ("max_group_count", "1", "", ""),
    ("value_quality_check_limit", "0", "", "0 = disabled"),
    ("mux_settle_time", "1500", "ms",
     "Time for the muxed input to settle. The value shuld be a multiple off 100."),
    ("startup_delay", "15", "Sec.", ""),
    ("alarm_handler", "", "", ""),
    ("mb_tcp_connect_retries_default", "2", "", ""),
    ("mb_tcp_connect_timeout_default", "1000", "ms", ""),
]


def q(value: str) -> str:
    """A MySQL string literal. Backslash is MySQL's escape character unless the session
    sets NO_BACKSLASH_ESCAPES, which these scripts never do - modern even replaces the
    whole SQL_MODE - so it is doubled before the quotes are. Left alone, `C:\\temp`
    stored a tab, and a text ending in a backslash swallowed its closing quote and broke
    the whole multi-row statement (2026-10-23)."""
    return "'" + str(value).replace("\\", "\\\\").replace("'", "''") + "'"


def _values(record) -> str:
    return "(" + ",".join(q(v) for v in astuple(record)) + ");"


def group_cleanup_sql(table: str, groups: list[str], element_ids: list[str]) -> list[str]:
    """The group rows this script writes again, deleted first.

    The groups table's unique key is (type, view_order, ref, value), and a point's
    view_order is its position in its group. So when a point is added, removed or moved
    inside a group, REPLACE INTO cannot replace the old row of every later point: it
    adds a second one at the new position, and the old stays. A review simulating
    re-imports found 33 extra rows from one inserted point (2026-10-23); plant 2313 held
    1279 group rows for 369 template rows. Only this list's own rows go - the link row,
    its groups' alias rows, and the membership rows of its own element_ids - so a list
    that adds a few points to a table leaves the rest alone.
    """
    out = ["-- This list's own group rows are cleared first, so a point that moved inside its",
           "-- group does not keep its old position row beside the new one.",
           f"DELETE FROM `iw_par_{table}_groups` WHERE `type` = 'default_link'"]
    if groups:
        out.append("  OR (`type` = 'group_alias' AND `ref` IN ("
                   + ", ".join(q(g) for g in groups) + "))")
    if element_ids:
        ids = [q(e) for e in element_ids]
        rows = [", ".join(ids[i:i + 6]) for i in range(0, len(ids), 6)]
        out.append("  OR (`type` = 'group' AND `value` IN (" + rows[0] + ("," if len(rows) > 1 else "))"))
        for i, row in enumerate(rows[1:], start=2):
            out.append("    " + row + ("," if i < len(rows) else "))"))
    out[-1] += ";"
    return out


def replace_list_sql(table: str, unit_ids: list[str] | tuple[str, ...] = ()) -> list[str]:
    """options.replace_list: the old list goes before the new one is written.

    An import never deletes (docs/16 section 16.6): REPLACE INTO keys on element_id, so
    a row the new list no longer carries stays, in the template and in the unit's bound
    rows, and the plant goes on showing it. This is section 16.6.4's clean-out, written
    into the script. The bound rows of every unit whose group is this table go first -
    the units the script's own iw_sys_plant_units rows give grp_name = table - keeping
    the two IWMAC adds itself, com_stat and com_error. The three tables are then emptied
    before each block, because replace_list implies Options.truncates. The parameter
    build binds the new rows afterwards.

    The units the script itself names count too. Modern writes its iw_sys_plant_units
    rows last, so a unit that moves to this table from an older one, or a table that was
    renamed, has no grp_name = table yet when this runs, and the subquery alone deleted
    nothing (review, 2026-10-23).
    """
    by_group = f"`unit_id` IN (SELECT `unit_id` FROM `iw_sys_plant_units` WHERE `grp_name` = {q(table)})"
    where = ([f"WHERE (`unit_id` IN ({', '.join(q(u) for u in unit_ids)})", f"   OR {by_group})"]
             if unit_ids else [f"WHERE {by_group}"])
    return [
        "-- replace_list: the old list is deleted before this one is written - the bound",
        f"-- rows of every unit whose group is {table} (com_stat and com_error stay), then",
        "-- each table below. Back up first; run Generate Param/Grp/Set afterwards.",
        "DELETE FROM `iw_gen_driver_parameters`",
        *where,
        "  AND `element_id` NOT IN ('com_stat', 'com_error');",
    ]


def _unit_ids(project: Project) -> list[str]:
    """The units the script itself writes, for replace_list's DELETE."""
    s = project.system
    if s is None:
        return []
    return [u.unit_id for u in s.effective_units() if str(u.unit_id or "").strip()]


def _in_list(values, indent: str = "    ", per_line: int = 6) -> list[str]:
    """`(a, b, ..., z)` as SQL, six values a line, for long IN lists."""
    quoted = [q(v) for v in values]
    rows = [", ".join(quoted[i:i + per_line]) for i in range(0, len(quoted), per_line)]
    if len(rows) == 1:
        return ["(" + rows[0] + ")"]
    return (["(" + rows[0] + ","] + [indent + r + "," for r in rows[1:-1]]
            + [indent + rows[-1] + ")"])


def _key(element_id: str) -> str:
    """An element_id as the plant's tables compare it: latin1_swedish_ci ignores case
    and trailing spaces, and the column is varchar(100)."""
    return str(element_id)[:100].rstrip().casefold()


@dataclass
class UpdatePlan:
    """What happens on the plant when this list replaces its previous version.

    REPLACE INTO keys on element_id (group + driver id), so a point that was removed,
    moved to another address or another group, or renamed into another group, leaves
    its old row behind in the template and bound to every unit - still polled, and
    still shown (docs/16 section 16.6). replace_list deletes the whole old list, and
    with it every setting made on the plant. Given the previous version, the script can
    delete exactly the rows that are gone, and leave the rest - and their settings -
    alone (2026-10-23).
    """
    previous_table: str
    added: list[str]
    removed: list[str]              # element_ids only the previous version has
    readdressed: list[str]          # in both, with another driver_id (explicit element_id)
    unchanged: int
    groups_gone: list[str]
    removed_rows: list[tuple[str, str, str]]   # (element_id, driver_id, alias_text)
    units: list[str]                # units either version's script names

    def summary(self) -> str:
        return (f"{len(self.added)} added, {len(self.removed)} removed or moved, "
                f"{len(self.readdressed)} re-addressed, {self.unchanged} unchanged")


def update_plan(previous: Project, previous_result: RunResult,
                project: Project, result: RunResult) -> UpdatePlan:
    old = {_key(r.element_id): r for r in previous_result.params}
    new = {_key(r.element_id): r for r in result.params}
    removed = [r for k, r in old.items() if k not in new]
    readdressed = [new[k].element_id for k, r in old.items()
                   if k in new and r.driver_id != new[k].driver_id]
    old_groups = {g.name for g in previous.groups}
    new_groups = {g.name for g in project.groups}
    return UpdatePlan(
        previous_table=previous.table,
        added=[r.element_id for k, r in new.items() if k not in old],
        removed=[r.element_id for r in removed],
        readdressed=readdressed,
        unchanged=sum(1 for k in new if k in old) - len(readdressed),
        groups_gone=sorted(old_groups - new_groups),
        removed_rows=[(r.element_id, r.driver_id, r.alias_text) for r in removed],
        units=list(dict.fromkeys(_unit_ids(previous) + _unit_ids(project))))


def update_bound_sql(plan: UpdatePlan, table: str) -> list[str]:
    """The bound rows of the removed and re-addressed points, on every unit of the list."""
    ids = plan.removed + plan.readdressed
    head = [f"-- Update from the previous version: {plan.summary()}.",
            "-- Rows the previous version has and this one has not are deleted from every",
            "-- unit on the table; re-addressed points are unbound so they bind to their new",
            "-- register. Points both versions have keep their settings on the plant."]
    if plan.previous_table != table:
        head.append(f"-- The previous version wrote table {plan.previous_table}: its own "
                    "tables are left as they are.")
    if not ids:
        return head + ["-- Nothing to delete."]
    tables = [table] + ([plan.previous_table] if plan.previous_table != table else [])
    by_group = ("`unit_id` IN (SELECT `unit_id` FROM `iw_sys_plant_units` WHERE `grp_name` IN ("
                + ", ".join(q(t) for t in tables) + "))")
    where = ([f"WHERE (`unit_id` IN ({', '.join(q(u) for u in plan.units)})", f"   OR {by_group})"]
             if plan.units else [f"WHERE {by_group}"])
    listing = _in_list(ids)
    listing[-1] += ";"
    return head + ["DELETE FROM `iw_gen_driver_parameters`", *where,
                   "  AND `element_id` IN " + listing[0], *listing[1:]]


def update_group_sql(plan: UpdatePlan, table: str) -> list[str]:
    """The removed points' group rows and the gone groups' alias rows (legacy; modern
    folds them into group_cleanup_sql)."""
    clauses = []
    if plan.removed:
        listing = _in_list(plan.removed)
        clauses.append(["(`type` = 'group' AND `value` IN " + listing[0], *listing[1:-1],
                        listing[-1] + ")"] if len(listing) > 1
                       else ["(`type` = 'group' AND `value` IN " + listing[0] + ")"])
    if plan.groups_gone:
        clauses.append(["(`type` = 'group_alias' AND `ref` IN ("
                        + ", ".join(q(g) for g in plan.groups_gone) + "))"])
    if not clauses:
        return []
    out = [f"DELETE FROM `iw_par_{table}_groups` WHERE " + clauses[0][0], *clauses[0][1:]]
    for c in clauses[1:]:
        out += ["  OR " + c[0], *c[1:]]
    out[-1] += ";"
    return out


def update_table_sql(plan: UpdatePlan, table_name: str) -> list[str]:
    """The removed points' rows in one template table (param or set)."""
    if not plan.removed:
        return []
    listing = _in_list(plan.removed)
    listing[-1] += ";"
    return [f"DELETE FROM `{table_name}` WHERE `element_id` IN " + listing[0], *listing[1:]]


def verify_sql(project: Project, result: RunResult, schema: str = "") -> str:
    """Read-only checks to paste into the plant's SQL tool after the import.

    Every statement is a SELECT. Each lists problems, so an empty result is a pass;
    the first shows the bound count per unit against what this list expects. They are
    docs/16 section 16.6.2's diagnostics, filled in with this list's table, element_ids
    and units instead of placeholders, plus the leftovers those could not see (2026-10-23).
    """
    t = project.table
    pre = f"`{schema}`." if schema else ""
    ids = [r.element_id for r in result.params]
    units = _unit_ids(project)
    on_table = f"u.`grp_name` = {q(t)}" + (
        f" OR u.`unit_id` IN ({', '.join(q(u) for u in units)})" if units else "")
    in_ids = _in_list(ids, indent="      ")

    def block(title: str, *sql: str) -> list[str]:
        return ["", f"-- {title}", *sql]

    def with_ids(prefix: str, suffix: str = "") -> list[str]:
        first, *rest = in_ids
        if not rest:
            return [prefix + first + suffix]
        return [prefix + first, *rest[:-1], rest[-1] + suffix]

    lines = [f"-- modbusgen verification for table {t}: {len(ids)} parameter rows, so "
             f"{len(ids) + 2} bound rows per unit with com_stat and com_error.",
             "-- Paste it into the plant's SQL tool after the import and Generate "
             "Param/Grp/Set. Every statement is a SELECT and changes nothing.",
             "-- Each query lists problems - an empty result is a pass - except 1, which "
             "shows the count per unit.",
             "-- If the tool answers \"No database selected\", run USE iw_plant_server3; first."]
    lines += block(f"1. Units on {t}: bound rows from this list (expected {len(ids)})",
                   "SELECT u.`unit_id`, u.`unit_name`,",
                   *with_ids("       SUM(g.`element_id` IN ", ") AS `from_this_list`,"),
                   f"       {len(ids)} AS `expected`, COUNT(g.`element_id`) AS `all_bound`",
                   f"FROM {pre}`iw_sys_plant_units` u",
                   f"LEFT JOIN {pre}`iw_gen_driver_parameters` g ON g.`unit_id` = u.`unit_id`",
                   f"WHERE {on_table}",
                   "GROUP BY u.`unit_id`, u.`unit_name`;")
    lines += block("2. Bound rows this list does not have - left by an earlier version, "
                   "still polled",
                   "SELECT g.`unit_id`, g.`element_id`, g.`driver_id`, g.`alias_text`",
                   f"FROM {pre}`iw_gen_driver_parameters` g",
                   f"JOIN {pre}`iw_sys_plant_units` u ON u.`unit_id` = g.`unit_id`",
                   f"WHERE ({on_table})",
                   "  AND g.`element_id` NOT IN ('com_stat', 'com_error')",
                   *with_ids("  AND g.`element_id` NOT IN ", ";"))
    lines += block("3. This list's rows that a unit has not bound - the parameter build "
                   "has not run, or an older row holds the register",
                   "SELECT u.`unit_id`, p.`element_id`, p.`driver_id`, p.`alias_text`",
                   f"FROM {pre}`iw_sys_plant_units` u",
                   f"CROSS JOIN {pre}`iw_par_{t}_param` p",
                   f"LEFT JOIN {pre}`iw_gen_driver_parameters` g",
                   "  ON g.`unit_id` = u.`unit_id` AND g.`element_id` = p.`element_id`",
                   f"WHERE ({on_table}) AND g.`element_id` IS NULL",
                   *with_ids("  AND p.`element_id` IN ", ";"))
    lines += block("4. Template rows this list does not have",
                   f"SELECT `element_id`, `driver_id`, `alias_text` FROM {pre}`iw_par_{t}_param`",
                   *with_ids("WHERE `element_id` NOT IN ", ";"))
    lines += block("5. Two template rows for one register",
                   "SELECT `driver_id`, COUNT(*) AS `n`, GROUP_CONCAT(`element_id`) AS `element_ids`",
                   f"FROM {pre}`iw_par_{t}_param` GROUP BY `driver_id` HAVING COUNT(*) > 1;")
    lines += block("6. Setting rows this list does not have",
                   f"SELECT `element_id` FROM {pre}`iw_set_{t}`",
                   *with_ids("WHERE `element_id` NOT IN ", ";"))
    lines += block("7. A point in its group more than once - an old position row",
                   "SELECT `ref` AS `group_name`, `value` AS `element_id`, COUNT(*) AS `n`",
                   f"FROM {pre}`iw_par_{t}_groups` WHERE `type` = 'group'",
                   "GROUP BY `ref`, `value` HAVING COUNT(*) > 1;")
    if units:
        lines += block("8. Units this script writes that sit on another table",
                       f"SELECT `unit_id`, `grp_name` FROM {pre}`iw_sys_plant_units`",
                       f"WHERE `unit_id` IN ({', '.join(q(u) for u in units)}) "
                       f"AND `grp_name` <> {q(t)};")
    return "\r\n".join(lines) + "\r\n"


def verify_filename(project: Project) -> str:
    return f"modbusgen-{project.plant}-{project.table}-verify.sql"


def render_sql(project: Project, result: RunResult, plan: UpdatePlan | None = None) -> str:
    """The import script. With `plan` (update_plan against the previous version), it also
    deletes the rows that version had and this one has not."""
    if project.options.sql_format == "legacy":
        return render_sql_legacy(project, result, plan)
    return render_sql_modern(project, result, plan)


def render_sql_legacy(project: Project, result: RunResult,
                      plan: UpdatePlan | None = None) -> str:
    t = project.table
    o = project.options
    lines: list[str] = []
    add = lines.append

    if project.system and project.system.units:
        s = project.system
        u = s.effective_units()[0]           # the legacy tool emitted a single unit
        addr = f"{s.driver_addr_prefix}{u.driver_addr}"
        add("-- iw_sys_plant_units")
        add("INSERT INTO `iw_sys_plant_units` (`row_date`, `active`, `blockout`, "
            "`unit_id`, `unit_name`, `grp_name`, `driver_type`, `driver_addr`, "
            "`regulator_type`, `order_no`, `view_order`, `driver_adr_extra`) VALUES")
        add(f"(NOW() ,  '1',  '0',  {q(u.unit_id)},  {q(u.unit_name)},  {q(t)},  "
            f"{q(s.owner)},  {q(addr)},  {q(s.reg_type)},  {q(s.order_no)},  '0',  '');")
        add("--")
        add("-- iw_sys_plant_orderno")
        add(f"INSERT INTO `iw_sys_order_no` (`row_date`, `order_no`, `db_link`, "
            f"`group_link`) VALUES (NOW(), {q(s.order_no)}, {q(t + '_param')}, "
            f"{q(t + '_groups')});")
        add("--")

    if project.system and project.system.settings:
        s = project.system
        c = s.comm
        add("-- iw_sys_processes")
        add("INSERT INTO `iw_sys_processes` (`row_date`, `man_start`, `path`, "
            f"`process_name`, `process_id`, `process_status`) VALUES (NOW(), '0', "
            f"'iw_mb.exe', {q(s.owner)}, '', '');")
        add("--")
        add("-- iw_sys_plant_settings")
        add("INSERT INTO `iw_sys_plant_settings` (`row_date`, `setting`, `owner`, "
            "`value`, `eng_unit`, `help_text`, `help_link`) VALUES")

        def setting(name, value, eng_unit="", help_text="", last=False, escape_tail=""):
            # escape_tail goes inside the quotes as written: the Excel tool's server line
            # ends in the escape sequence \r\n, which q() would otherwise double
            end = ";" if last else ","
            add(f"(NOW(), {q(name)}, {q(s.owner)}, {q(value)[:-1]}{escape_tail}', "
                f"{q(eng_unit)}, {q(help_text)}, ''){end}")

        setting("comm_port", c.com_port)
        setting("mb_tcp_servers", f"1;{c.ip};{c.port};1000;2;1000", "",
                "ID;IPadr;IPport;ConnTout;ConnRetries;RequestTout", escape_tail="\\r\\n")
        setting("mb_mode", "0" if c.mode == "rtu" else "2", "", "0=RTU|1=ASCII|2=TCP")
        for name, value, eng_unit, help_text in FIXED_SETTINGS:
            setting(name, value, eng_unit, help_text)
        setting("comm_parity", c.parity, "", "0=N|1=O|2=E|3=M|4=S")
        setting("comm_data_bits", str(c.data_bits))
        # DIVERGENCE: Excel always writes stop bits '1' (docs/08 item 20)
        setting("comm_stop_bits", str(c.stop_bits))
        setting("comm_baudrate", str(c.baudrate))
        for i, (name, value, eng_unit, help_text) in enumerate(FIXED_SETTINGS_TAIL):
            setting(name, value, eng_unit, help_text,
                    last=(i == len(FIXED_SETTINGS_TAIL) - 1))

    if o.replace_list:
        add("--")
        lines.extend(replace_list_sql(t, _unit_ids(project)))
    elif plan is not None:
        add("--")
        lines.extend(update_bound_sql(plan, t))
        if not o.truncates:
            lines.extend(update_table_sql(plan, f"iw_par_{t}_param"))
            lines.extend(update_table_sql(plan, f"iw_set_{t}"))
            lines.extend(update_group_sql(plan, t))
    add("--")
    add("-- Group")
    add("--")
    if o.create_tables:
        add(CREATE_GROUPS.format(t=t))
        add("--")
    if o.truncates:
        add(f"TRUNCATE TABLE iw_par_{t}_groups;")
        add("--")
    for rec in result.group_aliases:
        add(f"INSERT INTO `iw_par_{t}_groups` VALUES " + _values(rec))
    for rec in result.groups:
        add(f"INSERT INTO `iw_par_{t}_groups` VALUES " + _values(rec))

    add("--")
    add("-- Param")
    add("--")
    if o.create_tables:
        add(CREATE_PARAM.format(t=t))
        add("--")
    if o.truncates:
        add(f"TRUNCATE TABLE iw_par_{t}_param;")
        add("--")
    for rec in result.params:
        add(f"INSERT INTO `iw_par_{t}_param` VALUES " + _values(rec))

    add("--")
    add("-- Set")
    add("--")
    if o.create_tables:
        add(CREATE_SET.format(t=t))
        add("--")
    if o.truncates:
        add(f"TRUNCATE TABLE iw_set_{t};")
        add("--")
    for rec in result.sets:
        add(f"INSERT INTO `iw_set_{t}` VALUES " + _values(rec))

    return "\r\n".join(lines) + "\r\n"


def default_filename(project: Project) -> str:
    return f"modbusgen-{project.plant}-{project.table}-SQL File.txt"


# ---------------------------------------------------------------------------
# Modern house style ("REPLACE INTO", schema 4.3.4) - modelled on the 2026
# reference export CarloGavazzi_EM270-v2.sql. Idempotent re-import: REPLACE
# INTO instead of TRUNCATE+INSERT, CREATE TABLE IF NOT EXISTS always emitted,
# iw_sys_* blocks at the end.
# ---------------------------------------------------------------------------

CREATE_GROUPS_MODERN = """CREATE TABLE IF NOT EXISTS `iw_par_{t}_groups` (
  `row_date` datetime NOT NULL DEFAULT '2021-01-01 00:00:00',
  `type` varchar(50) NOT NULL DEFAULT '',
  `view_order` mediumint(6) NOT NULL DEFAULT '0',
  `ref` varchar(100) NOT NULL DEFAULT '',
  `value` varchar(200) NOT NULL DEFAULT '',
  UNIQUE KEY `type` (`type`,`view_order`,`ref`,`value`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='4.3.4';"""

CREATE_PARAM_MODERN = """CREATE TABLE IF NOT EXISTS `iw_par_{t}_param` (
  `row_date` datetime NOT NULL DEFAULT '2021-01-01 00:00:00',
  `element_id` varchar(100) NOT NULL DEFAULT '',
  `driver_id` varchar(100) NOT NULL DEFAULT '',
  `alias_text` text NOT NULL,
  `menu` varchar(10) NOT NULL DEFAULT '',
  `application` text NOT NULL,
  `parameter_type` text NOT NULL,
  `factory_setting` text NOT NULL,
  `grp` text NOT NULL,
  `att` text NOT NULL,
  `eng_unit` varchar(20) NOT NULL DEFAULT '',
  `format` varchar(20) NOT NULL DEFAULT '',
  `range_min` text NOT NULL,
  `range_max` text NOT NULL,
  `scale` varchar(15) NOT NULL DEFAULT '',
  `raw_min` varchar(15) NOT NULL DEFAULT '',
  `raw_max` varchar(15) NOT NULL DEFAULT '',
  `eng_min` varchar(15) NOT NULL DEFAULT '',
  `eng_max` varchar(15) NOT NULL DEFAULT '',
  `driver_id_extra` varchar(255) NOT NULL DEFAULT '',
  `format_extra` text NOT NULL,
  UNIQUE KEY `element_id` (`element_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='4.3.4';"""

CREATE_SET_MODERN = """CREATE TABLE IF NOT EXISTS `iw_set_{t}` (
  `row_date` datetime NOT NULL DEFAULT '2021-01-01 00:00:00',
  `element_id` varchar(100) NOT NULL DEFAULT '',
  `active` enum('0','1') NOT NULL DEFAULT '0',
  `onl_ind` enum('0','1') NOT NULL DEFAULT '1',
  `update_freq` set('','fast','norm','slow','once','never') NOT NULL DEFAULT 'norm',
  `save_data` varchar(20) NOT NULL DEFAULT 'change',
  `save_freq` varchar(20) NOT NULL DEFAULT '',
  `plant_pri` char(1) NOT NULL DEFAULT '',
  `sys_pri` char(1) NOT NULL DEFAULT '',
  `alarm_type` tinyint(3) NOT NULL DEFAULT '0',
  PRIMARY KEY (`element_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='4.3.4';"""

GROUP_COLS_M = "(`row_date`, `type`, `view_order`, `ref`, `value`)"
PARAM_COLS_M = ("(`row_date`, `element_id`, `driver_id`, `alias_text`, `menu`, "
                "`application`, `parameter_type`, `factory_setting`, `grp`, `att`, "
                "`eng_unit`, `format`, `range_min`, `range_max`, `scale`, `raw_min`, "
                "`raw_max`, `eng_min`, `eng_max`, `driver_id_extra`, `format_extra`)")
SET_COLS_M = ("(`row_date`, `element_id`, `active`, `onl_ind`, `update_freq`, "
              "`save_data`, `save_freq`, `plant_pri`, `sys_pri`, `alarm_type`)")

PARITY_NUM = {"none": "0", "odd": "1", "even": "2"}

# (setting, fixed-value-or-None-for-dynamic, eng_unit, help_text) in EM270 order
MODERN_SETTINGS = [
    ("comm_port", None, "", ""),
    ("comm_parity", None, "", "0=N|1=O|2=E|3=M|4=S"),
    ("comm_data_bits", None, "", ""),
    ("comm_stop_bits", None, "", ""),
    ("comm_baudrate", None, "", ""),
    ("mb_mode", None, "", "0=RTU|1=ASCII|2=TCP"),
    ("force_word_not_byte", "0", "", "0|1"),
    ("handshake", "0", "", "0|1|2"),
    ("check_rate", "1", "ms", ""),
    ("max_outstanding_packets", "-1", "", ""),
    ("packet_timeout", "1", "sec.", ""),
    ("idle_event_rate", "250", "msec.", ""),
    ("sql_queue_poll_time", "2000", "msec.", ""),
    ("max_error_count", "2", "", ""),
    ("mb_request_timeout", "1000", "ms", ""),
    ("mb_request_retries", "2", "", ""),
    ("com_error_alarm_delay", "10", "min.", ""),
    ("show_queue_info", "0", "", ""),
    ("speed_index_block", "10", "", ""),
    ("speed_index_offline", "10", "", ""),
    ("speed_index_slow", "1", "", ""),
    ("speed_index_norm", "1", "", ""),
    ("max_param_block_time", "2", "hours", ""),
    ("max_group_count", "1", "", ""),
    ("value_quality_check_limit", "0", "", "0 = disabled"),
    ("mb_tcp_servers", None, "", "ID;IPadr;IPport;ConnTout;ConnRetries;RequestTout"),
    ("mux_settle_time", "1500", "ms",
     "Time for the muxed input to settle. The value shuld be a multiple off 100."),
    ("startup_delay", "15", "Sec.", ""),
    ("allow_crc_swap", "0", "", "Default 0"),
    ("enablers485mode", "0", "", "0=OFF|0 < delay in ms and ON"),
    ("alarm_handler", "", "", ""),
]


def _mrow(values, last=False) -> str:
    """One VALUES row, EM270 style: quoted strings, bare ints, ', ' separators."""
    parts = [str(v) if isinstance(v, int) else q(v) for v in values]
    return "(" + ", ".join(parts) + (");" if last else "),")


def _mblock(lines, header, rows):
    # No rows, no statement: a bare "REPLACE INTO ... VALUES" is a syntax error, and with
    # truncate or replace_list on it failed after the tables had already been emptied
    if not rows:
        return
    lines.append(header + " VALUES")
    for i, row in enumerate(rows):
        lines.append(_mrow(row, last=(i == len(rows) - 1)))


def render_sql_modern(project: Project, result: RunResult,
                      plan: UpdatePlan | None = None) -> str:
    t = project.table
    ts = result.params[0].row_date if result.params else \
        (result.group_aliases[0].row_date if result.group_aliases else "")
    lines: list[str] = []
    add = lines.append

    add('SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";')
    add("")
    add("-- If duplicates: The parameter list (_group, _param and set_) is from the "
        "first/top 'selected rows'")
    add("")
    add("")

    if project.options.replace_list:
        lines.extend(replace_list_sql(t, _unit_ids(project)))
        add("")
        add("")
    elif plan is not None:
        lines.extend(update_bound_sql(plan, t))
        add("")
        add("")

    add(CREATE_GROUPS_MODERN.format(t=t))
    add("")
    if project.options.truncates:
        add(f"TRUNCATE TABLE `iw_par_{t}_groups`;")
        add("")
    else:
        gone_ids = plan.removed if plan is not None else []
        gone_groups = plan.groups_gone if plan is not None else []
        lines.extend(group_cleanup_sql(
            t, [r.ref for r in result.group_aliases if r.type == "group_alias"]
            + gone_groups,
            list(dict.fromkeys([r.value for r in result.groups] + gone_ids))))
        add("")
    group_rows = [(ts, "default_link", 2, "", "")]
    for rec in result.group_aliases:
        if rec.type == "group_alias":
            group_rows.append((ts, "group_alias", int(rec.view_order), rec.ref,
                               rec.value))
    for rec in result.groups:
        group_rows.append((ts, "group", int(rec.view_order), rec.ref, rec.value))
    _mblock(lines, f"REPLACE INTO `iw_par_{t}_groups` {GROUP_COLS_M}", group_rows)
    add("")
    add("")

    add(CREATE_PARAM_MODERN.format(t=t))
    add("")
    if project.options.truncates:
        add(f"TRUNCATE TABLE `iw_par_{t}_param`;")
        add("")
    elif plan is not None and plan.removed:
        lines.extend(update_table_sql(plan, f"iw_par_{t}_param"))
        add("")
    _mblock(lines, f"REPLACE INTO `iw_par_{t}_param` {PARAM_COLS_M}",
            [tuple(astuple(rec)) for rec in result.params])
    add("")
    add("")

    add(CREATE_SET_MODERN.format(t=t))
    add("")
    if project.options.truncates:
        add(f"TRUNCATE TABLE `iw_set_{t}`;")
        add("")
    elif plan is not None and plan.removed:
        lines.extend(update_table_sql(plan, f"iw_set_{t}"))
        add("")
    set_rows = []
    for rec in result.sets:
        vals = list(astuple(rec))
        vals[-1] = int(vals[-1])            # alarm_type bare, as in the reference
        set_rows.append(tuple(vals))
    _mblock(lines, f"REPLACE INTO `iw_set_{t}` {SET_COLS_M}", set_rows)

    s = project.system
    if s and (s.units or s.settings):
        add("")
        add("")
    if s and s.units:
        add("-- Watch out for duplicate unit_id!")
        add("")
        _mblock(lines, "REPLACE INTO `iw_sys_plant_units` (`row_date`, `active`, "
                "`blockout`, `unit_id`, `unit_name`, `grp_name`, `driver_type`, "
                "`driver_addr`, `regulator_type`, `order_no`, `view_order`, "
                "`driver_adr_extra`, `unit_extra`)",
                [(ts, "1", "0", u.unit_id, u.unit_name, t, s.owner,
                  f"{s.driver_addr_prefix}{u.driver_addr}", s.reg_type, s.order_no,
                  int(u.view_order), "", "")
                 for u in s.effective_units()])
        add("")
        _mblock(lines, "REPLACE INTO `iw_sys_order_no` (`row_date`, `order_no`, "
                "`db_link`, `group_link`)",
                [(ts, s.order_no, f"{t}_param", f"{t}_groups")])
        add("")
    if s and s.settings:
        _mblock(lines, "REPLACE INTO `iw_sys_processes` (`row_date`, `man_start`, "
                "`path`, `process_name`, `process_id`, `process_status`)",
                [(ts, "0", "iw_mb.exe", s.owner, "", "")])
        add("")
        add("-- If duplicates: The iw_sys_plant_settings is from the first/top "
            "'selected rows'")
        add("")
        c = s.comm
        dynamic = {
            "comm_port": str(c.com_port),
            "comm_parity": PARITY_NUM.get(str(c.parity).lower(), str(c.parity)),
            "comm_data_bits": str(c.data_bits),
            "comm_stop_bits": str(c.stop_bits),
            "comm_baudrate": str(c.baudrate),
            "mb_mode": "0" if c.mode == "rtu" else "2",
            "mb_tcp_servers": f"1;{c.ip or 'XXX.XXX.XXX.XXX'};{c.port};1000;2;1000",
        }
        rows = [(ts, name, s.owner,
                 dynamic[name] if fixed is None else fixed, eng, help_, "")
                for name, fixed, eng, help_ in MODERN_SETTINGS]
        _mblock(lines, "REPLACE INTO `iw_sys_plant_settings` (`row_date`, `setting`, "
                "`owner`, `value`, `eng_unit`, `help_text`, `help_link`)", rows)

    return "\r\n".join(lines) + "\r\n"
