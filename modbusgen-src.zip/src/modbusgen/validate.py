"""Pre-generation validation: the checklist of docs/06-validation-and-checks.md 6.5,
turned into hard gates.

A finding says four things, and each is used by somebody different. The **message** is
the diagnosis, and is what `validate()` has always returned. The **code** is a stable
key: the GUI hangs its one-click repairs off it, so rewording a message can no longer
silently detach its fix. The **advice** is what to do about it, which until 2026-08-26
existed only in the page - the CLI printed rules and no remedies, which is a poor deal
for a person and a useless one for an agent. And the **suggestion** is a near key from
the same table, because the most expensive datatype error on record (`I_Hold_U16R_N`
across 50 points, docs/11) was a transposition that any spell-check would have caught.

Every finding about a point carries that point's index *and its address*. The index
counts rows after motherword synthesis, so it can name a row the author never wrote;
the address is in the file they are editing.
"""
from __future__ import annotations

import difflib
import re
from dataclasses import dataclass

from .model import Project
from .rules import att, driver_id
from .tables import Tables

VALID_RW = {"r", "rw", "vr", "vrw"}
VALID_ALARM = {"A", "B", "C", "N"}

# system.owner becomes driver_type in iw_sys_plant_units. IWMAC documents these two
# limits (docs/16); both are warnings rather than gates, because the fleet contradicts
# them and this repository cannot settle which side is right.
OWNER_MAX = 10
OWNER_CHARS = re.compile(r"[A-Z0-9]+")

# A datatype key travels into Work column D, a CSV column and a VLOOKUP, and has to
# stay one unambiguous token in an error message and in the GUI's dropdown.
DATATYPE_NAME = re.compile(r"[A-Za-z0-9_]+")
DATATYPE_FIELDS = ("read_func", "write_func", "raw_type", "read_swap", "write_swap",
                   "application", "parameter_type", "rw_hint", "default_group")

# How many bits the word a motherword polls actually yields, by its raw datatype.
# A bit row extracts its bit from that word (docs/06 section 6.3), so this is the
# ceiling on what the row can address.
WORD_BITS = {"I16": 16, "U16": 16, "I32": 32, "U32": 32, "F": 32, "D": 64,
             # driver types added 2026-08-20; width is the registers the driver reads
             "I64I32": 64, "U64U32": 64, "CLK": 16, "STR4": 32, "STR8": 64,
             "BCD35": 16, "BCD4": 32, "rU16": 16, "rI16": 16}


@dataclass(frozen=True)
class Finding:
    """One validation failure, in the four forms its readers need."""
    code: str                       # stable key; the GUI's repairs hang off this
    message: str                    # the diagnosis, as validate() has always phrased it
    advice: str                     # what to do about it
    point: int | None = None        # 1-based index, counted after motherword synthesis
    addr: int | None = None         # the register, which is in the file being edited
    suggestion: str | None = None   # a near key from the same table, when one exists
    # A warning is usually about a set of rows rather than one, and reports the whole
    # set: the prose used to stop at eight and put the rest beyond reach. Kept as
    # numbers rather than one finding per row, because 1 600 blank alias texts is a
    # real list and 1 600 findings is not a payload anybody wants.
    points: tuple[int, ...] = ()
    addrs: tuple[int, ...] = ()

    def as_dict(self) -> dict:
        return {"code": self.code, "message": self.message, "advice": self.advice,
                "point": self.point, "addr": self.addr, "suggestion": self.suggestion,
                "points": list(self.points), "addrs": list(self.addrs)}


# One entry per code. A code with no advice is a rule stated without a remedy, which is
# the state this table exists to end; a test asserts every code used below appears here.
ADVICE = {
    "datatype-missing":
        "Choose a datatype. It supplies the read and write function codes, so nothing "
        "else about the row can be derived until it is set.",
    "datatype-unknown":
        "That datatype key does not exist. Pick one from the table, or - if the "
        "register genuinely needs a combination no shipped key describes - define it in "
        "the project's own `datatypes` block (docs/02) rather than inventing a "
        "spelling.",
    "datatype-name-illegal":
        "Rename the variable using letters, digits and underscore only. The key travels "
        "into Work column D, a CSV column and a VLOOKUP, and a space or a slash breaks "
        "one of the three.",
    "datatype-name-case-duplicate":
        "Rename one of the two. Datatype lookups fold case, here and in Excel, so two "
        "names differing only in case are one name with two definitions.",
    "datatype-redefines-shipped":
        "Rename the variable. The shipped table wins: Excel's VLOOKUP takes the first "
        "match, so a project row of the same name would never take effect - it would "
        "only make one name mean two things in two files.",
    "group-missing":
        "Give the row a group, or switch on options.auto_groups to fill it from the "
        "datatype's default group.",
    "group-unknown":
        "Define that group in the project's `groups` block. The standard set is "
        "aio/dio/alm/misc/sch; a converted workbook keeps its own section headings "
        "instead (docs/11).",
    "addr-invalid":
        "Enter the register number exactly as the documentation prints it, digits only, "
        "with any 4xxxx/3xxxxx prefix stripped.",
    "addr-underflow":
        "Address 0 cannot have 1 subtracted from it. Either the documentation is already "
        "0-based - turn options.subtract_one off - or the address is wrong.",
    "bit-invalid":
        "Bit must be 0-31, or the nibble form start#length such as 5#4.",
    "bit-needs-register":
        "Bits live inside a register: use Bit_Hold or Bit_Input. Coils and discrete "
        "inputs are already single bits, so they take no bit number.",
    "rw-invalid":
        "Use r for read-only or rw for writable. vr and vrw are applied automatically to "
        "bit rows - you do not author them.",
    "rw-not-writable":
        "The datatype table marks that register read-only. Set rw back to r, or choose a "
        "datatype that has a write function - and check docs/15 first, because a 32-bit "
        "write needs function 16 and the modbus.php driver cannot do it at all.",
    "alarm-invalid":
        "The alarm letter must be A, B, C or N. Leave it blank for a point that raises "
        "no alarm.",
    "unit-unknown":
        "Pick a unit from data/tables/units.csv, or add it there so every future list can "
        "use it too. An unmatched unit means an omitted field, never an invented "
        "spelling.",
    "scale-unknown":
        "Pick a scale from data/tables/scaling.csv, or add it there. x0.1 covers most of "
        "the real fleet; if the document needs a factor the table lacks, omit scale, "
        "keep the point and say so.",
    "decimals-range":
        "Decimals must be 0, 1, 2 or 3 - or blank to leave the display format empty.",
    "statetext-unknown":
        "Add a list with that id to `statetexts`, or clear the statetext field on the "
        "row.",
    "update-freq-invalid":
        "Leave update_freq unset to let it be derived, or choose fast, norm, slow, once "
        "or never.",
    "driver-id-duplicate":
        "Two rows poll the same register and bit, which is one address twice. Change one "
        "of the addresses, or delete the copy. Applying one address across several rows "
        "in a bulk edit causes this.",
    "element-id-duplicate":
        "Two rows resolve to the same key. Change the group or the address on one of "
        "them, or give one an explicit element_id.",
    "motherword-not-read-only":
        "Set that row's rw to r. A motherword exists to poll the word its bits live in; "
        "it is never written.",
    "motherword-missing":
        "Switch on options.auto_motherwords to have it created, or add a row at the same "
        "address with no bit.",
    "bit-outside-motherword":
        "The motherword the tool synthesizes is 16-bit, and it is never widened because "
        "a 32-bit one would have to guess the word order. Either author the word itself "
        "as an explicit 32-bit point at that address - that choice of _N or _W is what "
        "makes the high bits addressable - or move the bit to the register actually "
        "holding the high word.",
    "online-missing":
        "Mark three or four reliable, frequently changing read points online: true - an "
        "outdoor temperature or an energy counter. IWMAC uses them to tell that the unit "
        "is alive, so a point that rarely changes is a poor choice.",
    "group-order-clash":
        "Give each group its own view order; two groups cannot sit at the same position.",

    # Soft checks. These never stop a list, which is exactly why each one has to say
    # what it costs to ignore - a warning nobody can act on is noise, and noise is what
    # gets a real warning ignored later.
    "alias-text-missing":
        "Give each row an alias text: it is the only name the operator ever sees, so a "
        "blank one ships a nameless line in the IWMAC menu. The Excel tool tolerated "
        "this and real lists carry it, which is why it does not block - but it is a "
        "delivery defect, not a style choice.",
    "motherword-absent":
        "A bit row reads its bit out of a word somebody has to poll. Leave "
        "options.auto_motherwords on and the word row is synthesized for you; switch it "
        "off and you must author a row at the same address with no bit, or the bits "
        "read nothing.",
    "project-datatype-also-shipped":
        "Nothing to do. The row matches the shared table exactly, which is what a "
        "promoted datatype looks like and what a project opened on a machine that "
        "already has the row looks like. Delete it from the project only if you are "
        "sure every machine that opens this file has the shared row.",
    "project-datatype-unknown-value":
        "Check that field against docs/15 before shipping. Every other datatype in the "
        "table uses a value the driver is known to accept; this one does not, so "
        "nothing here can tell you whether the driver will understand it. The GUI "
        "cannot create such a row - it came from an import or was hand-edited.",
    "project-datatype-unused":
        "Delete the definition, or point a row at it. An unused datatype is harmless in "
        "the file and misleading to the next reader, who will assume some point needs "
        "it.",
    "owner-too-long":
        "Check what actually arrived in iw_sys_plant_units before shipping. IWMAC "
        "documents 10 characters for driver_type, and a real delivery carries 11 - so "
        "either the limit is not 10 or that delivery was truncated somewhere without "
        "anyone noticing. Shorten it if the plant database shows truncation.",
    "owner-charset":
        "Check it against the plant database. IWMAC documents capitals and digits for "
        "driver_type; the fleet also carries lowercase owners, so this is unconfirmed "
        "rather than certainly wrong.",
}

# The swap suffix drifting into the raw type - `I_Hold_U16R_N` for `I_Hold_U16_R` - is
# not a typo a fuzzy match ranks first: difflib puts three wrong keys ahead of the right
# one. It is also the single most expensive datatype error on record (docs/11), so it
# gets a rule of its own before the general search.
_FUSED_SWAP = re.compile(r"(.+?)([NRW])_([NRW])")


def _suggest(bad: str, pool) -> str | None:
    """A key from `pool` the author probably meant, or None.

    Deliberately conservative: one suggestion, not a list. A wrong suggestion that
    looks confident is worse than none, because the fix is a register-level decision
    and the reader is being asked to check it, not to accept it.
    """
    if not bad:
        return None
    fused = _FUSED_SWAP.fullmatch(bad)
    if fused:
        moved = f"{fused.group(1)}_{fused.group(2)}"
        if moved in pool:
            return moved
    names = list(pool)
    hit = difflib.get_close_matches(bad, names, n=1, cutoff=0.6)
    if hit:
        return hit[0]
    folded = {n.casefold(): n for n in names}       # lookups fold case; spelling may not
    return folded.get(bad.casefold())


def _top_bit(bit: int | str) -> int | None:
    """Highest bit index an authored bit value touches ('5#4' = bits 5..8).

    None when the value is not a well-formed bit - the range check below already
    reports those, and one row should not collect two errors for one mistake.
    """
    if isinstance(bit, int):
        return bit if 0 <= bit <= 31 else None
    m = re.fullmatch(r"(\d+)#(\d+)", bit) if isinstance(bit, str) else None
    if m is None:
        return None
    return int(m.group(1)) + max(int(m.group(2)), 1) - 1


def _finding(code: str, message: str, point: int | None = None,
             addr: int | None = None, suggestion: str | None = None,
             points: tuple[int, ...] = (), addrs: tuple[int, ...] = ()) -> Finding:
    return Finding(code=code, message=message, advice=ADVICE[code], point=point,
                   addr=addr, suggestion=suggestion, points=points, addrs=addrs)


def _datatype_errors(project: Project) -> list[str]:
    """Rules on the project's own datatype rows that must stop generation.

    The shipped table is the authority: a project adds keys and never redefines one,
    because Excel's VLOOKUP takes the first match and modbusgen's _FoldDict is
    first-writer-wins. A redefinition would therefore not even take effect - it would
    only make one name mean two things across two files.
    """
    from .tables import default_tables

    found: list[Finding] = []
    shipped = default_tables().datatypes
    seen: dict[str, str] = {}
    for name, row in project.datatypes.items():
        where = f"datatypes.{name}"
        if not DATATYPE_NAME.fullmatch(name):
            found.append(_finding(
                "datatype-name-illegal",
                f"{where}: a datatype name takes letters, digits and underscore only"))
        first = seen.get(name.casefold())
        if first is not None:
            found.append(_finding(
                "datatype-name-case-duplicate",
                f"{where}: differs only in case from '{first}', and lookups fold case"))
        seen[name.casefold()] = name
        if name in shipped and any(getattr(row, f) != getattr(shipped[name], f)
                                   for f in DATATYPE_FIELDS):
            found.append(_finding(
                "datatype-redefines-shipped",
                f"{where}: already in data/tables/datatypes.csv with a different "
                f"definition, and a project must not redefine a shipped datatype - "
                f"rename this row"))
    return found


def validate(project: Project, tables: Tables) -> list[str]:
    """Run after auto-fill/synthesis. Returns a list of error strings; empty = valid.

    The messages only. Callers that can act on more - the CLI, the web API, the GUI -
    should use `validate_detailed`, which carries the code, the address, the advice and
    a suggestion alongside each message.
    """
    return [f.message for f in validate_detailed(project, tables)]


def validate_detailed(project: Project, tables: Tables) -> list[Finding]:
    """Run after auto-fill/synthesis. Returns findings; empty = valid."""
    errors: list[Finding] = _datatype_errors(project)
    o = project.options
    group_names = {g.name for g in project.groups}
    seen_driver: dict[str, int] = {}
    seen_element: dict[str, int] = {}
    online_count = 0
    mothers: set[tuple[str, int]] = set()
    mother_word: dict[tuple[str, int], tuple[int, str]] = {}   # -> (bits, datatype)
    bit_rows: list[tuple[int, str, str, int, int | str]] = []

    for i, p in enumerate(project.points, start=1):
        # the index counts synthesized rows and so can name one nobody wrote; the
        # address is in the file the author is editing, so it travels with every finding
        label = p.text or p.datatype or "unnamed"
        addr = p.addr if isinstance(p.addr, int) else None
        where = (f"point {i} ({label}, addr {p.addr})" if addr is not None
                 else f"point {i} ({label})")
        here = dict(point=i, addr=addr)

        # counted before the datatype guard below: `online` is a flag, not a decoding
        # question, and a row skipped for a bad datatype used to make the project look
        # as though nothing was marked at all - one mistake reported as two
        if p.online:
            online_count += 1

        dt = tables.datatypes.get(p.datatype)
        if not p.datatype:
            errors.append(_finding("datatype-missing", f"{where}: datatype missing",
                                   **here))
            continue
        if dt is None:
            near = _suggest(p.datatype, tables.datatypes)
            errors.append(_finding(
                "datatype-unknown",
                f"{where}: datatype '{p.datatype}' not in data/tables/datatypes.csv"
                + (f" - did you mean '{near}'?" if near else ""),
                suggestion=near, **here))
            continue

        if not p.group:
            errors.append(_finding("group-missing", f"{where}: group missing", **here))
        elif p.group not in group_names:
            near = _suggest(p.group, group_names)
            errors.append(_finding(
                "group-unknown",
                f"{where}: group '{p.group}' has no alias in 'groups'"
                + (f" - did you mean '{near}'?" if near else ""),
                suggestion=near, **here))

        if not isinstance(p.addr, int) or p.addr < 0:
            errors.append(_finding("addr-invalid",
                                   f"{where}: addr must be a non-negative integer",
                                   **here))
            continue
        if o.subtract_one and p.addr - 1 < 0:
            errors.append(_finding(
                "addr-underflow",
                f"{where}: addr {p.addr} with subtract_one would go below 0", **here))

        # 32-bit words (Danfoss alarm/status words etc.) address bits up to 31;
        # "5#4" is the legacy nibble syntax (start bit # length)
        if p.bit is not None and not (
                (isinstance(p.bit, int) and 0 <= p.bit <= 31)
                or (isinstance(p.bit, str) and re.fullmatch(r"\d+#\d+", p.bit))):
            errors.append(_finding(
                "bit-invalid",
                f"{where}: bit must be 0..31 or nibble syntax like '5#4'", **here))
        if p.bit is not None and dt.read_func not in ("3", "4"):
            errors.append(_finding(
                "bit-needs-register",
                f"{where}: bit addressing needs a register datatype "
                f"(read function 3/4), not '{p.datatype}'", **here))

        if p.rw not in VALID_RW:
            errors.append(_finding(
                "rw-invalid",
                f"{where}: rw must be one of {', '.join(sorted(VALID_RW))}", **here))
        # bit rows write through their word - no per-bit write function needed
        if p.rw in ("rw", "vrw") and dt.write_func == "" and p.bit is None:
            errors.append(_finding(
                "rw-not-writable",
                f"{where}: datatype '{p.datatype}' has no write function; "
                f"rw is impossible", **here))

        if p.alarm is not None and p.alarm not in VALID_ALARM:
            errors.append(_finding(
                "alarm-invalid",
                f"{where}: alarm must be one of {', '.join(sorted(VALID_ALARM))}",
                **here))

        if p.unit and p.unit not in tables.units:
            near = _suggest(p.unit, tables.units)
            errors.append(_finding(
                "unit-unknown",
                f"{where}: unit '{p.unit}' not in data/tables/units.csv"
                + (f" - did you mean '{near}'?" if near else ""),
                suggestion=near, **here))
        if p.scale and p.scale not in tables.scaling:
            near = _suggest(p.scale, tables.scaling)
            errors.append(_finding(
                "scale-unknown",
                f"{where}: scale '{p.scale}' not in data/tables/scaling.csv"
                + (f" - did you mean '{near}'?" if near else ""),
                suggestion=near, **here))

        if p.decimals is not None and p.decimals not in (0, 1, 2, 3):
            errors.append(_finding("decimals-range", f"{where}: decimals must be 0..3",
                                   **here))

        if p.statetext is not None and p.statetext not in project.statetexts:
            errors.append(_finding(
                "statetext-unknown",
                f"{where}: statetext {p.statetext} not defined in 'statetexts'", **here))

        if p.update_freq is not None and p.update_freq not in (
                "fast", "norm", "slow", "once", "never"):
            errors.append(_finding(
                "update-freq-invalid",
                f"{where}: update_freq must be fast/norm/slow/once/never", **here))


        did = driver_id(p, project, tables)
        eid = p.element_id if p.element_id else f"{p.group}_{did}"
        if did in seen_driver:
            errors.append(_finding(
                "driver-id-duplicate",
                f"{where}: duplicate driver_id '{did}' (also point "
                f"{seen_driver[did]})", **here))
        else:
            seen_driver[did] = i
        if eid in seen_element:
            errors.append(_finding(
                "element-id-duplicate",
                f"{where}: duplicate element_id '{eid}' (also point "
                f"{seen_element[eid]})", **here))
        else:
            seen_element[eid] = i

        if p.bit is None:           # any row polling the word counts (Excel semantics)
            key = (dt.read_func, p.addr)
            mothers.add(key)
            bits = WORD_BITS.get(dt.raw_type)
            if bits and bits > mother_word.get(key, (0, ""))[0]:
                mother_word[key] = (bits, p.datatype)
            if p.is_motherword and att(p) != "r":
                errors.append(_finding("motherword-not-read-only",
                                       f"{where}: motherword must be read-only (rw: r)",
                                       **here))
        if p.bit is not None:
            bit_rows.append((i, where, dt.read_func, p.addr, p.bit))

    if o.require_motherwords:
        for i, _where, rf, addr, _bit in bit_rows:
            if (rf, addr) not in mothers:
                errors.append(_finding(
                    "motherword-missing",
                    f"point {i}: bit value at addr {addr} has no motherword row "
                    f"(same address, no bit, text 'Motherword')", point=i, addr=addr))

    # A bit is extracted from the word its motherword polls, so it cannot reach past that
    # word's width - and synthesized motherwords are 16-bit by design (rules.py).
    for i, where, rf, addr, bit in bit_rows:
        top = _top_bit(bit)
        bits, mother_dt = mother_word.get((rf, addr), (0, ""))
        if top is None or not bits or top < bits:
            continue
        errors.append(_finding(
            "bit-outside-motherword",
            f"{where}: bit {bit} is outside the {bits}-bit motherword at addr "
            f"{addr} ('{mother_dt}' covers bits 0..{bits - 1}) - bits above it "
            f"live in the register holding the high word, and finding which "
            f"register that is means fixing the 32-bit word order, which "
            f"modbusgen never guesses (docs/15): address the bit in that "
            f"register, or author this word as an explicit 32-bit point",
            point=i, addr=addr))

    if online_count == 0 and project.points:
        errors.append(_finding(
            "online-missing",
            "no point has online: true - at least one online-indication "
            "point is required (docs/06 item 6)"))

    dup_orders = {}
    for g in project.groups:
        dup_orders.setdefault(g.order, []).append(g.name)
    for order, names in dup_orders.items():
        if len(names) > 1:
            errors.append(_finding("group-order-clash",
                                   f"groups {names} share view order {order}"))

    return errors


def _datatype_warnings(project: Project) -> list[str]:
    """Things worth saying about a project's own datatypes that must not stop a list.

    The vocabulary check is deliberately soft. The GUI offers dropdowns and cannot
    create an off-vocabulary row; a real delivery can contain one, and refusing to
    validate it would leave that list with no route through the tool at all.
    """
    from .tables import default_tables

    warnings: list[Finding] = []
    shipped = default_tables().datatypes
    vocabulary = {f: {getattr(dt, f) for dt in shipped.values()}
                  for f in DATATYPE_FIELDS}
    used = {p.datatype.casefold() for p in project.points if p.datatype}
    for name, row in project.datatypes.items():
        where = f"warning: datatypes.{name}"
        if name in shipped:
            warnings.append(_finding(
                "project-datatype-also-shipped",
                f"{where}: also in the shared table, with the same definition - "
                f"harmless, and what a promoted row looks like"))
        for f in DATATYPE_FIELDS:
            value = getattr(row, f)
            if value not in vocabulary[f]:
                warnings.append(_finding(
                    "project-datatype-unknown-value",
                    f"{where}: {f} '{value}' appears in no shipped datatype, so nothing "
                    f"here can say the driver supports it (docs/15)",
                    suggestion=_suggest(value, vocabulary[f])))
        if name.casefold() not in used:
            warnings.append(_finding("project-datatype-unused",
                                     f"{where}: defined, but no point uses it"))
    return warnings


def soft_checks(project: Project, tables: Tables) -> list[str]:
    """The warning sentences, as every caller of this has always received them."""
    return [w.message for w in soft_checks_detailed(project, tables)]


def soft_checks_detailed(project: Project, tables: Tables) -> list[Finding]:
    """Non-blocking quality warnings (fleet-common patterns the Excel tool tolerated):
    blank alias texts, bits without motherwords when require_motherwords is off, and
    what the project's own datatype rows are worth saying about.

    Findings rather than sentences, for the same reason the errors are: a warning that
    names rows only inside its own prose cannot be mapped back to the file - and those
    numbers count synthesized motherwords, so "points 1, 3" in a two-point project was
    not a typo, it was unusable. The whole set of rows travels in `points`/`addrs` now,
    not the first eight of it.
    """
    warnings: list[Finding] = _datatype_warnings(project)
    blank = [(i, p.addr) for i, p in enumerate(project.points, start=1)
             if not p.text and not p.is_motherword]
    if blank:
        # addresses in the sentence, indices in the field: the index counts synthesized
        # motherwords, so a two-point project used to be told about "points 1, 3" and
        # had no way to reach the second one. The address is in the file being edited;
        # the GUI still gets the indices, which it can map through point_rows
        where = [a for _i, a in blank if isinstance(a, int)]
        head = ", ".join(str(a) for a in where[:8])
        more = f" (+{len(where) - 8} more)" if len(where) > 8 else ""
        warnings.append(_finding(
            "alias-text-missing",
            f"warning: {len(blank)} point(s) without alias text (addr {head}{more})",
            points=tuple(i for i, _a in blank), addrs=tuple(where)))
    if not project.options.require_motherwords:
        mothers = set()
        for p in project.points:
            if p.bit is None:       # any row polling the word counts (Excel semantics)
                dt = tables.datatypes.get(p.datatype)
                if dt:
                    mothers.add((dt.read_func, p.addr))
        missing = set()
        for p in project.points:
            if p.bit is not None:
                dt = tables.datatypes.get(p.datatype)
                if dt and (dt.read_func, p.addr) not in mothers:
                    missing.add(p.addr)
        if missing:
            shown = ", ".join(str(a) for a in sorted(missing)[:8])
            more = f" (+{len(missing) - 8} more)" if len(missing) > 8 else ""
            warnings.append(_finding(
                "motherword-absent",
                f"warning: bit rows without motherword at addr {shown}{more} - the "
                f"Excel tool warned about this too; enable options.auto_motherwords or "
                f"add rows if the driver needs them",
                addrs=tuple(sorted(missing))))
    warnings.extend(_owner_warnings(project))
    return warnings


def _owner_warnings(project: Project) -> list[str]:
    """`system.owner` becomes `driver_type` in `iw_sys_plant_units`, and the IWMAC side
    documents it as max 10 characters, capitals and digits only (docs/16 §16.7).

    A warning rather than an error, because the fleet does not agree with the rule and
    this repository cannot settle which is right: `KAMSTRUP801` is eleven characters and
    comes from a real Kamstrup MULTICAL delivery, and `mb_01` is lowercase with an
    underscore. Either the limit is not 10, or that delivery was truncated somewhere
    downstream without anyone noticing - and a hard error would reject a list the house
    has already shipped. Say it and generate anyway; promote it once somebody knows.
    """
    owner = (project.system.owner if project.system else "") or ""
    if not owner:
        return []
    out = []
    if len(owner) > OWNER_MAX:
        out.append(_finding(
            "owner-too-long",
            f"warning: system.owner {owner!r} is {len(owner)} characters - "
            f"IWMAC documents a maximum of {OWNER_MAX} for driver_type "
            f"(docs/16). A real delivery carries an 11-character owner, so this "
            f"is unconfirmed rather than certainly wrong - check what arrived in "
            f"iw_sys_plant_units before shipping it"))
    if not OWNER_CHARS.fullmatch(owner):
        out.append(_finding(
            "owner-charset",
            f"warning: system.owner {owner!r} is not capitals and digits only - "
            f"IWMAC documents that for driver_type (docs/16); the fleet also "
            f"carries lowercase owners, so confirm rather than assume"))
    return out
