"""Pre-generation validation: the checklist of docs/06-validation-and-checks.md 6.5,
turned into hard gates. Every finding carries the point index (1-based, as listed in
the project file after motherword synthesis) so the user can fix the YAML directly.
"""
from __future__ import annotations

import re

from .model import Project
from .rules import att, driver_id
from .tables import Tables

VALID_RW = {"r", "rw", "vr", "vrw"}
VALID_ALARM = {"A", "B", "C", "N"}

# system.owner becomes driver_type in iw_sys_plant_units. IWMAC documents these two
# limits (docs/16); both are warnings rather than gates, because the fleet contradicts
# them and this repository cannot settle which side is right.
OWNER_MAX = 10
OWNER_CHARS = re.compile(r"[A-Z0-9]+")

# A datatype key travels into Work column D, a CSV column and a VLOOKUP, and has to
# stay one unambiguous token in an error message and in the GUI's dropdown.
DATATYPE_NAME = re.compile(r"[A-Za-z0-9_]+")
DATATYPE_FIELDS = ("read_func", "write_func", "raw_type", "read_swap", "write_swap",
                   "application", "parameter_type", "rw_hint", "default_group")

# How many bits the word a motherword polls actually yields, by its raw datatype.
# A bit row extracts its bit from that word (docs/06 section 6.3), so this is the
# ceiling on what the row can address.
WORD_BITS = {"I16": 16, "U16": 16, "I32": 32, "U32": 32, "F": 32, "D": 64,
             # driver types added 2026-08-20; width is the registers the driver reads
             "I64I32": 64, "U64U32": 64, "CLK": 16, "STR4": 32, "STR8": 64,
             "BCD35": 16, "BCD4": 32, "rU16": 16, "rI16": 16}


def _top_bit(bit: int | str) -> int | None:
    """Highest bit index an authored bit value touches ('5#4' = bits 5..8).

    None when the value is not a well-formed bit - the range check below already
    reports those, and one row should not collect two errors for one mistake.
    """
    if isinstance(bit, int):
        return bit if 0 <= bit <= 31 else None
    m = re.fullmatch(r"(\d+)#(\d+)", bit) if isinstance(bit, str) else None
    if m is None:
        return None
    return int(m.group(1)) + max(int(m.group(2)), 1) - 1


def _datatype_errors(project: Project) -> list[str]:
    """Rules on the project's own datatype rows that must stop generation.

    The shipped table is the authority: a project adds keys and never redefines one,
    because Excel's VLOOKUP takes the first match and modbusgen's _FoldDict is
    first-writer-wins. A redefinition would therefore not even take effect - it would
    only make one name mean two things across two files.
    """
    from .tables import default_tables

    errors: list[str] = []
    shipped = default_tables().datatypes
    seen: dict[str, str] = {}
    for name, row in project.datatypes.items():
        where = f"datatypes.{name}"
        if not DATATYPE_NAME.fullmatch(name):
            errors.append(f"{where}: a datatype name takes letters, digits and "
                          f"underscore only")
        first = seen.get(name.casefold())
        if first is not None:
            errors.append(f"{where}: differs only in case from '{first}', and lookups "
                          f"fold case")
        seen[name.casefold()] = name
        if name in shipped and any(getattr(row, f) != getattr(shipped[name], f)
                                   for f in DATATYPE_FIELDS):
            errors.append(f"{where}: already in data/tables/datatypes.csv with a "
                          f"different definition, and a project must not redefine a "
                          f"shipped datatype - rename this row")
    return errors


def validate(project: Project, tables: Tables) -> list[str]:
    """Run after auto-fill/synthesis. Returns a list of error strings; empty = valid."""
    errors: list[str] = _datatype_errors(project)
    o = project.options
    group_names = {g.name for g in project.groups}
    seen_driver: dict[str, int] = {}
    seen_element: dict[str, int] = {}
    online_count = 0
    mothers: set[tuple[str, int]] = set()
    mother_word: dict[tuple[str, int], tuple[int, str]] = {}   # -> (bits, datatype)
    bit_rows: list[tuple[int, str, str, int, int | str]] = []

    for i, p in enumerate(project.points, start=1):
        where = f"point {i} ({p.text or p.datatype or 'unnamed'})"

        dt = tables.datatypes.get(p.datatype)
        if not p.datatype:
            errors.append(f"{where}: datatype missing")
            continue
        if dt is None:
            errors.append(f"{where}: datatype '{p.datatype}' not in data/tables/datatypes.csv")
            continue

        if not p.group:
            errors.append(f"{where}: group missing")
        elif p.group not in group_names:
            errors.append(f"{where}: group '{p.group}' has no alias in 'groups'")

        if not isinstance(p.addr, int) or p.addr < 0:
            errors.append(f"{where}: addr must be a non-negative integer")
            continue
        if o.subtract_one and p.addr - 1 < 0:
            errors.append(f"{where}: addr {p.addr} with subtract_one would go below 0")

        # 32-bit words (Danfoss alarm/status words etc.) address bits up to 31;
        # "5#4" is the legacy nibble syntax (start bit # length)
        if p.bit is not None and not (
                (isinstance(p.bit, int) and 0 <= p.bit <= 31)
                or (isinstance(p.bit, str) and re.fullmatch(r"\d+#\d+", p.bit))):
            errors.append(f"{where}: bit must be 0..31 or nibble syntax like '5#4'")
        if p.bit is not None and dt.read_func not in ("3", "4"):
            errors.append(f"{where}: bit addressing needs a register datatype "
                          f"(read function 3/4), not '{p.datatype}'")

        if p.rw not in VALID_RW:
            errors.append(f"{where}: rw must be one of {sorted(VALID_RW)}")
        # bit rows write through their word - no per-bit write function needed
        if p.rw in ("rw", "vrw") and dt.write_func == "" and p.bit is None:
            errors.append(f"{where}: datatype '{p.datatype}' has no write function; "
                          f"rw is impossible")

        if p.alarm is not None and p.alarm not in VALID_ALARM:
            errors.append(f"{where}: alarm must be one of {sorted(VALID_ALARM)}")

        if p.unit and p.unit not in tables.units:
            errors.append(f"{where}: unit '{p.unit}' not in data/tables/units.csv")
        if p.scale and p.scale not in tables.scaling:
            errors.append(f"{where}: scale '{p.scale}' not in data/tables/scaling.csv")

        if p.decimals is not None and p.decimals not in (0, 1, 2, 3):
            errors.append(f"{where}: decimals must be 0..3")

        if p.statetext is not None and p.statetext not in project.statetexts:
            errors.append(f"{where}: statetext {p.statetext} not defined in 'statetexts'")

        if p.update_freq is not None and p.update_freq not in (
                "fast", "norm", "slow", "once", "never"):
            errors.append(f"{where}: update_freq must be fast/norm/slow/once/never")


        did = driver_id(p, project, tables)
        eid = p.element_id if p.element_id else f"{p.group}_{did}"
        if did in seen_driver:
            errors.append(f"{where}: duplicate driver_id '{did}' (also point {seen_driver[did]})")
        else:
            seen_driver[did] = i
        if eid in seen_element:
            errors.append(f"{where}: duplicate element_id '{eid}' (also point {seen_element[eid]})")
        else:
            seen_element[eid] = i

        if p.online:
            online_count += 1
        if p.bit is None:           # any row polling the word counts (Excel semantics)
            key = (dt.read_func, p.addr)
            mothers.add(key)
            bits = WORD_BITS.get(dt.raw_type)
            if bits and bits > mother_word.get(key, (0, ""))[0]:
                mother_word[key] = (bits, p.datatype)
            if p.is_motherword and att(p) != "r":
                errors.append(f"{where}: motherword must be read-only (rw: r)")
        if p.bit is not None:
            bit_rows.append((i, where, dt.read_func, p.addr, p.bit))

    if o.require_motherwords:
        for i, _where, rf, addr, _bit in bit_rows:
            if (rf, addr) not in mothers:
                errors.append(f"point {i}: bit value at addr {addr} has no motherword "
                              f"row (same address, no bit, text 'Motherword')")

    # A bit is extracted from the word its motherword polls, so it cannot reach past that
    # word's width - and synthesized motherwords are 16-bit by design (rules.py).
    for _i, where, rf, addr, bit in bit_rows:
        top = _top_bit(bit)
        bits, mother_dt = mother_word.get((rf, addr), (0, ""))
        if top is None or not bits or top < bits:
            continue
        errors.append(f"{where}: bit {bit} is outside the {bits}-bit motherword at addr "
                      f"{addr} ('{mother_dt}' covers bits 0..{bits - 1}) - bits above it "
                      f"live in the register holding the high word, and finding which "
                      f"register that is means fixing the 32-bit word order, which "
                      f"modbusgen never guesses (docs/15): address the bit in that "
                      f"register, or author this word as an explicit 32-bit point")

    if online_count == 0 and project.points:
        errors.append("no point has online: true - at least one online-indication "
                      "point is required (docs/06 item 6)")

    dup_orders = {}
    for g in project.groups:
        dup_orders.setdefault(g.order, []).append(g.name)
    for order, names in dup_orders.items():
        if len(names) > 1:
            errors.append(f"groups {names} share view order {order}")

    return errors


def _datatype_warnings(project: Project) -> list[str]:
    """Things worth saying about a project's own datatypes that must not stop a list.

    The vocabulary check is deliberately soft. The GUI offers dropdowns and cannot
    create an off-vocabulary row; a real delivery can contain one, and refusing to
    validate it would leave that list with no route through the tool at all.
    """
    from .tables import default_tables

    warnings: list[str] = []
    shipped = default_tables().datatypes
    vocabulary = {f: {getattr(dt, f) for dt in shipped.values()}
                  for f in DATATYPE_FIELDS}
    used = {p.datatype.casefold() for p in project.points if p.datatype}
    for name, row in project.datatypes.items():
        where = f"warning: datatypes.{name}"
        if name in shipped:
            warnings.append(f"{where}: also in the shared table, with the same "
                            f"definition - harmless, and what a promoted row looks like")
        for f in DATATYPE_FIELDS:
            value = getattr(row, f)
            if value not in vocabulary[f]:
                warnings.append(f"{where}: {f} '{value}' appears in no shipped "
                                f"datatype, so nothing here can say the driver "
                                f"supports it (docs/15)")
        if name.casefold() not in used:
            warnings.append(f"{where}: defined, but no point uses it")
    return warnings


def soft_checks(project: Project, tables: Tables) -> list[str]:
    """Non-blocking quality warnings (fleet-common patterns the Excel tool tolerated):
    blank alias texts, bits without motherwords when require_motherwords is off, and
    what the project's own datatype rows are worth saying about."""
    warnings: list[str] = _datatype_warnings(project)
    no_text = [i for i, p in enumerate(project.points, start=1)
               if not p.text and not p.is_motherword]
    if no_text:
        head = ", ".join(str(i) for i in no_text[:8])
        more = f" (+{len(no_text) - 8} more)" if len(no_text) > 8 else ""
        warnings.append(f"warning: {len(no_text)} point(s) without alias text "
                        f"(points {head}{more})")
    if not project.options.require_motherwords:
        mothers = set()
        for p in project.points:
            if p.bit is None:       # any row polling the word counts (Excel semantics)
                dt = tables.datatypes.get(p.datatype)
                if dt:
                    mothers.add((dt.read_func, p.addr))
        missing = set()
        for p in project.points:
            if p.bit is not None:
                dt = tables.datatypes.get(p.datatype)
                if dt and (dt.read_func, p.addr) not in mothers:
                    missing.add(p.addr)
        if missing:
            shown = ", ".join(str(a) for a in sorted(missing)[:8])
            more = f" (+{len(missing) - 8} more)" if len(missing) > 8 else ""
            warnings.append(f"warning: bit rows without motherword at addr {shown}"
                            f"{more} - the Excel tool warned about this too; enable "
                            f"options.auto_motherwords or add rows if the driver "
                            f"needs them")
    warnings.extend(_owner_warnings(project))
    return warnings


def _owner_warnings(project: Project) -> list[str]:
    """`system.owner` becomes `driver_type` in `iw_sys_plant_units`, and the IWMAC side
    documents it as max 10 characters, capitals and digits only (docs/16 §16.7).

    A warning rather than an error, because the fleet does not agree with the rule and
    this repository cannot settle which is right: `KAMSTRUP801` is eleven characters and
    comes from a real Kamstrup MULTICAL delivery, and `mb_01` is lowercase with an
    underscore. Either the limit is not 10, or that delivery was truncated somewhere
    downstream without anyone noticing - and a hard error would reject a list the house
    has already shipped. Say it and generate anyway; promote it once somebody knows.
    """
    owner = (project.system.owner if project.system else "") or ""
    if not owner:
        return []
    out = []
    if len(owner) > OWNER_MAX:
        out.append(f"warning: system.owner {owner!r} is {len(owner)} characters - "
                   f"IWMAC documents a maximum of {OWNER_MAX} for driver_type "
                   f"(docs/16). A real delivery carries an 11-character owner, so this "
                   f"is unconfirmed rather than certainly wrong - check what arrived in "
                   f"iw_sys_plant_units before shipping it")
    if not OWNER_CHARS.fullmatch(owner):
        out.append(f"warning: system.owner {owner!r} is not capitals and digits only - "
                   f"IWMAC documents that for driver_type (docs/16); the fleet also "
                   f"carries lowercase owners, so confirm rather than assume")
    return out
