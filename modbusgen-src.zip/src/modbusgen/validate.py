"""Pre-generation validation: the checklist of docs/06-validation-and-checks.md 6.5,
turned into hard gates.

A finding says four things, and each is used by somebody different. The **message** is
the diagnosis, and is what `validate()` has always returned. The **code** is a stable
key: the GUI hangs its one-click repairs off it, so rewording a message can no longer
silently detach its fix. The **advice** is what to do about it, which until 2026-08-26
existed only in the page - the CLI printed rules and no remedies, which is a poor deal
for a person and a useless one for an agent. And the **suggestion** is a near key from
the same table, because the most expensive datatype error on record (`I_Hold_U16R_N`
across 50 points, docs/11) was a transposition that any spell-check would have caught.

Every finding about a point carries that point's index *and its address*. The index
counts rows after motherword synthesis, so it can name a row the author never wrote;
the address is in the file they are editing.
"""
from __future__ import annotations

import difflib
import re
from dataclasses import dataclass

from .model import DRIVERS, Project
from .rules import att, driver_id
from .tables import Tables

VALID_RW = {"r", "rw", "vr", "vrw"}
VALID_ALARM = {"A", "B", "C", "N"}

# system.owner becomes driver_type in iw_sys_plant_units. IWMAC documents these two
# limits (docs/16); both are warnings rather than gates, because the fleet contradicts
# them and this repository cannot settle which side is right.
OWNER_MAX = 10
OWNER_CHARS = re.compile(r"[A-Z0-9]+")
# Column widths from the CREATE TABLE in sqlout. MySQL truncates rather than refusing,
# so anything past these lands in the plant database quietly shortened.
MENU_MAX = 10
ELEMENT_ID_MAX = 100

# What the driver's own configuration string can carry, from the RC_RR_RDT_RS_WC_WR_WDT_WS
# table in docs/15 section 2. These are the same on both drivers - a function code or a
# swap letter outside them is not a modbus.php limitation, it is a string neither driver
# can parse - so they are errors whatever `driver` says, and whatever it does not say.
# `0` is a read function because the shipped `Virt` row uses it: a calculated point polls
# nothing. Empty is legal for the write half, and means the row is not writable.
DRIVER_READ_FUNCS = {"0", "1", "2", "3", "4"}
DRIVER_WRITE_FUNCS = {"", "5", "6", "15", "16"}
DRIVER_SWAPS = {"", "N", "R", "W"}

# The two transports the driver has (docs/15 section 1; neither driver does Modbus over
# UDP, which the rev-3 document states outright). sqlout writes mb_mode as
# `"0" if mode == "rtu" else "2"`, so anything that is not exactly `rtu` is configured as
# TCP - a misspelling is not ignored, it is silently answered.
COMM_MODES = {"tcp", "rtu"}

# The table name is interpolated straight into `iw_par_{t}_param` and its two siblings,
# inside backticks. The schema has always declared this pattern; nothing enforced it at
# run time, so a backtick in the name closed the identifier and left the rest of it loose
# in the script.
TABLE_NAME = re.compile(r"[a-z0-9_]+")
# A Modbus PDU addresses a register with two bytes, so 65535 is the last one there is.
# Checked against the protocol address - after subtract_one - because that is the number
# the driver puts on the wire.
ADDR_MAX = 65535
# The plant number reaches the generated file's name and nothing else, which is exactly
# why a separator in it matters: gui.py writes projects_dir / default_filename(project).
# a set rather than a character class: written as a regex this was r'[<>:"/\|?*]',
# where the backslash escaped the pipe instead of joining the class, so the one character
# most worth catching - the separator - was silently not in it.
FILENAME_UNSAFE = frozenset('<>:"|?*') | {"/", chr(92)}

# The plant number this repository hands out: the GUI's starter prompt tells an agent to
# write `plant: 1234` into the file it produces, so a list authored that way arrives
# carrying it whether or not anyone ever supplied the real one. Only this value, and only
# as a warning - 1234 is a legal four-digit plant number, so a project may genuinely mean
# it. The plant field's own HTML placeholder shows 12345 and is deliberately not here: it
# is never a value, and it is the number the test suite uses for a project that is right.
PLACEHOLDER_PLANT = "1234"

# Characters that are not in the output encoding but have an exact equivalent in it, so
# swapping them loses no meaning. Every one of these arrives by paste from a vendor PDF -
# the non-breaking hyphen especially, which is indistinguishable from a plain one on
# screen. The rest of what cp1252 cannot carry (an ohm sign, an arrow, a tick) has no
# equivalent and is the author's to decide about, which is why the repair says it only
# handles these.
LOOKALIKES = {"\u2010": "-", "\u2011": "-", "\u2012": "-", "\u2212": "-",
              "\u03bc": "\u00b5", "\u2044": "/", "\u2032": "'",
              "\u2007": " ", "\u202f": " "}
# `N` in the driver id: the Modbus slave address (docs/15 section 2). The fleet carries
# nothing that contradicts the range, unlike the owner-length limit beside it.
SLAVE_MIN, SLAVE_MAX = 1, 255

# The capability rows of docs/15 section 1 that separate the two drivers: mb.exe carries
# all three, modbus.php carries none. Each is therefore a *question* while `driver` is
# unstated - which is what it always was - and a *statement* once the project says
# modbus.php, because then the list is known to be wrong rather than possibly wrong. One
# row per capability, one predicate, and two codes: the warning and the error say the
# same thing at two levels of certainty.
#
# Only capabilities the sources name outright are here. STR4/STR8, CLK and the 64-bit
# float are marked "unverified" per driver in section 5, and that section says in as many
# words not to infer support from silence - so they are absent rather than assumed either
# way. The 64-bit *writes* those types need are caught by the FC16 row regardless.
DRIVER_CAPS = (
    ("driver-swap-needs-mb-exe", "driver-swap-unsupported",
     lambda p, dt: dt.read_swap in ("R", "W") or dt.write_swap in ("R", "W"),
     "{n} point(s) with a swapped word order - these work on mb.exe only, and the "
     "project does not say which driver the plant runs (docs/15)",
     "{n} point(s) with a swapped word order on modbus.php, which has no word or byte "
     "swap - each reads a plausible wrong number and nothing reports it (docs/15)"),
    ("driver-write32-needs-mb-exe", "driver-write-unsupported",
     lambda p, dt: p.rw in ("rw", "vrw") and dt.write_func == "16",
     "{n} point(s) whose write needs FC16 - a value wider than one register is written "
     "in a single FC16 transaction and FC16 is mb.exe only, but the project does not "
     "say which driver the plant runs (docs/15)",
     "{n} point(s) whose write needs FC16 on modbus.php, which has no FC16 at all - "
     "none of them can be written, and nothing reports it (docs/15)"),
    ("driver-wide64-needs-mb-exe", "driver-wide64-unsupported",
     lambda p, dt: "64" in dt.raw_type,
     "{n} point(s) use a 64-bit integer datatype - mb.exe supports those only partly "
     "and modbus.php not at all, and the project does not say which driver the plant "
     "runs (docs/15 section 5)",
     "{n} point(s) use a 64-bit integer datatype on modbus.php, which does not support "
     "them - I64I32 and U64U32 need mb.exe (docs/15 section 5)"),
)

# A datatype key travels into Work column D, a CSV column and a VLOOKUP, and has to
# stay one unambiguous token in an error message and in the GUI's dropdown.
DATATYPE_NAME = re.compile(r"[A-Za-z0-9_]+")
DATATYPE_FIELDS = ("read_func", "write_func", "raw_type", "read_swap", "write_swap",
                   "application", "parameter_type", "rw_hint", "default_group")

# How many bits the word a motherword polls actually yields, by its raw datatype.
# A bit row extracts its bit from that word (docs/06 section 6.3), so this is the
# ceiling on what the row can address.
WORD_BITS = {"I16": 16, "U16": 16, "I32": 32, "U32": 32, "F": 32, "D": 64,
             # driver types added 2026-08-20; width is the registers the driver reads
             "I64I32": 64, "U64U32": 64, "CLK": 16, "STR4": 32, "STR8": 64,
             "BCD35": 16, "BCD4": 32, "rU16": 16, "rI16": 16}


@dataclass(frozen=True)
class Finding:
    """One validation failure, in the four forms its readers need."""
    code: str                       # stable key; the GUI's repairs hang off this
    message: str                    # the diagnosis, as validate() has always phrased it
    advice: str                     # what to do about it
    point: int | None = None        # 1-based index, counted after motherword synthesis
    addr: int | None = None         # the register, which is in the file being edited
    suggestion: str | None = None   # a near key from the same table, when one exists
    # A warning is usually about a set of rows rather than one, and reports the whole
    # set: the prose used to stop at eight and put the rest beyond reach. Kept as
    # numbers rather than one finding per row, because 1 600 blank alias texts is a
    # real list and 1 600 findings is not a payload anybody wants.
    points: tuple[int, ...] = ()
    addrs: tuple[int, ...] = ()

    def as_dict(self) -> dict:
        return {"code": self.code, "message": self.message, "advice": self.advice,
                "point": self.point, "addr": self.addr, "suggestion": self.suggestion,
                "points": list(self.points), "addrs": list(self.addrs)}


# One entry per code. A code with no advice is a rule stated without a remedy, which is
# the state this table exists to end; a test asserts every code used below appears here.
ADVICE = {
    "datatype-missing":
        "Choose a datatype. It supplies the read and write function codes, so nothing "
        "else about the row can be derived until it is set.",
    "datatype-unknown":
        "That datatype key does not exist. Pick one from the table, or - if the "
        "register genuinely needs a combination no shipped key describes - define it in "
        "the project's own `datatypes` block (docs/02) rather than inventing a "
        "spelling.",
    "datatype-name-illegal":
        "Rename the variable using letters, digits and underscore only. The key travels "
        "into Work column D, a CSV column and a VLOOKUP, and a space or a slash breaks "
        "one of the three.",
    "datatype-name-case-duplicate":
        "Rename one of the two. Datatype lookups fold case, here and in Excel, so two "
        "names differing only in case are one name with two definitions.",
    "datatype-redefines-shipped":
        "Rename the variable. The shipped table wins: Excel's VLOOKUP takes the first "
        "match, so a project row of the same name would never take effect - it would "
        "only make one name mean two things in two files.",
    "group-missing":
        "Give the row a group, or switch on options.auto_groups to fill it from the "
        "datatype's default group.",
    "group-unknown":
        "Define that group in the project's `groups` block. The standard set is "
        "aio/dio/alm/misc/sch; a converted workbook keeps its own section headings "
        "instead (docs/11).",
    "addr-invalid":
        "Enter the register number exactly as the documentation prints it, digits only, "
        "with any 4xxxx/3xxxxx prefix stripped.",
    "addr-underflow":
        "Address 0 cannot have 1 subtracted from it. Either the documentation is already "
        "0-based - turn options.subtract_one off - or the address is wrong.",
    "bit-invalid":
        "Bit must be 0-31, or the nibble form start#length such as 5#4.",
    "bit-needs-register":
        "Bits live inside a register: use Bit_Hold or Bit_Input. Coils and discrete "
        "inputs are already single bits, so they take no bit number.",
    "rw-invalid":
        "Use r for read-only or rw for writable. vr and vrw are applied automatically to "
        "bit rows - you do not author them.",
    "rw-not-writable":
        "The datatype table marks that register read-only. Set rw back to r, or choose a "
        "datatype that has a write function - and check docs/15 first, because a 32-bit "
        "write needs function 16 and the modbus.php driver cannot do it at all.",
    "alarm-invalid":
        "The alarm letter must be A, B, C or N. Leave it blank for a point that raises "
        "no alarm.",
    "scale-unknown":
        "Pick a scale from data/tables/scaling.csv, or add it there. x0.1 covers most of "
        "the real fleet; if the document needs a factor the table lacks, omit scale, "
        "keep the point and say so.",
    "decimals-range":
        "Decimals must be 0, 1, 2 or 3 - or blank to leave the display format empty.",
    "statetext-unknown":
        "Add a list with that id to `statetexts`, or clear the statetext field on the "
        "row.",
    "update-freq-invalid":
        "Leave update_freq unset to let it be derived, or choose fast, norm, slow, once "
        "or never.",
    "driver-id-duplicate":
        "Two rows poll the same register and bit, which is one address twice. Change one "
        "of the addresses, or delete the copy. Applying one address across several rows "
        "in a bulk edit causes this.",
    "element-id-duplicate":
        "Two rows resolve to the same key. Change the group or the address on one of "
        "them, or give one an explicit element_id.",
    "motherword-not-read-only":
        "Set that row's rw to r. A motherword exists to poll the word its bits live in; "
        "it is never written.",
    "motherword-missing":
        "Switch on options.auto_motherwords to have it created, or add a row at the same "
        "address with no bit.",
    "bit-outside-motherword":
        "The motherword the tool synthesizes is 16-bit, and it is never widened because "
        "a 32-bit one would have to guess the word order. Either author the word itself "
        "as an explicit 32-bit point at that address - that choice of _N or _W is what "
        "makes the high bits addressable - or move the bit to the register actually "
        "holding the high word.",
    "online-missing":
        "Mark three or four reliable, frequently changing read points online: true - an "
        "outdoor temperature or an energy counter. IWMAC uses them to tell that the unit "
        "is alive, so a point that rarely changes is a poor choice.",
    "group-order-clash":
        "Give each group its own view order; two groups cannot sit at the same position.",

    # Soft checks. These never stop a list, which is exactly why each one has to say
    # what it costs to ignore - a warning nobody can act on is noise, and noise is what
    # gets a real warning ignored later.
    "unit-unknown":
        "A custom unit ships into eng_unit exactly as typed (varchar(20)), so the "
        "operator sees this spelling. Use the table's key where one exists - a near "
        "miss gets a suggestion; check it against the document before taking it - or "
        "add the unit to data/tables/units.csv so every future list shares one "
        "spelling. Excel wrote XL-ERROR here and warned; modbusgen writes the text.",
    "alias-text-missing":
        "Give each row an alias text: it is the only name the operator ever sees, so a "
        "blank one ships a nameless line in the IWMAC menu. The Excel tool tolerated "
        "this and real lists carry it, which is why it does not block - but it is a "
        "delivery defect, not a style choice.",
    "motherword-absent":
        "A bit row reads its bit out of a word somebody has to poll. Leave "
        "options.auto_motherwords on and the word row is synthesized for you; switch it "
        "off and you must author a row at the same address with no bit, or the bits "
        "read nothing.",
    "project-datatype-also-shipped":
        "Nothing to do. The row matches the shared table exactly, which is what a "
        "promoted datatype looks like and what a project opened on a machine that "
        "already has the row looks like. Delete it from the project only if you are "
        "sure every machine that opens this file has the shared row.",
    "project-datatype-unknown-value":
        "Check that field against docs/15 before shipping. Every other datatype in the "
        "table uses a value the driver is known to accept; this one does not, so "
        "nothing here can tell you whether the driver will understand it. The GUI "
        "cannot create such a row - it came from an import or was hand-edited.",
    "project-datatype-unused":
        "Delete the definition, or point a row at it. An unused datatype is harmless in "
        "the file and misleading to the next reader, who will assume some point needs "
        "it.",
    "owner-too-long":
        "Check what actually arrived in iw_sys_plant_units before shipping. IWMAC "
        "documents 10 characters for driver_type, and a real delivery carries 11 - so "
        "either the limit is not 10 or that delivery was truncated somewhere without "
        "anyone noticing. Shorten it if the plant database shows truncation.",
    "owner-charset":
        "Check it against the plant database. IWMAC documents capitals and digits for "
        "driver_type; the fleet also carries lowercase owners, so this is unconfirmed "
        "rather than certainly wrong.",
    "comm-incomplete":
        "Fill the address in, or switch system.settings off until you have it. The "
        "script is generated either way: a missing IP is written as the literal "
        "XXX.XXX.XXX.XXX and a missing serial port as an empty value, and once that is "
        "imported it sits in iw_sys_plant_settings looking exactly like a real setting. "
        "The driver then fails to reach a device that is on the bus.",
    "plant-missing":
        "Set the plant number. It names the generated file and nothing else, so this "
        "cannot produce a wrong list - but a script called modbusgen--<table> is one "
        "nobody can file against a plant. A project rebuilt from a generated SQL script "
        "never carries one, because the SQL does not store it.",
    "plant-is-a-placeholder":
        "Put the real plant number in. 1234 is the number the GUI's starter prompt writes "
        "into the project it asks an agent for, so it arrives in every list authored that "
        "way and looks exactly like an answer. It reaches the generated file's name and "
        "nothing else, so the list itself is not wrong - the script is simply filed "
        "against a plant nobody meant, which is the kind of mistake that surfaces at "
        "import time in front of a customer. There is no repair, because the number is a "
        "fact about the plant; if the plant really is 1234, leave it and say so.",
    "points-none":
        "Add the points, or say the file is a skeleton on purpose. An empty points array "
        "is legal - docs/14 ships one for a document that could not be read - which is "
        "why this is a warning and not an error. But zero is also what a file loads as "
        "when its rows were written somewhere the loader does not read, and the count to "
        "hold it against is the coverage ledger's included total: if the source has rows "
        "and the project has none, the file lost them, and the next thing to check is "
        "its shape (docs/11 'Project shape checkpoint'), not its register facts.",
    "driver-unknown":
        "Set the project's driver to mb.exe or modbus.php, or leave it out. Those are "
        "the two IWMAC Modbus driver implementations (docs/15 section 1) and there is no "
        "third. A spelling neither of them matches is refused rather than read as one, "
        "because a driver the tool does not recognise would quietly switch off the "
        "checks that depend on knowing which one it is.",
    "table-name-illegal":
        "Rename the table using lowercase letters, digits and underscore only - the "
        "pattern the schema has always declared. The name is interpolated into "
        "`iw_par_<name>_param` and its two siblings inside backticks, so a backtick in it "
        "closes the identifier and leaves the rest of the name loose in the script, and a "
        "space or a capital makes an identifier nobody can type again. This name decides "
        "which three database tables the plant's list lands in, so changing it changes "
        "the destination: check it against the delivery before taking the repair.",
    "addr-too-high":
        f"A Modbus request addresses a register with two bytes, so {ADDR_MAX} is the last "
        f"one that exists. Check whether the documentation prints a `4xxxx`/`3xxxxx` "
        f"table prefix that should have been stripped - `40101` is address `101`, not "
        f"40101 - which is the usual cause. The check is against the protocol address, "
        f"after options.subtract_one, because that is the number the driver puts on the "
        f"wire.",
    "plant-not-filename-safe":
        "Take those characters out of the plant number. It reaches the generated file's "
        "name and nothing else, which is the whole problem: the GUI writes "
        "projects_dir / default_filename(project), so a separator in it aims the write "
        "somewhere other than the projects folder and a reserved character makes a name "
        "Windows refuses outright. The fleet's plant numbers are digits; there is no "
        "repair here because the number itself is a fact about the plant.",
    "sys-field-space":
        "Take the spaces out. IWMAC states the constraint for these two fields (docs/16 "
        "section 16.7): reg_type lands in regulator_type and order_no in order_no, both "
        "in iw_sys_plant_units, and neither takes a space. Unlike the owner limit beside "
        "it, nothing in the fleet contradicts this one - but it is still the platform's "
        "rule rather than something this tool can prove, so it warns rather than blocks. "
        "The house convention is to populate reg_type, order_no and owner identically "
        "from the driver name (docs/13), and both fields stay blank unless the delivery "
        "specifies them.",
    "comm-mode-unknown":
        "Set comm.mode to tcp or rtu - those are the two transports the driver has, and "
        "neither of them is UDP (docs/15 section 1). This is not ignored: sqlout writes "
        "mb_mode as 0 for rtu and 2 for everything else, so any other spelling - "
        "including RTU in capitals - configures the plant as TCP without saying so. The "
        "placeholder check goes with it, because comm-incomplete only looks at a mode "
        "that is exactly tcp: a misspelt mode with no IP writes XXX.XXX.XXX.XXX into the "
        "plant database and reports nothing at all.",
    "slave-address-range":
        f"Use the device's Modbus slave address, {SLAVE_MIN} to {SLAVE_MAX} (docs/15 "
        f"section 2). It is the `N` field of the driver id and identifies the device on "
        f"the bus; 0 is the broadcast address and addresses nothing, and anything above "
        f"{SLAVE_MAX} does not fit the protocol. This is separate from "
        f"driver_addr_prefix, which is the 0_ or 1_ in front of it and not part of the "
        f"address.",
    "online-never-polled":
        "Either clear the update_freq on those points or mark a different point as the "
        "online indication. `never` and `once` are the two frequencies that do not "
        "repeat, and the online indication is what IWMAC watches to decide the device is "
        "answering at all - a point that is polled once and never again cannot show "
        "that. Pick something that changes on its own and is always readable: an outdoor "
        "temperature, an energy counter (docs/16 section 16.10).",
    "text-not-encodable":
        "Those characters are not in the file's output encoding, so the generated script "
        "carries a literal ? where each one stood - in the alias the operator reads, or "
        "the menu, or a state word. The CLI refuses to write such a file at all "
        "(errors=strict); the GUI's download and the browser build replace instead, "
        "which is why this is worth seeing before you press Generate rather than after "
        "the script is in the plant database. Some of them are a paste artefact with an "
        "exact equivalent that does encode - a non-breaking hyphen for a hyphen, a Greek "
        "mu for the micro sign - and the repair swaps only those. The rest have no "
        "equivalent: an ohm sign, an arrow, a tick. Write those out in words, in the "
        "document's own language, rather than leaving a ? for the operator.",
    "motherword-text-collision":
        "Rename the point. `Motherword` is not a reserved word in the file format, it is "
        "how the tool recognises a synthesized word row - the test is an exact match on "
        "the alias text - so a point that happens to carry it is treated as one of those "
        "everywhere. The row still reaches iw_par_<t>_param, but with "
        "exclude_motherwords_from_groups on, which is the default, it gets no group "
        "membership and the operator never sees it in any menu folder. Several warnings "
        "skip it as well, for the same reason. Use the maker's own wording for the value, "
        "as every other point does; there is no button here because the tool cannot pick "
        "a name for you.",
    "statetext-word-duplicate":
        "Two numbers in one state list carry the same word, so the operator sees one "
        "text for two different device states and cannot tell them apart - the state "
        "list's whole job. Copy the vendor's own wording for each number; where the "
        "document really does give two values the same name, say so in the notes rather "
        "than leaving it looking like a copy-paste slip. Which of the two is wrong is a "
        "question for the document, so there is no button for it.",
    "statetext-overwrites-extra":
        "Switch options.statetext_in_alias off to keep the extra you wrote. On, the "
        "flattened state list is written into every point's extra that has a state "
        "list, replacing whatever was there - so '(1=Drift)' becomes the whole list and "
        "the note you meant the operator to read is gone from the alias. Leave the "
        "option on only where no point carries an extra of its own.",
    "group-alias-blank":
        "Give the group a display alias. It is the name of the folder the operator opens "
        "in the IWMAC menu, and an empty one writes a group_alias row with an empty "
        "value - a folder with no name rather than no folder. The key itself is a poor "
        "name and still a better one than nothing; the fleet uses short words in the "
        "document's own language (docs/12).",
    "range-inverted":
        "Swap them: range_min is the bottom of the engineering range and range_max the "
        "top, and a range that runs downwards is not a range. options.include_minmax is "
        "on, so both values are written into the param row exactly as given - nothing "
        "sorts them on the way out.",
    "bit-point-formatted":
        "Clear the unit, scale and decimals on those rows. A coil, a discrete input or a "
        "bit inside a register has two values and no magnitude, so there is nothing for "
        "a unit to name or a factor to multiply - but they are still written into the "
        "parameter row, where a temperature unit and two decimals on an on/off value "
        "describe nothing. If the register really is a measurement then the datatype is "
        "wrong rather than the formatting: a bit datatype cannot carry one. What a "
        "digital point wants instead is a state text (docs/07).",
    "datatype-func-unsupported":
        "Use a function code the driver has. Reads are 1 coils, 2 discrete inputs, "
        "3 holding registers, 4 input registers; writes are 5 single coil, 6 single "
        "register, 15 multiple coils, 16 multiple registers, or blank for a row that is "
        "not writable (docs/15 section 3). This is not a modbus.php limitation - a code "
        "outside that set is a configuration string neither driver can parse, so it "
        "fails everywhere. Check which register block the vendor document puts the "
        "value in rather than picking a code that looks close.",
    "datatype-swap-unsupported":
        "Word order is one of three letters: N normal, R swap bytes, W swap words "
        "(docs/15 section 2). A datatype swaps bytes or words, never both - the driver "
        "has no encoding for that and the capabilities matrix lists it as unsupported on "
        "both drivers. If the device needs something none of the three describes, that "
        "is a finding to report rather than a spelling to invent.",
    "driver-swap-unsupported":
        "The project says this plant runs modbus.php, which supports no word or byte "
        "swap at all, so these points cannot be read correctly there - each returns a "
        "plausible wrong number and nothing reports it (docs/15 section 1). Only the _N "
        "form works on that driver. Whether the device really is _N is a register-level "
        "fact: settle it from the vendor document, or read the raw words with modpoll "
        "-t3:hex and rearrange them by hand (docs/16 section 16.4.1). Do not switch to "
        "_N to clear this - that is a claim about the device, not a repair. If the plant "
        "is in fact on mb.exe, correct the driver field instead.",
    "driver-write-unsupported":
        "The project says this plant runs modbus.php, which has no FC16 at all, so a "
        "value wider than one register cannot be written there - the write silently "
        "never happens (docs/15 sections 1 and 4). Author these points r and report why; "
        "the value stays readable, since a 32-bit read without a swap works on both "
        "drivers. If the plant is in fact on mb.exe, correct the driver field instead.",
    "driver-wide64-unsupported":
        "The project says this plant runs modbus.php, which does not support 64-bit "
        "datatypes; I64I32 and U64U32 need mb.exe (docs/15 section 5). Prefer skipping "
        "the register and reporting the gap over shipping a row that reads nothing. Note "
        "that even on mb.exe the support is partial - IWMAC casts the value down to 32 "
        "bits on save - so a counter that genuinely needs 64 bits has no correct home on "
        "either driver.",
    "driver-wide64-needs-mb-exe":
        "Say which driver the plant runs - set driver to mb.exe or modbus.php beside the "
        "plant number - and this stops being a question. modbus.php does not support "
        "I64I32 or U64U32 at all, and mb.exe supports them only partly: it casts the "
        "value down to 32 bits on save, so a counter that genuinely needs 64 bits loses "
        "its top half with no error (docs/15 sections 1 and 5). Prefer skipping such a "
        "register and reporting it over shipping a lossy read.",
    "driver-swap-needs-mb-exe":
        "Say which driver the plant runs - set driver to mb.exe or modbus.php beside the "
        "plant number - and this stops being a question. modbus.php supports no word or "
        "byte swap at all, so a _R or _W point reads a plausible wrong number there and "
        "never fails loudly (docs/15); on mb.exe the swap is supported and there is "
        "nothing to answer. Only the _N form works on modbus.php, but whether the device "
        "really is _N is a register-level fact and never a substitution made to satisfy "
        "a driver. Settle it rather than guess it: the vendor document, if it states a "
        "word order - otherwise a live read. modpoll has no swap of its own, so read the "
        "raw words with -t3:hex and rearrange them by hand, two and two for a byte swap "
        "and four and four for a word swap; the arrangement that gives a plausible "
        "number is the one the device delivers (docs/16 section 16.4.1).",
    "driver-write32-needs-mb-exe":
        "Say which driver the plant runs - set driver to mb.exe or modbus.php beside the "
        "plant number - and this stops being a question. A 32-bit write is one FC16 "
        "transaction and modbus.php has no FC16 at all, so the write silently never "
        "happens there; on mb.exe it is supported and there is nothing to answer. On "
        "modbus.php the documented remedy is to author the point r and report why "
        "(docs/15 section 5) - the value stays readable, since 32-bit reads without a "
        "swap work on both drivers.",
    "datatype-truncates":
        "Prefer skipping the row and saying you did. I64I32 and U64U32 are 64-bit on "
        "the wire and IWMAC casts them down to 32 bits on save, so a counter that "
        "genuinely needs 64 loses its top half with nothing reported (docs/15). Include "
        "it only with the loss stated to whoever reads the list.",
    "statetext-unused":
        "Delete the list, or point a row at it with statetext. An unreferenced state "
        "list emits nothing and tells the next reader that some point needs it.",
    "group-unused":
        "Delete the group, or move rows into it. A group no point uses is still written "
        "to the groups block, so the operator gets a menu folder that opens on nothing.",
    "alias-duplicate":
        "Give them different text, or different system_no/tag so the alias as a whole "
        "differs. Two rows that read identically in the menu cannot be told apart by "
        "the operator, who has no way to see which register each one came from.",
    "alarms-to-alm-inert":
        "Switch options.auto_groups on, or switch alarms_to_alm off. On its own it does "
        "nothing at all: the regrouping only runs inside the auto_groups pass, so the "
        "alarm rows stay in the groups they already had and the setting reads as though "
        "it took effect. Note that auto_groups also fills empty groups from the "
        "datatype's default, which is not what you want on a source that defines its "
        "own sections.",
    "ranges-dropped":
        "Switch options.include_minmax on, or delete the ranges. They are carried in "
        "the file and nowhere else: with the option off the param row's min and max "
        "columns are written blank, which is what the fleet does, so the values look "
        "recorded and reach nothing.",
    "statetexts-dropped":
        "Switch options.use_json on. It is the master gate: with it off no format_extra "
        "is emitted for any point, whatever ids the rows carry, so the operator sees "
        "the raw number where the file says they should see a word.",
    "alias-part-dropped":
        "Switch the alias part back on, or clear the field on those rows. The alias is "
        "assembled from system_no, tag, text and extra under three separate toggles; a "
        "part switched off is simply not joined, so the data sits in the file looking "
        "delivered and never reaches the operator.",
    "statetext-only-rw-drops":
        "Switch options.statetext_only_rw off, or accept that these rows show numbers. "
        "It restricts state-text JSON to writable points, so a read-only status register "
        "with a perfectly good list attached emits nothing.",
    "active-ignored":
        "Clear the per-point active, or switch options.force_active off. Force-active "
        "sets every row to 1 regardless, so a row deliberately marked inactive is "
        "written active anyway - only a text matching options.reserve_text still wins.",
    "legacy-only-option":
        "Switch create_tables off, or switch sql_format to legacy. It only affects the "
        "legacy serialisation; modern always emits CREATE TABLE IF NOT EXISTS and never "
        "truncates, so the setting changes nothing about what is generated.",
    "proper-case-mangles":
        "Switch options.proper_case_states off to keep the words as typed. It reproduces "
        "Excel's Proper(), which upper-cases the first letter of every word and lowers "
        "the rest - so kWh becomes Kwh, pH becomes Ph and PWM becomes Pwm, and the "
        "operator reads the mangled form. Off means the casing you wrote is what ships.",
    "decimals-overwritten":
        "Switch options.override_decimal off to keep the decimals you typed. On, the "
        "unit table's value replaces them wherever the unit carries one - three units do "
        "(Pa, ppm and m3/h, all zero), so this quietly rounds those rows to whole "
        "numbers and leaves every other row alone.",
    "menu-too-long":
        "Shorten it to ten characters. iw_par_*_param.menu is varchar(10), so MySQL "
        "truncates anything longer on insert without an error - the menu path then "
        "points somewhere that does not exist, and nothing in the script says so.",
    "element-id-too-long":
        "Shorten the group name, or set a shorter element_id on the row. "
        "iw_par_*_param.element_id is varchar(100) and it is the key the param and set "
        "rows join on: MySQL truncates silently, and two ids that differ only past "
        "character 100 become one row that overwrites the other.",
    "scale-without-decimals":
        "Set decimals to match the scale - x0.1 gives 1, x0.01 gives 2. The format "
        "string is built from decimals alone, so a scaled value with none displays "
        "rounded to whole numbers: 21.4 degrees reads as 21, and the scaling looks "
        "broken rather than unformatted.",
}

# The swap suffix drifting into the raw type - `I_Hold_U16R_N` for `I_Hold_U16_R` - is
# not a typo a fuzzy match ranks first: difflib puts three wrong keys ahead of the right
# one. It is also the single most expensive datatype error on record (docs/11), so it
# gets a rule of its own before the general search.
_FUSED_SWAP = re.compile(r"(.+?)([NRW])_([NRW])")


def _suggest(bad: str, pool) -> str | None:
    """A key from `pool` the author probably meant, or None.

    Deliberately conservative: one suggestion, not a list. A wrong suggestion that
    looks confident is worse than none, because the fix is a register-level decision
    and the reader is being asked to check it, not to accept it.
    """
    if not bad:
        return None
    fused = _FUSED_SWAP.fullmatch(bad)
    if fused:
        moved = f"{fused.group(1)}_{fused.group(2)}"
        if moved in pool:
            return moved
    names = list(pool)
    hit = difflib.get_close_matches(bad, names, n=1, cutoff=0.6)
    if hit:
        return hit[0]
    folded = {n.casefold(): n for n in names}       # lookups fold case; spelling may not
    return folded.get(bad.casefold())


def _top_bit(bit: int | str) -> int | None:
    """Highest bit index an authored bit value touches ('5#4' = bits 5..8).

    None when the value is not a well-formed bit - the range check below already
    reports those, and one row should not collect two errors for one mistake.
    """
    if isinstance(bit, int):
        return bit if 0 <= bit <= 31 else None
    m = re.fullmatch(r"(\d+)#(\d+)", bit) if isinstance(bit, str) else None
    if m is None:
        return None
    return int(m.group(1)) + max(int(m.group(2)), 1) - 1


def _finding(code: str, message: str, point: int | None = None,
             addr: int | None = None, suggestion: str | None = None,
             points: tuple[int, ...] = (), addrs: tuple[int, ...] = ()) -> Finding:
    return Finding(code=code, message=message, advice=ADVICE[code], point=point,
                   addr=addr, suggestion=suggestion, points=points, addrs=addrs)


def _datatype_errors(project: Project) -> list[str]:
    """Rules on the project's own datatype rows that must stop generation.

    The shipped table is the authority: a project adds keys and never redefines one,
    because Excel's VLOOKUP takes the first match and modbusgen's _FoldDict is
    first-writer-wins. A redefinition would therefore not even take effect - it would
    only make one name mean two things across two files.
    """
    from .tables import default_tables

    found: list[Finding] = []
    shipped = default_tables().datatypes
    seen: dict[str, str] = {}
    for name, row in project.datatypes.items():
        where = f"datatypes.{name}"
        if not DATATYPE_NAME.fullmatch(name):
            found.append(_finding(
                "datatype-name-illegal",
                f"{where}: a datatype name takes letters, digits and underscore only"))
        first = seen.get(name.casefold())
        if first is not None:
            found.append(_finding(
                "datatype-name-case-duplicate",
                f"{where}: differs only in case from '{first}', and lookups fold case"))
        seen[name.casefold()] = name
        if name in shipped and any(getattr(row, f) != getattr(shipped[name], f)
                                   for f in DATATYPE_FIELDS):
            found.append(_finding(
                "datatype-redefines-shipped",
                f"{where}: already in data/tables/datatypes.csv with a different "
                f"definition, and a project must not redefine a shipped datatype - "
                f"rename this row"))
        # The four fields that become the driver's own configuration string. A project
        # datatype is the one place a value the driver cannot parse can get in: the
        # shipped table is checked by the test suite, and the GUI's dialog offers
        # dropdowns, but a hand-written JSON carries whatever it says. Nothing caught
        # this before, so `read_func: 7` generated a driver id the driver silently
        # refuses - on both drivers, which is why it is an error and not a warning.
        # 0 accepts but is not advertised: it belongs to the shipped `Virt` row, where it
        # means "polls nothing", and offering it as a choice would read as a fifth block.
        for field, legal, what, offer in (
                ("read_func", DRIVER_READ_FUNCS, "read function",
                 "1 coils, 2 discrete inputs, 3 holding registers, 4 input registers"),
                ("write_func", DRIVER_WRITE_FUNCS, "write function",
                 "5 single coil, 6 single register, 15 multiple coils, 16 multiple "
                 "registers, or blank when the row is not writable")):
            value = str(getattr(row, field, "") or "")
            if value not in legal:
                found.append(_finding(
                    "datatype-func-unsupported",
                    f"{where}: {field} '{value}' is not a Modbus {what} the IWMAC "
                    f"driver has - use {offer} (docs/15 section 3)",
                    suggestion=_suggest(value, legal - {"", "0"})))
        for field in ("read_swap", "write_swap"):
            value = str(getattr(row, field, "") or "")
            if value not in DRIVER_SWAPS:
                found.append(_finding(
                    "datatype-swap-unsupported",
                    f"{where}: {field} '{value}' is not a word order the driver "
                    f"understands - N normal, R swap bytes, W swap words, and a "
                    f"datatype swaps one or the other but never both "
                    f"(docs/15 section 2)",
                    suggestion=_suggest(value, DRIVER_SWAPS - {""})))
    return found


def validate(project: Project, tables: Tables) -> list[str]:
    """Run after auto-fill/synthesis. Returns a list of error strings; empty = valid.

    The messages only. Callers that can act on more - the CLI, the web API, the GUI -
    should use `validate_detailed`, which carries the code, the address, the advice and
    a suggestion alongside each message.
    """
    return [f.message for f in validate_detailed(project, tables)]


def validate_detailed(project: Project, tables: Tables) -> list[Finding]:
    """Run after auto-fill/synthesis. Returns findings; empty = valid."""
    errors: list[Finding] = _datatype_errors(project)
    # Before the rows, because it is the one field that changes what the row checks below
    # are allowed to conclude. Unstated is legal - most files predate the field - but a
    # third spelling is not: it would read as unstated and silently take the delivery
    # warnings back to "confirm before shipping" while the file looks as though it said.
    if project.driver and project.driver not in DRIVERS:
        errors.append(_finding(
            "driver-unknown",
            f"driver '{project.driver}' is not an IWMAC Modbus driver - "
            f"use {' or '.join(DRIVERS)}, or leave it out",
            suggestion=_suggest(project.driver, DRIVERS)))
    if not TABLE_NAME.fullmatch(str(project.table or "")):
        errors.append(_finding(
            "table-name-illegal",
            f"table '{project.table}' takes lowercase letters, digits and underscore "
            f"only - it is written straight into `iw_par_<name>_param`"))

    # The transport, and the address on it. Both are project-level facts the point loop
    # below never sees, and both are silently answered rather than refused when wrong.
    s = project.system
    if s:
        mode = str(s.comm.mode or "").strip()
        if mode not in COMM_MODES:
            errors.append(_finding(
                "comm-mode-unknown",
                f"system.comm.mode '{mode}' is not a transport the driver has - use "
                f"{' or '.join(sorted(COMM_MODES))}. Anything but rtu is written as TCP",
                suggestion=_suggest(mode.lower(), COMM_MODES)))
        # effective_units() is what actually reaches iw_sys_plant_units - the unit_list
        # when there is one, the single-unit shorthand otherwise - so it is the right
        # thing to range-check rather than the raw fields.
        if s.units:
            for u in s.effective_units():
                addr = str(u.driver_addr or "").strip()
                n = int(addr) if addr.lstrip("-").isdigit() else None
                if n is None or not (SLAVE_MIN <= n <= SLAVE_MAX):
                    where = f" (unit '{u.unit_id}')" if u.unit_id else ""
                    errors.append(_finding(
                        "slave-address-range",
                        f"driver_addr '{addr}'{where} is not a Modbus slave address - "
                        f"it must be {SLAVE_MIN} to {SLAVE_MAX}"))

    # The register the driver actually puts on the wire, which is the printed address
    # less one when subtract_one is on. Two bytes, so 65535 is the end of the space; a
    # number past it is almost always an unstripped 4xxxx/3xxxxx table prefix.
    for i, p in enumerate(project.points, start=1):
        if not isinstance(p.addr, int):
            continue                                    # addr-invalid owns that
        wire = p.addr - 1 if project.options.subtract_one else p.addr
        if wire > ADDR_MAX:
            errors.append(_finding(
                "addr-too-high",
                f"point {i} (addr {p.addr}): the driver would poll register {wire}, past "
                f"the last one a Modbus request can address ({ADDR_MAX})",
                point=i, addr=p.addr))

    # Capability gaps become errors once the project says modbus.php: the feature is
    # absent there, so the delivery is wrong rather than possibly wrong. The same rows
    # come back from _driver_gaps as warnings while the driver is unstated.
    errors.extend(_driver_gaps(project, tables)[0])
    o = project.options
    group_names = {g.name for g in project.groups}
    seen_driver: dict[str, int] = {}
    seen_element: dict[str, int] = {}
    online_count = 0
    mothers: set[tuple[str, int]] = set()
    mother_word: dict[tuple[str, int], tuple[int, str]] = {}   # -> (bits, datatype)
    bit_rows: list[tuple[int, str, str, int, int | str]] = []

    for i, p in enumerate(project.points, start=1):
        # the index counts synthesized rows and so can name one nobody wrote; the
        # address is in the file the author is editing, so it travels with every finding
        label = p.text or p.datatype or "unnamed"
        addr = p.addr if isinstance(p.addr, int) else None
        where = (f"point {i} ({label}, addr {p.addr})" if addr is not None
                 else f"point {i} ({label})")
        here = dict(point=i, addr=addr)

        # counted before the datatype guard below: `online` is a flag, not a decoding
        # question, and a row skipped for a bad datatype used to make the project look
        # as though nothing was marked at all - one mistake reported as two
        if p.online:
            online_count += 1

        dt = tables.datatypes.get(p.datatype)
        if not p.datatype:
            errors.append(_finding("datatype-missing", f"{where}: datatype missing",
                                   **here))
            continue
        if dt is None:
            near = _suggest(p.datatype, tables.datatypes)
            errors.append(_finding(
                "datatype-unknown",
                f"{where}: datatype '{p.datatype}' not in data/tables/datatypes.csv"
                + (f" - did you mean '{near}'?" if near else ""),
                suggestion=near, **here))
            continue

        if not p.group:
            errors.append(_finding("group-missing", f"{where}: group missing", **here))
        elif p.group not in group_names:
            near = _suggest(p.group, group_names)
            errors.append(_finding(
                "group-unknown",
                f"{where}: group '{p.group}' has no alias in 'groups'"
                + (f" - did you mean '{near}'?" if near else ""),
                suggestion=near, **here))

        if not isinstance(p.addr, int) or p.addr < 0:
            errors.append(_finding("addr-invalid",
                                   f"{where}: addr must be a non-negative integer",
                                   **here))
            continue
        if o.subtract_one and p.addr - 1 < 0:
            errors.append(_finding(
                "addr-underflow",
                f"{where}: addr {p.addr} with subtract_one would go below 0", **here))

        # 32-bit words (Danfoss alarm/status words etc.) address bits up to 31;
        # "5#4" is the legacy nibble syntax (start bit # length)
        if p.bit is not None and not (
                (isinstance(p.bit, int) and 0 <= p.bit <= 31)
                or (isinstance(p.bit, str) and re.fullmatch(r"\d+#\d+", p.bit))):
            errors.append(_finding(
                "bit-invalid",
                f"{where}: bit must be 0..31 or nibble syntax like '5#4'", **here))
        if p.bit is not None and dt.read_func not in ("3", "4"):
            errors.append(_finding(
                "bit-needs-register",
                f"{where}: bit addressing needs a register datatype "
                f"(read function 3/4), not '{p.datatype}'", **here))

        if p.rw not in VALID_RW:
            errors.append(_finding(
                "rw-invalid",
                f"{where}: rw must be one of {', '.join(sorted(VALID_RW))}", **here))
        # bit rows write through their word - no per-bit write function needed
        if p.rw in ("rw", "vrw") and dt.write_func == "" and p.bit is None:
            errors.append(_finding(
                "rw-not-writable",
                f"{where}: datatype '{p.datatype}' has no write function; "
                f"rw is impossible", **here))

        if p.alarm is not None and p.alarm not in VALID_ALARM:
            errors.append(_finding(
                "alarm-invalid",
                f"{where}: alarm must be one of {', '.join(sorted(VALID_ALARM))}",
                **here))

        if p.scale and p.scale not in tables.scaling:
            near = _suggest(p.scale, tables.scaling)
            errors.append(_finding(
                "scale-unknown",
                f"{where}: scale '{p.scale}' not in data/tables/scaling.csv"
                + (f" - did you mean '{near}'?" if near else ""),
                suggestion=near, **here))

        if p.decimals is not None and p.decimals not in (0, 1, 2, 3):
            errors.append(_finding("decimals-range", f"{where}: decimals must be 0..3",
                                   **here))

        if p.statetext is not None and p.statetext not in project.statetexts:
            errors.append(_finding(
                "statetext-unknown",
                f"{where}: statetext {p.statetext} not defined in 'statetexts'", **here))

        if p.update_freq is not None and p.update_freq not in (
                "fast", "norm", "slow", "once", "never"):
            errors.append(_finding(
                "update-freq-invalid",
                f"{where}: update_freq must be fast/norm/slow/once/never", **here))


        did = driver_id(p, project, tables)
        eid = p.element_id if p.element_id else f"{p.group}_{did}"
        if did in seen_driver:
            errors.append(_finding(
                "driver-id-duplicate",
                f"{where}: duplicate driver_id '{did}' (also point "
                f"{seen_driver[did]})", **here))
        else:
            seen_driver[did] = i
        if eid in seen_element:
            errors.append(_finding(
                "element-id-duplicate",
                f"{where}: duplicate element_id '{eid}' (also point "
                f"{seen_element[eid]})", **here))
        else:
            seen_element[eid] = i

        if p.bit is None:           # any row polling the word counts (Excel semantics)
            key = (dt.read_func, p.addr)
            mothers.add(key)
            bits = WORD_BITS.get(dt.raw_type)
            if bits and bits > mother_word.get(key, (0, ""))[0]:
                mother_word[key] = (bits, p.datatype)
            if p.is_motherword and att(p) != "r":
                errors.append(_finding("motherword-not-read-only",
                                       f"{where}: motherword must be read-only (rw: r)",
                                       **here))
        if p.bit is not None:
            bit_rows.append((i, where, dt.read_func, p.addr, p.bit))

    if o.require_motherwords:
        for i, _where, rf, addr, _bit in bit_rows:
            if (rf, addr) not in mothers:
                errors.append(_finding(
                    "motherword-missing",
                    f"point {i}: bit value at addr {addr} has no motherword row "
                    f"(same address, no bit, text 'Motherword')", point=i, addr=addr))

    # A bit is extracted from the word its motherword polls, so it cannot reach past that
    # word's width - and synthesized motherwords are 16-bit by design (rules.py).
    for i, where, rf, addr, bit in bit_rows:
        top = _top_bit(bit)
        bits, mother_dt = mother_word.get((rf, addr), (0, ""))
        if top is None or not bits or top < bits:
            continue
        errors.append(_finding(
            "bit-outside-motherword",
            f"{where}: bit {bit} is outside the {bits}-bit motherword at addr "
            f"{addr} ('{mother_dt}' covers bits 0..{bits - 1}) - bits above it "
            f"live in the register holding the high word, and finding which "
            f"register that is means fixing the 32-bit word order, which "
            f"modbusgen never guesses (docs/15): address the bit in that "
            f"register, or author this word as an explicit 32-bit point",
            point=i, addr=addr))

    if online_count == 0 and project.points:
        errors.append(_finding(
            "online-missing",
            "no point has online: true - at least one online-indication "
            "point is required (docs/06 item 6)"))

    dup_orders = {}
    for g in project.groups:
        dup_orders.setdefault(g.order, []).append(g.name)
    for order, names in dup_orders.items():
        if len(names) > 1:
            errors.append(_finding("group-order-clash",
                                   f"groups {names} share view order {order}"))

    return errors


def _datatype_warnings(project: Project) -> list[str]:
    """Things worth saying about a project's own datatypes that must not stop a list.

    The vocabulary check is deliberately soft. The GUI offers dropdowns and cannot
    create an off-vocabulary row; a real delivery can contain one, and refusing to
    validate it would leave that list with no route through the tool at all.
    """
    from .tables import default_tables

    warnings: list[Finding] = []
    shipped = default_tables().datatypes
    vocabulary = {f: {getattr(dt, f) for dt in shipped.values()}
                  for f in DATATYPE_FIELDS}
    used = {p.datatype.casefold() for p in project.points if p.datatype}
    for name, row in project.datatypes.items():
        where = f"warning: datatypes.{name}"
        if name in shipped:
            warnings.append(_finding(
                "project-datatype-also-shipped",
                f"{where}: also in the shared table, with the same definition - "
                f"harmless, and what a promoted row looks like"))
        for f in DATATYPE_FIELDS:
            value = getattr(row, f)
            if value not in vocabulary[f]:
                warnings.append(_finding(
                    "project-datatype-unknown-value",
                    f"{where}: {f} '{value}' appears in no shipped datatype, so nothing "
                    f"here can say the driver supports it (docs/15)",
                    suggestion=_suggest(value, vocabulary[f])))
        if name.casefold() not in used:
            warnings.append(_finding("project-datatype-unused",
                                     f"{where}: defined, but no point uses it"))
    return warnings


def _unit_warnings(project: Project, tables: Tables) -> list[Finding]:
    """A unit absent from data/tables/units.csv, one finding per point.

    DIVERGENCE from the Excel tool (reference/vba-src/generate_param_grp_set_work.bas
    lines 313-330; docs/04 "eng_unit (BK)"): Excel treats a unit outside its table as a
    warning - it writes the literal XL-ERROR into eng_unit, sets unit_flag_error, and
    still generates. modbusgen used to make this a hard error (unit-unknown); the
    owner's ruling is that a custom unit should ship into eng_unit exactly as typed
    instead (rules.py), which is strictly better than XL-ERROR, so it is a warning here
    too. Kept per-point rather than aggregated like the checks below it: two custom
    units on one project (x10min, C/bar) can need two different suggestions, or none,
    and one combined message could not carry either.
    """
    warnings: list[Finding] = []
    for i, p in enumerate(project.points, start=1):
        if not p.unit or p.unit in tables.units:
            continue
        label = p.text or p.datatype or "unnamed"
        addr = p.addr if isinstance(p.addr, int) else None
        where = (f"point {i} ({label}, addr {p.addr})" if addr is not None
                 else f"point {i} ({label})")
        near = _suggest(p.unit, tables.units)
        msg = (f"{where}: unit '{p.unit}' is not in data/tables/units.csv - it ships "
               f"as a custom eng_unit, exactly as typed")
        if near:
            msg += f" - did you mean '{near}'?"
        if len(p.unit) > 20:
            msg += (f" - and at {len(p.unit)} characters it is longer than the 20 "
                    f"the eng_unit column holds")
        warnings.append(_finding("unit-unknown", msg, point=i, addr=addr,
                                 suggestion=near))
    return warnings


def soft_checks(project: Project, tables: Tables) -> list[str]:
    """The warning sentences, as every caller of this has always received them."""
    return [w.message for w in soft_checks_detailed(project, tables)]


def soft_checks_detailed(project: Project, tables: Tables) -> list[Finding]:
    """Non-blocking quality warnings (fleet-common patterns the Excel tool tolerated):
    blank alias texts, bits without motherwords when require_motherwords is off, and
    what the project's own datatype rows are worth saying about.

    Findings rather than sentences, for the same reason the errors are: a warning that
    names rows only inside its own prose cannot be mapped back to the file - and those
    numbers count synthesized motherwords, so "points 1, 3" in a two-point project was
    not a typo, it was unusable. The whole set of rows travels in `points`/`addrs` now,
    not the first eight of it.
    """
    warnings: list[Finding] = _datatype_warnings(project)
    warnings.extend(_unit_warnings(project, tables))
    blank = [(i, p.addr) for i, p in enumerate(project.points, start=1)
             if not p.text and not p.is_motherword]
    if blank:
        # addresses in the sentence, indices in the field: the index counts synthesized
        # motherwords, so a two-point project used to be told about "points 1, 3" and
        # had no way to reach the second one. The address is in the file being edited;
        # the GUI still gets the indices, which it can map through point_rows
        where = [a for _i, a in blank if isinstance(a, int)]
        head = ", ".join(str(a) for a in where[:8])
        more = f" (+{len(where) - 8} more)" if len(where) > 8 else ""
        warnings.append(_finding(
            "alias-text-missing",
            f"warning: {len(blank)} point(s) without alias text (addr {head}{more})",
            points=tuple(i for i, _a in blank), addrs=tuple(where)))
    if not project.options.require_motherwords:
        mothers = set()
        for p in project.points:
            if p.bit is None:       # any row polling the word counts (Excel semantics)
                dt = tables.datatypes.get(p.datatype)
                if dt:
                    mothers.add((dt.read_func, p.addr))
        missing = set()
        for p in project.points:
            if p.bit is not None:
                dt = tables.datatypes.get(p.datatype)
                if dt and (dt.read_func, p.addr) not in mothers:
                    missing.add(p.addr)
        if missing:
            shown = ", ".join(str(a) for a in sorted(missing)[:8])
            more = f" (+{len(missing) - 8} more)" if len(missing) > 8 else ""
            warnings.append(_finding(
                "motherword-absent",
                f"warning: bit rows without motherword at addr {shown}{more} - the "
                f"Excel tool warned about this too; enable options.auto_motherwords or "
                f"add rows if the driver needs them",
                addrs=tuple(sorted(missing))))
    warnings.extend(_owner_warnings(project))
    warnings.extend(_sys_field_warnings(project))
    warnings.extend(_delivery_warnings(project, tables))
    warnings.extend(_dead_config_warnings(project, tables))
    return warnings


# Proper() upper-cases the first letter of each word and lowers the rest, so any capital
# that is not the first letter of its word is one this destroys: kWh, pH, PWM, m3/h.
def _proper(word: str) -> str:
    return " ".join(w[:1].upper() + w[1:].lower() for w in word.split(" "))


def _dead_config_warnings(project: Project, tables: Tables) -> list[Finding]:
    """Settings that make other settings do nothing, and two values the database cuts.

    A different failure from the delivery checks: nothing here is missing or wrong, it is
    written down and inert. The file says the ranges are recorded, the state list is
    attached, the row is inactive - and the generated script contains none of it, with
    nothing anywhere saying which option ate it.

    Every one was confirmed by generating the script both ways rather than read off the
    options table, and the narrowing on `legacy-only-option` came out of that: `truncate`
    defaults to true and `sql_format` defaults to modern, so a check on the pair fires on
    every project ever written. Only `create_tables`, whose default is false, carries any
    intent to warn about.
    """
    o = project.options
    out: list[Finding] = []
    pts = [p for p in project.points if not p.is_motherword]

    def rows(match):
        got = [(i, p.addr) for i, p in enumerate(project.points, start=1)
               if not p.is_motherword and match(p)]
        return (tuple(i for i, _a in got),
                tuple(a for _i, a in got if isinstance(a, int)),
                len(got))

    if o.alarms_to_alm and not o.auto_groups:
        out.append(_finding("alarms-to-alm-inert",
            "warning: options.alarms_to_alm is on but auto_groups is off, so it moves "
            "nothing - the regrouping only runs inside the auto_groups pass"))

    if o.sql_format == "modern" and o.create_tables:
        out.append(_finding("legacy-only-option",
            "warning: options.create_tables is on with sql_format modern, which ignores "
            "it - modern always emits CREATE TABLE IF NOT EXISTS"))

    if not o.include_minmax:
        idx, addrs, n = rows(lambda p: p.range_min is not None or p.range_max is not None)
        if n:
            out.append(_finding("ranges-dropped",
                f"warning: {n} point(s) carry an engineering range and "
                f"options.include_minmax is off, so the columns are written blank",
                points=idx, addrs=addrs))

    if not o.use_json:
        idx, addrs, n = rows(lambda p: p.statetext is not None)
        if n:
            out.append(_finding("statetexts-dropped",
                f"warning: {n} point(s) reference a state list and options.use_json is "
                f"off, so no format_extra is emitted for any of them",
                points=idx, addrs=addrs))

    for flag, field, label in (("use_tag", "tag", "tag"),
                               ("use_system_no", "system_no", "system_no"),
                               ("use_extra", "extra", "extra")):
        if getattr(o, flag):
            continue
        idx, addrs, n = rows(lambda p, f=field: bool(getattr(p, f)))
        if n:
            out.append(_finding("alias-part-dropped",
                f"warning: {n} point(s) carry a {label} and options.{flag} is off, so it "
                f"is left out of the alias the operator reads",
                points=idx, addrs=addrs))

    # The mirror of decimals-overwritten: an option that replaces data you wrote rather
    # than dropping it. statetext_fields returns the flattened list as extra_override, so
    # a hand-written extra on a point with a state list is gone from the alias - and the
    # alias is the only place it ever showed. Gated on use_json, which is the master
    # switch statetext_fields returns early on.
    if o.statetext_in_alias and o.use_json:
        idx, addrs, n = rows(lambda p: p.statetext is not None and bool(p.extra))
        if n:
            out.append(_finding("statetext-overwrites-extra",
                f"warning: {n} point(s) carry both an extra and a state list, and "
                f"options.statetext_in_alias is on, so the flattened list replaces the "
                f"extra that was written",
                points=idx, addrs=addrs))

    if o.statetext_only_rw:
        idx, addrs, n = rows(lambda p: p.statetext is not None and p.rw in ("r", "vr"))
        if n:
            out.append(_finding("statetext-only-rw-drops",
                f"warning: {n} read-only point(s) reference a state list and "
                f"options.statetext_only_rw is on, so those emit no state text",
                points=idx, addrs=addrs))

    if o.force_active:
        idx, addrs, n = rows(lambda p: p.active == 0)
        if n:
            out.append(_finding("active-ignored",
                f"warning: {n} point(s) are marked active 0 and options.force_active is "
                f"on, so they are written active anyway",
                points=idx, addrs=addrs))

    if o.proper_case_states:
        mangled = sorted({w for states in project.statetexts.values()
                          for w in states.values() if w and _proper(w) != w})
        if mangled:
            shown = ", ".join(f"{w} -> {_proper(w)}" for w in mangled[:4])
            more = f" (+{len(mangled) - 4} more)" if len(mangled) > 4 else ""
            out.append(_finding("proper-case-mangles",
                f"warning: options.proper_case_states will re-case {len(mangled)} state "
                f"word(s): {shown}{more}"))

    if o.override_decimal:
        def overwritten(p):
            u = tables.units.get(p.unit) if p.unit else None
            table_dec = getattr(u, "decimals", "") if u else ""
            return bool(str(table_dec).strip()) and p.decimals is not None \
                and str(table_dec).strip() != str(p.decimals)
        idx, addrs, n = rows(overwritten)
        if n:
            out.append(_finding("decimals-overwritten",
                f"warning: options.override_decimal replaces the decimals typed on "
                f"{n} point(s) with the unit table's value", points=idx, addrs=addrs))

    # Two columns the database cuts without complaining. MENU_MAX/ELEMENT_ID_MAX mirror
    # the CREATE TABLE in sqlout; a truncated element_id can collide with another row's.
    idx, addrs, n = rows(lambda p: p.menu and len(str(p.menu)) > MENU_MAX)
    if n:
        out.append(_finding("menu-too-long",
            f"warning: {n} point(s) have a menu longer than {MENU_MAX} characters - "
            f"MySQL truncates the column on insert", points=idx, addrs=addrs))

    def long_eid(p):
        if p.element_id:
            return len(str(p.element_id)) > ELEMENT_ID_MAX
        dt = tables.datatypes.get(p.datatype)
        if not dt or p.addr is None:
            return False
        addr = p.addr - 1 if project.options.subtract_one else p.addr
        did = f"0_{dt.read_func}_{addr}" + (f".{p.bit}" if p.bit is not None else "")
        return len(f"{p.group}_{did}") > ELEMENT_ID_MAX
    idx, addrs, n = rows(long_eid)
    if n:
        out.append(_finding("element-id-too-long",
            f"warning: {n} point(s) build an element_id longer than {ELEMENT_ID_MAX} "
            f"characters - MySQL truncates it, and two truncated to the same value "
            f"become one row", points=idx, addrs=addrs))
    return out


def scale_decimals(key: str) -> int | None:
    """Decimals a scaling key implies, or None when it implies none.

    The multiplier is the key itself - `x0.1` means times 0.1 - and NOT the table's
    `scale` column, which is 1 on all but one row. A whole multiplier cannot produce a
    fractional value, so x1, x10, x100 and the fleet's x65 and x0036 need no decimals and
    must not be warned about: the first version of this check counted every scaled row
    and fired on 112 points whose scale was x1. Keys that are not multipliers at all
    (INV, pa) are out of scope for the same reason.
    """
    m = re.fullmatch(r"x(\d*\.?\d+)", str(key or "").strip())
    if not m:
        return None
    try:
        value = float(m.group(1))
    except ValueError:
        return None
    if value == int(value):
        return None                      # whole multiplier - nothing to round away
    frac = m.group(1).split(".", 1)[1] if "." in m.group(1) else ""
    return len(frac) or None


def _driver_gaps(project: Project, tables: Tables) -> tuple[list[Finding], list[Finding]]:
    """Every DRIVER_CAPS row against the project's points, as (errors, warnings).

    Both lists are always returned and exactly one of them is ever non-empty per row,
    because the severity is a function of `driver` alone:

    * unstated - warnings. Nothing is known, so nothing can be concluded; this is what
      the checks were before the field existed.
    * ``mb.exe`` - neither. Every row here is supported there, and a warning standing on
      a correct list is the one that teaches people to scroll past the next.
    * ``modbus.php`` - errors. The capability is absent, so the list is wrong rather than
      possibly wrong, and generating it produces a delivery that fails silently on the
      bus. That is what an error is for.

    A spelling that is neither driver counts as unstated: it is already the error
    ``driver-unknown``, and a file that looks as though it answered must not be treated
    as though it had.
    """
    errors: list[Finding] = []
    warnings: list[Finding] = []
    if project.driver == "mb.exe":
        return errors, warnings
    php = project.driver == "modbus.php"

    for warn_code, error_code, hits, unstated_msg, php_msg in DRIVER_CAPS:
        got = []
        for i, p in enumerate(project.points, start=1):
            dt = tables.datatypes.get(p.datatype)
            if dt and hits(p, dt):                  # an unknown key is already an error
                got.append((i, p.addr))
        if not got:
            continue
        idx = tuple(i for i, _a in got)
        addrs = tuple(a for _i, a in got if isinstance(a, int))
        if php:
            errors.append(_finding(error_code, php_msg.format(n=len(got)),
                                   points=idx, addrs=addrs))
        else:
            warnings.append(_finding(warn_code, "warning: " + unstated_msg.format(n=len(got)),
                                     points=idx, addrs=addrs))
    return errors, warnings


def _encodable(ch: str, encoding: str) -> bool:
    """Whether one character survives the file's output encoding.

    Asked per character rather than per string so the message can name what is wrong:
    "3 point(s) carry characters cp1252 cannot write" is a shrug, and "'‑'
    (U+2011)" is something to search the file for.
    """
    try:
        ch.encode(encoding or "cp1252")
        return True
    except (UnicodeEncodeError, LookupError):
        return False


def _as_number(v):
    """A range value as a float, or None when it is not one.

    range_min/range_max are free text: the fleet writes plain integers, but a document
    can print "-40.0" or a comma decimal, and a value that is neither is left alone
    rather than guessed at.
    """
    if v is None:
        return None
    try:
        return float(str(v).strip().replace(",", "."))
    except (TypeError, ValueError):
        return None


def _delivery_warnings(project: Project, tables: Tables) -> list[Finding]:
    """Checks on what the project would ship, rather than on whether it is well formed.

    Every one of these generates cleanly today. They are warnings because each has a
    legitimate reading - a half-filled comm block on a project still being written, a
    plant number the author is about to type - and because none of them can make the
    param rows wrong. What they have in common is that the cost lands somewhere the
    validator never looks: in iw_sys_plant_settings, in the operator's menu, on the bus.
    """
    out: list[Finding] = []
    s = project.system

    # 1. The comm block that generates a placeholder. sqlout writes XXX.XXX.XXX.XXX for
    #    a missing IP and an empty comm_port for a missing serial port, and both import.
    if s and s.settings:
        c = s.comm
        if c.mode == "tcp" and not str(c.ip or "").strip():
            out.append(_finding("comm-incomplete",
                "warning: system.settings is on and comm.mode is tcp, but no comm.ip is "
                "set - the script will carry the literal XXX.XXX.XXX.XXX"))
        if c.mode == "rtu" and not str(c.com_port or "").strip():
            out.append(_finding("comm-incomplete",
                "warning: system.settings is on and comm.mode is rtu, but no "
                "comm.com_port is set - the script will carry an empty serial port"))

    # 2. No plant number. It reaches the file name and nothing else, which is why this
    #    is not an error - but import-sql cannot supply one, so it is easily forgotten.
    if not str(project.plant or "").strip():
        out.append(_finding("plant-missing",
            "warning: no plant number - the generated file will be named without one"))
    elif str(project.plant).strip() == PLACEHOLDER_PLANT:
        out.append(_finding("plant-is-a-placeholder",
            f"warning: the plant number is still {PLACEHOLDER_PLANT}, the example this "
            f"repository hands out - the script would be filed against a plant nobody "
            f"meant"))
    else:
        unsafe = sorted({c for c in str(project.plant) if c in FILENAME_UNSAFE})
        if unsafe:
            out.append(_finding("plant-not-filename-safe",
                f"warning: the plant number contains {' '.join(repr(c) for c in unsafe)},"
                f" which the generated file cannot carry in its name"))

    # No points at all (2026-09-02). Not an error: an empty list is a legal skeleton. But
    # it is also the one figure a file that lost its rows to a wrong container agrees
    # with, and every other check here is quiet on zero points - online-missing included,
    # deliberately - so without this line a validate run says OK about nothing.
    if not project.points:
        out.append(_finding("points-none",
            "warning: the project has no points - a legal skeleton, but nothing to "
            "generate; if the source document has rows, they are not in this file"))

    # 3, 4 and 5. Capabilities the driver decides, not the document. The matrix lives
    #    in DRIVER_CAPS and is evaluated once by _driver_gaps, which hands the warnings
    #    here and the errors to validate_detailed - the same rows at two levels of
    #    certainty, depending on whether the project has said which driver it targets.
    out.extend(_driver_gaps(project, tables)[1])

    lossy = [(i, p.addr) for i, p in enumerate(project.points, start=1)
             if (tables.datatypes.get(p.datatype) or None)
             and "64" in tables.datatypes[p.datatype].raw_type]
    if lossy:
        out.append(_finding("datatype-truncates",
            f"warning: {len(lossy)} point(s) use a 64-bit datatype - IWMAC truncates "
            f"those to 32 bits on save",
            points=tuple(i for i, _a in lossy),
            addrs=tuple(a for _i, a in lossy if isinstance(a, int))))

    # 6. A group folder the operator opens and finds unnamed. group-unknown covers a
    #    group with no entry at all; this is an entry whose alias is empty, which
    #    generates a group_alias row carrying an empty value rather than no row.
    nameless = [g.name for g in project.groups if not str(g.alias or "").strip()]
    if nameless:
        out.append(_finding("group-alias-blank",
            f"warning: group(s) {', '.join(nameless)} have no display alias, so the "
            f"operator's menu folder ships without a name"))

    # 7. An engineering range written the wrong way round. Only worth saying when the
    #    range actually ships - with include_minmax off, ranges-dropped owns the case.
    if project.options.include_minmax:
        upside_down = [(i, p.addr) for i, p in enumerate(project.points, start=1)
                       if not p.is_motherword
                       and _as_number(p.range_min) is not None
                       and _as_number(p.range_max) is not None
                       and _as_number(p.range_min) > _as_number(p.range_max)]
        if upside_down:
            out.append(_finding("range-inverted",
                f"warning: {len(upside_down)} point(s) have range_min above range_max, "
                f"and both are written into the param row exactly as given",
                points=tuple(i for i, _a in upside_down),
                addrs=tuple(a for _i, a in upside_down if isinstance(a, int))))

    # 8. Display formatting on a value that has no magnitude. `Digital IO` is exactly the
    #    eight single-bit datatypes - the six Coil_X/Digital_X rows and Bit_Hold and
    #    Bit_Input - so it does not catch a nibble, which is a small integer and may
    #    legitimately be scaled.
    dressed = [(i, p.addr) for i, p in enumerate(project.points, start=1)
               if not p.is_motherword
               and (tables.datatypes.get(p.datatype) or None)
               and tables.datatypes[p.datatype].application == "Digital IO"
               and (p.unit or p.scale or p.decimals is not None)]
    if dressed:
        out.append(_finding("bit-point-formatted",
            f"warning: {len(dressed)} single-bit point(s) carry a unit, scale or "
            f"decimals - a bit is on or off, so the display format reaches the database "
            f"and describes nothing",
            points=tuple(i for i, _a in dressed),
            addrs=tuple(a for _i, a in dressed if isinstance(a, int))))

    # 8a. Characters the output encoding cannot carry. sqlout writes the file in
    #     options.encoding - cp1252, because the IWMAC tables are latin1 - and the
    #     download path encodes with errors="replace", so anything outside it becomes a
    #     literal ? in the delivered script. The CLI uses errors="strict" and refuses,
    #     which means the two paths disagree about the same file; this check is what makes
    #     the loss visible in both, before generation rather than after.
    bad_chars: dict[str, None] = {}
    bad_points: list[tuple[int, object]] = []
    bad_where: list[str] = []

    def _scan(value, label, point=None):
        text = "" if value is None else str(value)
        lost = [c for c in text if not _encodable(c, project.options.encoding)]
        if not lost:
            return
        for c in lost:
            bad_chars[c] = None
        if point is not None:
            bad_points.append(point)
        elif label not in bad_where:
            bad_where.append(label)

    for i, p in enumerate(project.points, start=1):
        for field in ("text", "extra", "tag", "system_no", "menu", "element_id"):
            _scan(getattr(p, field, None), field, point=(i, p.addr))
    for g in project.groups:
        _scan(g.name, f"group '{g.name}'")
        _scan(g.alias, f"the alias of group '{g.name}'")
    for sid, states in project.statetexts.items():
        for number, word in states.items():
            _scan(word, f"state text {sid}:{number}")
    if project.system:
        sy = project.system
        for field in ("unit_id", "unit_name", "reg_type", "order_no", "owner"):
            _scan(getattr(sy, field, None), f"system.{field}")
        for u in sy.unit_list:
            _scan(u.unit_id, "a system.unit_list unit_id")
            _scan(u.unit_name, "a system.unit_list unit_name")

    if bad_chars:
        shown = " ".join(f"{c!r} (U+{ord(c):04X})" for c in list(bad_chars)[:6])
        more = f" +{len(bad_chars) - 6} more" if len(bad_chars) > 6 else ""
        seen = sorted({i for i, _a in bad_points})
        where = (f"{len(seen)} point(s)" if seen else "")
        if bad_where:
            where = ", ".join(filter(None, [where, "; ".join(bad_where[:3])]))
        out.append(_finding("text-not-encodable",
            f"warning: {project.options.encoding} cannot write {shown}{more}, found in "
            f"{where} - each becomes a literal ? in the generated script",
            points=tuple(seen),
            addrs=tuple(a for _i, a in bad_points if isinstance(a, int))))

    # 8b. The one magic string in the point model. `is_motherword` is `text ==
    #     "Motherword"`, so an authored point carrying that text is read as a synthesized
    #     word row by everything downstream - including the groups pass, which leaves it
    #     out of the operator's menu entirely while exclude_motherwords_from_groups is on.
    #     Synthesized rows are excluded from the check itself: those are the real ones.
    impostors = [(i, p.addr) for i, p in enumerate(project.points, start=1)
                 if p.is_motherword and not p.synthesized]
    if impostors:
        out.append(_finding("motherword-text-collision",
            f"warning: {len(impostors)} authored point(s) carry the alias text "
            f"'Motherword', so the tool reads them as synthesized word rows and leaves "
            f"them out of the operator's menu",
            points=tuple(i for i, _a in impostors),
            addrs=tuple(a for _i, a in impostors if isinstance(a, int))))

    # 9. An online indication that cannot indicate. `never` and `once` are the two
    #    frequencies that do not repeat, and the online point is what IWMAC watches to
    #    decide the device is answering (docs/16 section 16.10).
    stalled = [(i, p.addr) for i, p in enumerate(project.points, start=1)
               if p.online and str(p.update_freq or "").lower() in ("never", "once")]
    if stalled:
        out.append(_finding("online-never-polled",
            f"warning: {len(stalled)} point(s) are marked online but polled "
            f"'{str(project.points[stalled[0][0] - 1].update_freq).lower()}', so the "
            f"online indication never refreshes",
            points=tuple(i for i, _a in stalled),
            addrs=tuple(a for _i, a in stalled if isinstance(a, int))))

    # 10. One word on two numbers: the operator sees the same text for two device states,
    #     which is the one thing a state list exists to prevent. The same shape as
    #     alias-duplicate, one level down.
    doubled = []
    for sid, states in sorted(project.statetexts.items()):
        seen: dict[str, int] = {}
        for number, word in sorted(states.items()):
            key = str(word).strip().casefold()
            if not key:
                continue                     # a blank word is its own question
            if key in seen:
                doubled.append(f"{sid}: {seen[key]} and {number} are both '{word}'")
            else:
                seen[key] = number
    if doubled:
        out.append(_finding("statetext-word-duplicate",
            f"warning: {len(doubled)} state text(s) repeat a word - "
            f"{'; '.join(doubled[:4])}{' …' if len(doubled) > 4 else ''}"))

    # 5 and 6. Defined and never used. The same shape as project-datatype-unused.
    used_states = {p.statetext for p in project.points if p.statetext is not None}
    spare = sorted(set(project.statetexts) - used_states)
    if spare:
        out.append(_finding("statetext-unused",
            f"warning: state text list(s) {', '.join(str(s) for s in spare)} are defined "
            f"but no point references them"))
    used_groups = {p.group for p in project.points if p.group}
    idle = [g.name for g in project.groups if g.name not in used_groups]
    if idle:
        out.append(_finding("group-unused",
            f"warning: group(s) {', '.join(idle)} are defined but hold no points"))

    # 7. Two rows the operator cannot tell apart. The whole alias, not just text: a
    #    shared text under different tags reads differently in the menu and is fine.
    seen: dict[tuple, list[tuple[int, object]]] = {}
    for i, p in enumerate(project.points, start=1):
        if p.is_motherword or not p.text:
            continue                                    # blank text has its own warning
        seen.setdefault((str(p.system_no or ""), str(p.tag or ""), p.text), []).append((i, p.addr))
    clashes = [rows for rows in seen.values() if len(rows) > 1]
    if clashes:
        flat = [r for rows in clashes for r in rows]
        where = [a for _i, a in flat if isinstance(a, int)]
        more = f" (+{len(where) - 8} more)" if len(where) > 8 else ""
        out.append(_finding("alias-duplicate",
            f"warning: {len(clashes)} alias(es) appear on more than one point "
            f"(addr {', '.join(str(a) for a in where[:8])}{more}) - the operator sees "
            f"identical lines",
            points=tuple(i for i, _a in flat),
            addrs=tuple(a for _i, a in flat if isinstance(a, int))))

    # 8. Scaled, and displayed rounded to whole numbers because decimals is blank.
    unscaled = [(i, p.addr) for i, p in enumerate(project.points, start=1)
                if p.scale and tables.scaling.get(p.scale) and p.decimals is None
                and not p.is_motherword and scale_decimals(p.scale)]
    if unscaled:
        out.append(_finding("scale-without-decimals",
            f"warning: {len(unscaled)} scaled point(s) have no decimals - the display "
            f"rounds them to whole numbers",
            points=tuple(i for i, _a in unscaled),
            addrs=tuple(a for _i, a in unscaled if isinstance(a, int))))
    return out


def _sys_field_warnings(project: Project) -> list[Finding]:
    """The two rows of docs/16 section 16.7 that nothing enforced.

    The section is called "Field constraints the generator does not enforce", and it
    listed four: the table name, these two, and the owner. The table name is an error
    (it reaches a backticked SQL identifier), the owner is two warnings, and these were
    simply not looked at. A space here does not break the script - it lands in a column
    IWMAC says cannot hold one, which is the platform's rule to state and not this
    repository's to prove.
    """
    out: list[Finding] = []
    s = project.system
    if not s:
        return out
    for field in ("reg_type", "order_no"):
        value = str(getattr(s, field, "") or "")
        if " " in value:
            out.append(_finding("sys-field-space",
                f"warning: system.{field} '{value}' contains a space, which IWMAC does "
                f"not accept in that field (docs/16 section 16.7)"))
    return out


def _owner_warnings(project: Project) -> list[str]:
    """`system.owner` becomes `driver_type` in `iw_sys_plant_units`, and the IWMAC side
    documents it as max 10 characters, capitals and digits only (docs/16 §16.7).

    A warning rather than an error, because the fleet does not agree with the rule and
    this repository cannot settle which is right: `KAMSTRUP801` is eleven characters and
    comes from a real Kamstrup MULTICAL delivery, and `mb_01` is lowercase with an
    underscore. Either the limit is not 10, or that delivery was truncated somewhere
    downstream without anyone noticing - and a hard error would reject a list the house
    has already shipped. Say it and generate anyway; promote it once somebody knows.
    """
    owner = (project.system.owner if project.system else "") or ""
    if not owner:
        return []
    out = []
    if len(owner) > OWNER_MAX:
        out.append(_finding(
            "owner-too-long",
            f"warning: system.owner {owner!r} is {len(owner)} characters - "
            f"IWMAC documents a maximum of {OWNER_MAX} for driver_type "
            f"(docs/16). A real delivery carries an 11-character owner, so this "
            f"is unconfirmed rather than certainly wrong - check what arrived in "
            f"iw_sys_plant_units before shipping it"))
    if not OWNER_CHARS.fullmatch(owner):
        out.append(_finding(
            "owner-charset",
            f"warning: system.owner {owner!r} is not capitals and digits only - "
            f"IWMAC documents that for driver_type (docs/16); the fleet also "
            f"carries lowercase owners, so confirm rather than assume"))
    return out
