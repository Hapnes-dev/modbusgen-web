"""Pre-generation validation: the checklist of docs/06-validation-and-checks.md 6.5,
turned into hard gates. Every finding carries the point index (1-based, as listed in
the project file after motherword synthesis) so the user can fix the YAML directly.
"""
from __future__ import annotations

import re

from .model import Project
from .rules import att, driver_id
from .tables import Tables

VALID_RW = {"r", "rw", "vr", "vrw"}
VALID_ALARM = {"A", "B", "C", "N"}


def validate(project: Project, tables: Tables) -> list[str]:
    """Run after auto-fill/synthesis. Returns a list of error strings; empty = valid."""
    errors: list[str] = []
    o = project.options
    group_names = {g.name for g in project.groups}
    seen_driver: dict[str, int] = {}
    seen_element: dict[str, int] = {}
    online_count = 0
    mothers: set[tuple[str, int]] = set()
    bit_rows: list[tuple[int, str, int]] = []

    for i, p in enumerate(project.points, start=1):
        where = f"point {i} ({p.text or p.datatype or 'unnamed'})"

        dt = tables.datatypes.get(p.datatype)
        if not p.datatype:
            errors.append(f"{where}: datatype missing")
            continue
        if dt is None:
            errors.append(f"{where}: datatype '{p.datatype}' not in data/tables/datatypes.csv")
            continue

        if not p.group:
            errors.append(f"{where}: group missing")
        elif p.group not in group_names:
            errors.append(f"{where}: group '{p.group}' has no alias in 'groups'")

        if not isinstance(p.addr, int) or p.addr < 0:
            errors.append(f"{where}: addr must be a non-negative integer")
            continue
        if o.subtract_one and p.addr - 1 < 0:
            errors.append(f"{where}: addr {p.addr} with subtract_one would go below 0")

        # 32-bit words (Danfoss alarm/status words etc.) address bits up to 31;
        # "5#4" is the legacy nibble syntax (start bit # length)
        if p.bit is not None and not (
                (isinstance(p.bit, int) and 0 <= p.bit <= 31)
                or (isinstance(p.bit, str) and re.fullmatch(r"\d+#\d+", p.bit))):
            errors.append(f"{where}: bit must be 0..31 or nibble syntax like '5#4'")
        if p.bit is not None and dt.read_func not in ("3", "4"):
            errors.append(f"{where}: bit addressing needs a register datatype "
                          f"(read function 3/4), not '{p.datatype}'")

        if p.rw not in VALID_RW:
            errors.append(f"{where}: rw must be one of {sorted(VALID_RW)}")
        if p.rw in ("rw", "vrw") and dt.write_func == "":
            errors.append(f"{where}: datatype '{p.datatype}' has no write function; "
                          f"rw is impossible")

        if p.alarm is not None and p.alarm not in VALID_ALARM:
            errors.append(f"{where}: alarm must be one of {sorted(VALID_ALARM)}")

        if p.unit and p.unit not in tables.units:
            errors.append(f"{where}: unit '{p.unit}' not in data/tables/units.csv")
        if p.scale and p.scale not in tables.scaling:
            errors.append(f"{where}: scale '{p.scale}' not in data/tables/scaling.csv")

        if p.decimals is not None and p.decimals not in (0, 1, 2, 3):
            errors.append(f"{where}: decimals must be 0..3")

        if p.statetext is not None and p.statetext not in project.statetexts:
            errors.append(f"{where}: statetext {p.statetext} not defined in 'statetexts'")

        if p.update_freq is not None and p.update_freq not in (
                "fast", "norm", "slow", "once", "never"):
            errors.append(f"{where}: update_freq must be fast/norm/slow/once/never")


        did = driver_id(p, project, tables)
        eid = p.element_id if p.element_id else f"{p.group}_{did}"
        if did in seen_driver:
            errors.append(f"{where}: duplicate driver_id '{did}' (also point {seen_driver[did]})")
        else:
            seen_driver[did] = i
        if eid in seen_element:
            errors.append(f"{where}: duplicate element_id '{eid}' (also point {seen_element[eid]})")
        else:
            seen_element[eid] = i

        if p.online:
            online_count += 1
        if p.bit is None and p.is_motherword:
            mothers.add((dt.read_func, p.addr))
            if att(p) != "r":
                errors.append(f"{where}: motherword must be read-only (rw: r)")
        if p.bit is not None:
            bit_rows.append((i, dt.read_func, p.addr))

    if o.require_motherwords:
        for i, rf, addr in bit_rows:
            if (rf, addr) not in mothers:
                errors.append(f"point {i}: bit value at addr {addr} has no motherword "
                              f"row (same address, no bit, text 'Motherword')")

    if online_count == 0 and project.points:
        errors.append("no point has online: true - at least one online-indication "
                      "point is required (docs/06 item 6)")

    dup_orders = {}
    for g in project.groups:
        dup_orders.setdefault(g.order, []).append(g.name)
    for order, names in dup_orders.items():
        if len(names) > 1:
            errors.append(f"groups {names} share view order {order}")

    return errors


def soft_checks(project: Project, tables: Tables) -> list[str]:
    """Non-blocking quality warnings (fleet-common patterns the Excel tool tolerated):
    blank alias texts, and bits without motherwords when require_motherwords is off."""
    warnings: list[str] = []
    no_text = [i for i, p in enumerate(project.points, start=1)
               if not p.text and not p.is_motherword]
    if no_text:
        head = ", ".join(str(i) for i in no_text[:8])
        more = f" (+{len(no_text) - 8} more)" if len(no_text) > 8 else ""
        warnings.append(f"warning: {len(no_text)} point(s) without alias text "
                        f"(points {head}{more})")
    if not project.options.require_motherwords:
        mothers = set()
        for p in project.points:
            if p.bit is None and p.is_motherword:
                dt = tables.datatypes.get(p.datatype)
                if dt:
                    mothers.add((dt.read_func, p.addr))
        missing = set()
        for p in project.points:
            if p.bit is not None:
                dt = tables.datatypes.get(p.datatype)
                if dt and (dt.read_func, p.addr) not in mothers:
                    missing.add(p.addr)
        if missing:
            shown = ", ".join(str(a) for a in sorted(missing)[:8])
            more = f" (+{len(missing) - 8} more)" if len(missing) > 8 else ""
            warnings.append(f"warning: bit rows without motherword at addr {shown}"
                            f"{more} - the Excel tool warned about this too; enable "
                            f"options.auto_motherwords or add rows if the driver "
                            f"needs them")
    return warnings
