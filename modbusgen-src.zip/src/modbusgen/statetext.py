"""State-text serialization, matching Concat_json (docs/07-json-statetext.md).

The JSON is built by string concatenation on purpose: the Excel tool emits states in
numeric order with no spaces, and `format_extra` must match it byte for byte.
"""
from __future__ import annotations


def proper(word: str) -> str:
    """Excel WorksheetFunction.Proper: capitalize first letter of every word,
    lowercase the rest."""
    out = []
    prev_alpha = False
    for ch in word:
        if ch.isalpha():
            out.append(ch.lower() if prev_alpha else ch.upper())
            prev_alpha = True
        else:
            out.append(ch)
            prev_alpha = False
    return "".join(out)


def state_json(states: dict[int, str], proper_case: bool = True) -> str:
    parts = []
    for num in sorted(states):
        word = states[num]
        if word == "":
            continue
        if proper_case:
            word = proper(word)
        parts.append(f'"{num}":{{"t":"{word}"}}')
    return '{"rev":"1","type":"num","v":{' + ",".join(parts) + "}}"


def state_plain(states: dict[int, str], proper_case: bool = True) -> str:
    parts = []
    for num in sorted(states):
        word = states[num]
        if word == "":
            continue
        if proper_case:
            word = proper(word)
        parts.append(f"{num}={word}")
    return " ".join(parts)
