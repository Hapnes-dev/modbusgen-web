"""Project model: the YAML input file parsed into dataclasses.

Field names follow docs/02-inputs.md; every field maps to a Work-sheet column or a
setup-sheet cell of the original Excel tool. Unknown YAML keys are rejected so typos
fail loudly instead of being silently ignored.
"""
from __future__ import annotations

from dataclasses import dataclass, field, fields as dc_fields
from typing import Any

from .tables import Datatype


class ProjectError(ValueError):
    """Invalid project file content."""


# The two IWMAC Modbus driver implementations (docs/15 section 1). They are not
# equivalent, and the difference decides questions the vendor document cannot: mb.exe
# carries word swaps and FC16, modbus.php carries neither. Nothing in a project file
# recorded which one a plant runs until 2026-08-29, so every check that depends on it
# could only end in "confirm before shipping". An empty string means not stated, which
# is what every file written before that date says.
DRIVERS = ("mb.exe", "modbus.php")


def _take(d: dict, ctx: str, spec: dict[str, Any]) -> dict:
    unknown = set(d) - set(spec)
    if unknown:
        raise ProjectError(f"{ctx}: unknown key(s): {', '.join(sorted(unknown))}")
    out = {}
    for key, default in spec.items():
        out[key] = d.get(key, default)
    return out


@dataclass
class Options:
    # Protocol_Spesific_Setup / Main_Setup toggles (defaults = template defaults)
    subtract_one: bool = True            # Prot!B18
    truncate: bool = True                # Main!B23
    create_tables: bool = False          # Main!B25
    use_system_no: bool = True           # Main!B31
    use_tag: bool = True                 # Main!B27
    use_extra: bool = True               # Main!B35
    reserve_text: str = "Reserve."       # Main!B13 (+B14)
    force_active: bool = True            # Prot!B38
    include_minmax: bool = False         # Prot!B42
    use_json: bool = True                # Prot!B54 (master gate on state texts)
    statetext_only_rw: bool = False      # Prot!B58
    statetext_in_alias: bool = False     # Prot!B62
    override_decimal: bool = False       # Prot!B46 (fill decimals from the unit table)
    require_motherwords: bool = False    # hard-fail bits without motherword (soft warning otherwise)
    sql_format: str = "modern"           # "modern" = REPLACE INTO house style (2026 examples);
                                         # "legacy" = the Excel tool's single-line INSERTs
    exclude_motherwords_from_groups: bool = True  # Prot!B30
    auto_motherwords: bool = True        # new: synthesize motherword rows for bit points
    auto_groups: bool = False            # Prot!B22 (fill missing group from datatype default)
    alarms_to_alm: bool = False          # Prot!B26
    proper_case_states: bool = True      # Excel WorksheetFunction.Proper on state words
    encoding: str = "cp1252"             # SQL file encoding (IWMAC tables are latin1)


@dataclass
class Comm:
    mode: str = "tcp"                    # tcp | rtu       (Main!B10)
    ip: str = ""                         # Main!B69
    port: int = 502
    com_port: str = ""                   # Main!B66
    baudrate: int = 19200                # Main!B72 (a checkbox there: 9600/19200 only)
    parity: str = "even"                 # none | odd | even  (Main!E75)
    stop_bits: int = 1
    data_bits: int = 8


@dataclass
class UnitRow:
    """One iw_sys_plant_units row - real lists register several devices on one
    driver (e.g. Carel EVD 01..10 with driver_addr 0_1..0_10)."""
    unit_id: str = ""
    unit_name: str = ""
    driver_addr: str = ""                # combined with driver_addr_prefix
    view_order: int = 0


@dataclass
class System:
    """Optional iw_sys_* blocks (Main_Setup B42/B45 sections)."""
    units: bool = False                  # emit iw_sys_plant_units + iw_sys_order_no
    settings: bool = False               # emit iw_sys_processes + iw_sys_plant_settings
    unit_id: str = ""                    # Main!B48 (single-unit shorthand)
    unit_name: str = ""                  # Main!B51
    reg_type: str = ""                   # Main!B54
    order_no: str = ""                   # Main!B57
    owner: str = ""                      # Main!B60 (driver/settings owner)
    driver_addr: str = "1"               # Main!B63
    driver_addr_prefix: str = "1_"       # Main!C63/D63 ("1_" or "0_")
    view_order: int = 0                  # iw_sys_plant_units.view_order
    unit_list: list[UnitRow] = field(default_factory=list)
    comm: Comm = field(default_factory=Comm)

    def effective_units(self) -> list[UnitRow]:
        """unit_list when given, else the single-unit shorthand fields."""
        if self.unit_list:
            return self.unit_list
        return [UnitRow(self.unit_id, self.unit_name, str(self.driver_addr),
                        int(self.view_order or 0))]


@dataclass
class Group:
    name: str
    alias: str = ""
    order: int = 0                       # view_order of the group_alias row


@dataclass
class Point:
    group: str = ""
    datatype: str = ""
    addr: int | None = None
    bit: int | str | None = None         # Work!F; int 0..31 or nibble syntax "5#4"
    element_id: str | None = None        # Work!C override
    system_no: str | None = None         # Work!M
    tag: str | None = None               # Work!N
    text: str = ""                       # Work!P (Aliastext)
    extra: str | None = None             # Work!O (Tag_extra)
    alarm: str | None = None             # Work!R (A/B/C/N)
    unit: str | None = None              # Work!S
    scale: str | None = None             # Work!T
    rw: str = "r"                        # Work!U
    online: bool = False                 # Work!V
    active: int | None = None            # Work!W (None -> 1 unless forced)
    no_group: bool = False               # Work!X = "x"
    menu: str | None = None              # Work!AA
    decimals: int | None = None          # Work!AB
    range_min: str | None = None         # Work!AC
    range_max: str | None = None         # Work!AD
    statetext: int | None = None         # Work!AE (Json Type No)
    update_freq: str | None = None       # override: fast/norm/slow/once/never (None = derived)
    synthesized: bool = False            # internal: auto-created motherword

    @property
    def is_motherword(self) -> bool:
        return self.text == "Motherword"


@dataclass
class Project:
    table: str
    plant: str
    options: Options
    system: System | None
    groups: list[Group]
    statetexts: dict[int, dict[int, str]]
    points: list[Point]
    # Datatype rows the project defines for itself. Last and defaulted so that every
    # existing construction stays valid - a project that defines none is the norm, and
    # the order the file is written in is yamlio's business, not this dataclass's.
    datatypes: dict[str, Datatype] = field(default_factory=dict)
    # Which driver the plant runs, one of DRIVERS or "" for not stated. Defaulted for the
    # same reason as datatypes above; in the file it sits beside `plant`, since both are
    # facts about the target plant rather than generation switches. It reaches no SQL
    # column - it decides what validate.py can say about word order and 32-bit writes.
    # The house standard is mb.exe, but that lives in the GUI's New and in the authoring
    # instructions, never here: a file that says nothing means nobody said, so loading
    # one must not turn silence into a claim about the plant.
    driver: str = ""


def _bool(v, ctx):
    if isinstance(v, bool):
        return v
    raise ProjectError(f"{ctx}: expected true/false, got {v!r}")


def load_project(data: dict) -> Project:
    if not isinstance(data, dict):
        raise ProjectError("project file must be a YAML mapping")
    # Annotation, not project content: JSON files reference their contract with $schema
    # and carry the reader's briefing in _help (yamlio.HELP_BLOCK). Both are stripped
    # here rather than modelled, so nothing downstream can be made to depend on them -
    # a file that lost either still loads, and one that hand-edited _help still generates
    # the same SQL.
    data = {k: v for k, v in data.items() if k not in ("$schema", "_help")}
    top = _take(data, "project", {
        "table": None, "plant": None, "driver": "", "options": {}, "system": None,
        "groups": {}, "statetexts": {}, "datatypes": {}, "points": [],
    })
    if not top["table"]:
        raise ProjectError("'table' is required (names the iw_par_/iw_set_ tables)")
    if top["plant"] is None:
        raise ProjectError("'plant' is required (plant number, used in the file name)")

    opt_spec = {f.name: getattr(Options(), f.name) for f in dc_fields(Options)}
    options = Options(**_take(top["options"] or {}, "options", opt_spec))

    system = None
    if top["system"] is not None:
        sys_spec = {f.name: getattr(System(), f.name) for f in dc_fields(System)}
        raw = _take(top["system"] or {}, "system", sys_spec)
        comm_spec = {f.name: getattr(Comm(), f.name) for f in dc_fields(Comm)}
        raw["comm"] = Comm(**_take(raw["comm"] if isinstance(raw["comm"], dict) else {},
                                   "system.comm", comm_spec))
        unit_spec = {f.name: getattr(UnitRow(), f.name) for f in dc_fields(UnitRow)}
        rows = []
        for i, u in enumerate(raw["unit_list"] or [], start=1):
            if not isinstance(u, dict):
                raise ProjectError(f"system.unit_list[{i}]: expected a mapping")
            ur = _take(u, f"system.unit_list[{i}]", unit_spec)
            ur["driver_addr"] = str(ur["driver_addr"])
            ur["view_order"] = int(ur["view_order"] or 0)
            rows.append(UnitRow(**ur))
        raw["unit_list"] = rows
        system = System(**raw)

    groups: list[Group] = []
    raw_groups = top["groups"] or {}
    if not isinstance(raw_groups, dict):
        raise ProjectError("'groups' must be a mapping of name -> alias")
    for i, (name, val) in enumerate(raw_groups.items(), start=1):
        if isinstance(val, str):
            groups.append(Group(str(name), val, i))
        elif isinstance(val, dict):
            g = _take(val, f"groups.{name}", {"alias": "", "order": i})
            groups.append(Group(str(name), g["alias"], int(g["order"])))
        else:
            raise ProjectError(f"groups.{name}: expected alias string or mapping")

    statetexts: dict[int, dict[int, str]] = {}
    for sid, states in (top["statetexts"] or {}).items():
        if not isinstance(states, dict):
            raise ProjectError(f"statetexts.{sid}: expected mapping number -> word")
        statetexts[int(sid)] = {int(k): str(v) for k, v in states.items()}

    # Datatype rows of the project's own - the Modbus_Variables sheet, carried in the
    # file. Every field is required: a datatype missing its read function would build
    # driver ids like `0__100` and validate them, which is worse than refusing here.
    datatypes: dict[str, Datatype] = {}
    raw_datatypes = top["datatypes"] or {}
    if not isinstance(raw_datatypes, dict):
        raise ProjectError("'datatypes' must be a mapping of name -> row")
    dt_fields = [f.name for f in dc_fields(Datatype) if f.name != "name"]
    for name, row in raw_datatypes.items():
        ctx = f"datatypes.{name}"
        if not isinstance(row, dict):
            raise ProjectError(f"{ctx}: expected a mapping of the nine column values")
        unknown = set(row) - set(dt_fields)
        if unknown:
            raise ProjectError(f"{ctx}: unknown key(s): {', '.join(sorted(unknown))}")
        missing = [f for f in dt_fields if f not in row]
        if missing:
            raise ProjectError(f"{ctx}: missing key(s): {', '.join(missing)}")
        datatypes[str(name)] = Datatype(name=str(name),
                                        **{f: str(row[f]) for f in dt_fields})

    pt_spec = {f.name: getattr(Point(), f.name) for f in dc_fields(Point)
               if f.name != "synthesized"}
    points = []
    for i, raw in enumerate(top["points"] or [], start=1):
        if not isinstance(raw, dict):
            raise ProjectError(f"points[{i}]: expected a mapping")
        p = Point(**_take(raw, f"points[{i}]", pt_spec))
        if p.addr is None:
            raise ProjectError(f"points[{i}]: 'addr' is required")
        p.rw = str(p.rw).lower()
        if p.alarm is not None:
            p.alarm = str(p.alarm).upper()
        p.online = _bool(p.online, f"points[{i}].online") if isinstance(p.online, bool) else bool(p.online)
        points.append(p)

    # A spelling that is neither driver is not raised here: validate.py names the two
    # legal values and carries advice, which is a better answer than a load error for a
    # field whose whole job is to be stated. `null` and absent both mean not stated.
    return Project(table=str(top["table"]), plant=str(top["plant"]), options=options,
                   system=system, groups=groups, statetexts=statetexts,
                   datatypes=datatypes, points=points,
                   driver=str(top["driver"] or "").strip())
