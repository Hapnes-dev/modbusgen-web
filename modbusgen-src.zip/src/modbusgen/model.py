"""Project model: the YAML input file parsed into dataclasses.

Field names follow docs/02-inputs.md; every field maps to a Work-sheet column or a
setup-sheet cell of the original Excel tool. Unknown YAML keys are rejected so typos
fail loudly instead of being silently ignored.
"""
from __future__ import annotations

from dataclasses import dataclass, field, fields as dc_fields
from typing import Any

from .tables import Datatype


class ProjectError(ValueError):
    """Invalid project file content."""


# The two IWMAC Modbus driver implementations (docs/15 section 1). They are not
# equivalent, and the difference decides questions the vendor document cannot: mb.exe
# carries word swaps and FC16, modbus.php carries neither. Nothing in a project file
# recorded which one a plant runs until 2026-08-29, so every check that depends on it
# could only end in "confirm before shipping". An empty string means not stated, which
# is what every file written before that date says.
DRIVERS = ("mb.exe", "modbus.php")

# The published contract. It lives here rather than in yamlio because the shape check
# below names it and yamlio imports this module; yamlio re-exports it unchanged.
SCHEMA_URL = "https://hapnes-dev.github.io/modbusgen-web/project.schema.json"

# The point keys an author reaches for when writing a project from memory of what "a
# JSON with points in it" usually looks like, each mapped to what the schema actually
# has. Every one of them is refused, never translated: a loader that quietly reads
# `address` as `addr` teaches the next file to carry it too, and the schema stops being
# the contract. The list is the real one - the first four rows, `rw: true` and `states`
# are the exact keys of a delivery that parsed, looked finished at 117 points and loaded
# none (2026-09-02, docs/11 "Project shape checkpoint").
_STATES = ("the words go once in the top-level \"statetexts\" object, and the point "
           "cites its list as \"statetext\": <id>")
POINT_ALIASES = {
    "address": "the field is addr",
    "register": "the field is addr",
    "name": "the field is text",
    "label": "the field is text",
    "description": "the field is text",
    "alias": "the field is text",
    "states": _STATES,
    "enum": _STATES,
    "view_order": "there is no such field - the order of the \"points\" array is the "
                  "operator's order",
    "writable": "the field is rw, an access string: \"rw\": \"rw\"",
}


def shape_problems(data) -> list[str]:
    """Every way the container can fail to be a project, named in one pass.

    load_project below is strict, and that strictness used to arrive one key at a time:
    fix `subtract_one`, run again, learn that `groups` is a list, run again, learn that
    the points were nested. On the routes that prune foreign keys before loading
    (webapi.prepare, the GUI's Import project) the first of those was not reported at
    all, and the GUI showed the file as one blank row under a green "Imported". This
    looks at the raw file, before any pruning, and names the whole shape at once.

    It is only about the container - never a register fact. A file it passes may still
    fail every rule in validate.py; a file it refuses was not a modbusgen project, and
    no rule in validate.py would ever have seen its points.
    """
    if not isinstance(data, dict):
        return []                        # load_project has its own sentence for that
    out: list[str] = []

    option_names = {f.name for f in dc_fields(Options)}
    stray = [k for k in data if k in option_names]
    if stray:
        inside = ", ".join(f'"{k}": ...' for k in stray)
        out.append(", ".join(repr(k) for k in stray) + " at the top level - "
                   + ("it is an option" if len(stray) == 1 else "they are options")
                   + ' and lives under "options": {' + inside + "}")

    groups = data.get("groups")
    nested: list[dict] = []
    if isinstance(groups, list):
        out.append("'groups' is a list - it is an object mapping each group key to its "
                   'alias: "groups": {"ac": "Modbus AC Object List"}')
        holders = [g for g in groups if isinstance(g, dict)]
    elif isinstance(groups, dict):
        holders = [g for g in groups.values() if isinstance(g, dict)]
    else:
        holders = []
    for g in holders:
        if isinstance(g.get("points"), list):
            nested += [p for p in g["points"] if isinstance(p, dict)]
    if nested:
        out.append(f"{len(nested)} point(s) nested under groups - none of them would be "
                   f'read. Every point lives in the top-level "points" array and names '
                   f'its group: {{"group": "ac", "datatype": ..., "addr": ..., "text": ...}}')

    points = data.get("points")
    if points is not None and not isinstance(points, list):
        out.append("'points' is not a list - it is an array of point objects")
    rows = [p for p in points if isinstance(p, dict)] if isinstance(points, list) else []
    rows += nested                       # so the row-level mistakes are named in the same breath
    for alias, remedy in POINT_ALIASES.items():
        n = sum(1 for p in rows if alias in p)
        if n:
            out.append(f"'{alias}' on {n} point(s) - {remedy}")
    n = sum(1 for p in rows if isinstance(p.get("rw"), bool))
    if n:
        out.append(f"'rw' is true/false on {n} point(s) - it is an access string: "
                   f'"rw" for a writable point, "r" (or leave it out) for read-only')

    statetexts = data.get("statetexts")
    if statetexts is not None and not isinstance(statetexts, dict):
        out.append("'statetexts' is not an object - it maps a list id to its words: "
                   '"statetexts": {"1": {"0": "Off", "1": "On"}}')
    options = data.get("options")
    if options is not None and not isinstance(options, dict):
        out.append("'options' is not an object")

    # Only worth saying beside a real problem: a relative path is legal in a file that
    # lives in this repository, and an odd URL on an otherwise correct file is not a
    # reason to refuse it. Beside one, it is usually the explanation.
    schema = data.get("$schema")
    if out and isinstance(schema, str) and schema != SCHEMA_URL \
            and not schema.endswith("schema/project.schema.json"):
        out.append(f"'$schema' points at {schema}, which is not the published contract "
                   f"{SCHEMA_URL} - a file written against a schema nobody has is a "
                   f"file written from memory")
    return out


def shape_message(problems: list[str]) -> str:
    lines = [f"this is not the modbusgen project shape - {len(problems)} problem(s), "
             f"nothing was loaded:"]
    lines += [f"  - {p}" for p in problems]
    lines.append("the container is: $schema, table, plant, driver, options {}, "
                 "groups {key: alias}, statetexts {id: {number: word}}, "
                 "points [{group, datatype, addr, text, ...}]. Copy the shape from a "
                 "working project or from the schema, never from memory, then re-prove "
                 "every register fact from the vendor document "
                 "(docs/11 'Project shape checkpoint')")
    return "\n".join(lines)


def check_shape(data) -> None:
    """Raise ProjectError naming every shape problem, or return quietly.

    Called on the raw file by load_project, and separately by the routes that prune a
    payload before loading it (webapi.prepare, parse_project, gui.Api.parse), because
    pruning is exactly what hid the first problem from them.
    """
    problems = shape_problems(data)
    if problems:
        raise ProjectError(shape_message(problems))


def _take(d: dict, ctx: str, spec: dict[str, Any]) -> dict:
    unknown = set(d) - set(spec)
    if unknown:
        raise ProjectError(f"{ctx}: unknown key(s): {', '.join(sorted(unknown))}")
    out = {}
    for key, default in spec.items():
        out[key] = d.get(key, default)
    return out


@dataclass
class Options:
    # Protocol_Spesific_Setup / Main_Setup toggles (defaults = template defaults)
    subtract_one: bool = True            # Prot!B18
    truncate: bool = True                # Main!B23
    create_tables: bool = False          # Main!B25
    use_system_no: bool = True           # Main!B31
    use_tag: bool = True                 # Main!B27
    use_extra: bool = True               # Main!B35
    reserve_text: str = "Reserve."       # Main!B13 (+B14)
    force_active: bool = True            # Prot!B38
    include_minmax: bool = False         # Prot!B42
    use_json: bool = True                # Prot!B54 (master gate on state texts)
    statetext_only_rw: bool = False      # Prot!B58
    statetext_in_alias: bool = False     # Prot!B62
    override_decimal: bool = False       # Prot!B46 (fill decimals from the unit table)
    require_motherwords: bool = False    # hard-fail bits without motherword (soft warning otherwise)
    sql_format: str = "modern"           # "modern" = REPLACE INTO house style (2026 examples);
                                         # "legacy" = the Excel tool's single-line INSERTs
    exclude_motherwords_from_groups: bool = True  # Prot!B30
    auto_motherwords: bool = True        # new: synthesize motherword rows for bit points
    auto_groups: bool = False            # Prot!B22 (fill missing group from datatype default)
    alarms_to_alm: bool = False          # Prot!B26
    proper_case_states: bool = True      # Excel WorksheetFunction.Proper on state words
    encoding: str = "cp1252"             # SQL file encoding (IWMAC tables are latin1)


@dataclass
class Comm:
    mode: str = "tcp"                    # tcp | rtu       (Main!B10)
    ip: str = ""                         # Main!B69
    port: int = 502
    com_port: str = ""                   # Main!B66
    baudrate: int = 19200                # Main!B72 (a checkbox there: 9600/19200 only)
    parity: str = "even"                 # none | odd | even  (Main!E75)
    stop_bits: int = 1
    data_bits: int = 8


@dataclass
class UnitRow:
    """One iw_sys_plant_units row - real lists register several devices on one
    driver (e.g. Carel EVD 01..10 with driver_addr 0_1..0_10)."""
    unit_id: str = ""
    unit_name: str = ""
    driver_addr: str = ""                # combined with driver_addr_prefix
    view_order: int = 0


@dataclass
class System:
    """Optional iw_sys_* blocks (Main_Setup B42/B45 sections)."""
    units: bool = False                  # emit iw_sys_plant_units + iw_sys_order_no
    settings: bool = False               # emit iw_sys_processes + iw_sys_plant_settings
    unit_id: str = ""                    # Main!B48 (single-unit shorthand)
    unit_name: str = ""                  # Main!B51
    reg_type: str = ""                   # Main!B54
    order_no: str = ""                   # Main!B57
    owner: str = ""                      # Main!B60 (driver/settings owner)
    driver_addr: str = "1"               # Main!B63
    driver_addr_prefix: str = "1_"       # Main!C63/D63 ("1_" or "0_")
    view_order: int = 0                  # iw_sys_plant_units.view_order
    unit_list: list[UnitRow] = field(default_factory=list)
    comm: Comm = field(default_factory=Comm)

    def effective_units(self) -> list[UnitRow]:
        """unit_list when given, else the single-unit shorthand fields."""
        if self.unit_list:
            return self.unit_list
        return [UnitRow(self.unit_id, self.unit_name, str(self.driver_addr),
                        int(self.view_order or 0))]


@dataclass
class Group:
    name: str
    alias: str = ""
    order: int = 0                       # view_order of the group_alias row


@dataclass
class Point:
    group: str = ""
    datatype: str = ""
    addr: int | None = None
    bit: int | str | None = None         # Work!F; int 0..31 or nibble syntax "5#4"
    element_id: str | None = None        # Work!C override
    system_no: str | None = None         # Work!M
    tag: str | None = None               # Work!N
    text: str = ""                       # Work!P (Aliastext)
    extra: str | None = None             # Work!O (Tag_extra)
    alarm: str | None = None             # Work!R (A/B/C/N)
    unit: str | None = None              # Work!S
    scale: str | None = None             # Work!T
    rw: str = "r"                        # Work!U
    online: bool = False                 # Work!V
    active: int | None = None            # Work!W (None -> 1 unless forced)
    no_group: bool = False               # Work!X = "x"
    menu: str | None = None              # Work!AA
    decimals: int | None = None          # Work!AB
    range_min: str | None = None         # Work!AC
    range_max: str | None = None         # Work!AD
    statetext: int | None = None         # Work!AE (Json Type No)
    update_freq: str | None = None       # override: fast/norm/slow/once/never (None = derived)
    synthesized: bool = False            # internal: auto-created motherword

    @property
    def is_motherword(self) -> bool:
        return self.text == "Motherword"


@dataclass
class Project:
    table: str
    plant: str
    options: Options
    system: System | None
    groups: list[Group]
    statetexts: dict[int, dict[int, str]]
    points: list[Point]
    # Datatype rows the project defines for itself. Last and defaulted so that every
    # existing construction stays valid - a project that defines none is the norm, and
    # the order the file is written in is yamlio's business, not this dataclass's.
    datatypes: dict[str, Datatype] = field(default_factory=dict)
    # Which driver the plant runs, one of DRIVERS or "" for not stated. Defaulted for the
    # same reason as datatypes above; in the file it sits beside `plant`, since both are
    # facts about the target plant rather than generation switches. It reaches no SQL
    # column - it decides what validate.py can say about word order and 32-bit writes.
    # The house standard is mb.exe, but that lives in the GUI's New and in the authoring
    # instructions, never here: a file that says nothing means nobody said, so loading
    # one must not turn silence into a claim about the plant.
    driver: str = ""


def _bool(v, ctx):
    if isinstance(v, bool):
        return v
    raise ProjectError(f"{ctx}: expected true/false, got {v!r}")


def load_project(data: dict) -> Project:
    if not isinstance(data, dict):
        raise ProjectError("project file must be a YAML mapping")
    # The whole container first, so a file that is not a project is refused with every
    # shape problem named rather than the first unknown key - see shape_problems.
    check_shape(data)
    # Annotation, not project content: JSON files reference their contract with $schema
    # and carry the reader's briefing in _help (yamlio.HELP_BLOCK). Both are stripped
    # here rather than modelled, so nothing downstream can be made to depend on them -
    # a file that lost either still loads, and one that hand-edited _help still generates
    # the same SQL.
    data = {k: v for k, v in data.items() if k not in ("$schema", "_help")}
    top = _take(data, "project", {
        "table": None, "plant": None, "driver": "", "options": {}, "system": None,
        "groups": {}, "statetexts": {}, "datatypes": {}, "points": [],
    })
    if not top["table"]:
        raise ProjectError("'table' is required (names the iw_par_/iw_set_ tables)")
    if top["plant"] is None:
        raise ProjectError("'plant' is required (plant number, used in the file name)")

    opt_spec = {f.name: getattr(Options(), f.name) for f in dc_fields(Options)}
    options = Options(**_take(top["options"] or {}, "options", opt_spec))

    system = None
    if top["system"] is not None:
        sys_spec = {f.name: getattr(System(), f.name) for f in dc_fields(System)}
        raw = _take(top["system"] or {}, "system", sys_spec)
        comm_spec = {f.name: getattr(Comm(), f.name) for f in dc_fields(Comm)}
        raw["comm"] = Comm(**_take(raw["comm"] if isinstance(raw["comm"], dict) else {},
                                   "system.comm", comm_spec))
        unit_spec = {f.name: getattr(UnitRow(), f.name) for f in dc_fields(UnitRow)}
        rows = []
        for i, u in enumerate(raw["unit_list"] or [], start=1):
            if not isinstance(u, dict):
                raise ProjectError(f"system.unit_list[{i}]: expected a mapping")
            ur = _take(u, f"system.unit_list[{i}]", unit_spec)
            ur["driver_addr"] = str(ur["driver_addr"])
            ur["view_order"] = int(ur["view_order"] or 0)
            rows.append(UnitRow(**ur))
        raw["unit_list"] = rows
        system = System(**raw)

    groups: list[Group] = []
    raw_groups = top["groups"] or {}
    if not isinstance(raw_groups, dict):
        raise ProjectError("'groups' must be a mapping of name -> alias")
    for i, (name, val) in enumerate(raw_groups.items(), start=1):
        if isinstance(val, str):
            groups.append(Group(str(name), val, i))
        elif isinstance(val, dict):
            g = _take(val, f"groups.{name}", {"alias": "", "order": i})
            groups.append(Group(str(name), g["alias"], int(g["order"])))
        else:
            raise ProjectError(f"groups.{name}: expected alias string or mapping")

    statetexts: dict[int, dict[int, str]] = {}
    for sid, states in (top["statetexts"] or {}).items():
        if not isinstance(states, dict):
            raise ProjectError(f"statetexts.{sid}: expected mapping number -> word")
        statetexts[int(sid)] = {int(k): str(v) for k, v in states.items()}

    # Datatype rows of the project's own - the Modbus_Variables sheet, carried in the
    # file. Every field is required: a datatype missing its read function would build
    # driver ids like `0__100` and validate them, which is worse than refusing here.
    datatypes: dict[str, Datatype] = {}
    raw_datatypes = top["datatypes"] or {}
    if not isinstance(raw_datatypes, dict):
        raise ProjectError("'datatypes' must be a mapping of name -> row")
    dt_fields = [f.name for f in dc_fields(Datatype) if f.name != "name"]
    for name, row in raw_datatypes.items():
        ctx = f"datatypes.{name}"
        if not isinstance(row, dict):
            raise ProjectError(f"{ctx}: expected a mapping of the nine column values")
        unknown = set(row) - set(dt_fields)
        if unknown:
            raise ProjectError(f"{ctx}: unknown key(s): {', '.join(sorted(unknown))}")
        missing = [f for f in dt_fields if f not in row]
        if missing:
            raise ProjectError(f"{ctx}: missing key(s): {', '.join(missing)}")
        datatypes[str(name)] = Datatype(name=str(name),
                                        **{f: str(row[f]) for f in dt_fields})

    pt_spec = {f.name: getattr(Point(), f.name) for f in dc_fields(Point)
               if f.name != "synthesized"}
    points = []
    for i, raw in enumerate(top["points"] or [], start=1):
        if not isinstance(raw, dict):
            raise ProjectError(f"points[{i}]: expected a mapping")
        p = Point(**_take(raw, f"points[{i}]", pt_spec))
        if p.addr is None:
            raise ProjectError(f"points[{i}]: 'addr' is required")
        p.rw = str(p.rw).lower()
        if p.alarm is not None:
            p.alarm = str(p.alarm).upper()
        p.online = _bool(p.online, f"points[{i}].online") if isinstance(p.online, bool) else bool(p.online)
        points.append(p)

    # A spelling that is neither driver is not raised here: validate.py names the two
    # legal values and carries advice, which is a better answer than a load error for a
    # field whose whole job is to be stated. `null` and absent both mean not stated.
    return Project(table=str(top["table"]), plant=str(top["plant"]), options=options,
                   system=system, groups=groups, statetexts=statetexts,
                   datatypes=datatypes, points=points,
                   driver=str(top["driver"] or "").strip())
