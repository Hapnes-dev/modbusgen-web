"""Project model: the YAML input file parsed into dataclasses.

Field names follow docs/02-inputs.md; every field maps to a Work-sheet column or a
setup-sheet cell of the original Excel tool. Unknown YAML keys are rejected so typos
fail loudly instead of being silently ignored.
"""
from __future__ import annotations

import difflib
import math
import re
from dataclasses import dataclass, field, fields as dc_fields
from typing import Any

from .tables import Datatype


class ProjectError(ValueError):
    """Invalid project file content."""


# The two IWMAC Modbus driver implementations (docs/15 section 1). They are not
# equivalent, and the difference decides questions the vendor document cannot: mb.exe
# carries word swaps and FC16, modbus.php carries neither. Nothing in a project file
# recorded which one a plant runs until 2026-08-29, so every check that depends on it
# could only end in "confirm before shipping". An empty string means not stated, which
# is what every file written before that date says.
DRIVERS = ("mb.exe", "modbus.php")

# The published contract. It lives here rather than in yamlio because the shape check
# below names it and yamlio imports this module; yamlio re-exports it unchanged.
SCHEMA_URL = "https://hapnes-dev.github.io/modbusgen-web/project.schema.json"

# The point keys an author reaches for when writing a project from memory of what "a
# JSON with points in it" usually looks like, each mapped to what the schema actually
# has. Every one of them is refused, never translated: a loader that quietly reads
# `address` as `addr` teaches the next file to carry it too, and the schema stops being
# the contract. The list is the real one - the first four rows, `rw: true` and `states`
# are the exact keys of a delivery that parsed, looked finished at 117 points and loaded
# none (2026-09-02, docs/11 "Project shape checkpoint").
_STATES = ("the words go once in the top-level \"statetexts\" object, and the point "
           "cites its list as \"statetext\": <id>")
POINT_ALIASES = {
    "address": "the field is addr",
    "register": "the field is addr",
    "name": "the field is text",
    "label": "the field is text",
    "description": "the field is text",
    "alias": "the field is text",
    "states": _STATES,
    "enum": _STATES,
    "view_order": "there is no such field - the order of the \"points\" array is the "
                  "operator's order",
    "writable": "the field is rw, an access string: \"rw\": \"rw\"",
}


def shape_problems(data) -> list[str]:
    """Every way the container can fail to be a project, named in one pass.

    load_project below is strict, and that strictness used to arrive one key at a time:
    fix `subtract_one`, run again, learn that `groups` is a list, run again, learn that
    the points were nested. On the routes that prune foreign keys before loading
    (webapi.prepare, the GUI's Import JSON) the first of those was not reported at
    all, and the GUI showed the file as one blank row under a green "Imported". This
    looks at the raw file, before any pruning, and names the whole shape at once.

    It is only about the container - never a register fact. A file it passes may still
    fail every rule in validate.py; a file it refuses was not a modbusgen project, and
    no rule in validate.py would ever have seen its points.
    """
    if not isinstance(data, dict):
        return []                        # load_project has its own sentence for that
    out: list[str] = []

    option_names = {f.name for f in dc_fields(Options)}
    stray = [k for k in data if k in option_names]
    if stray:
        inside = ", ".join(f'"{k}": ...' for k in stray)
        out.append(", ".join(repr(k) for k in stray) + " at the top level - "
                   + ("it is an option" if len(stray) == 1 else "they are options")
                   + ' and lives under "options": {' + inside + "}")

    groups = data.get("groups")
    nested: list[dict] = []
    if isinstance(groups, list):
        out.append("'groups' is a list - it is an object mapping each group key to its "
                   'alias: "groups": {"ac": "Modbus AC Object List"}')
        holders = [g for g in groups if isinstance(g, dict)]
    elif isinstance(groups, dict):
        holders = [g for g in groups.values() if isinstance(g, dict)]
    else:
        holders = []
    for g in holders:
        if isinstance(g.get("points"), list):
            nested += [p for p in g["points"] if isinstance(p, dict)]
    if nested:
        out.append(f"{len(nested)} point(s) nested under groups - none of them would be "
                   f'read. Every point lives in the top-level "points" array and names '
                   f'its group: {{"group": "ac", "datatype": ..., "addr": ..., "text": ...}}')

    points = data.get("points")
    if points is not None and not isinstance(points, list):
        out.append("'points' is not a list - it is an array of point objects")
    rows = [p for p in points if isinstance(p, dict)] if isinstance(points, list) else []
    rows += nested                       # so the row-level mistakes are named in the same breath
    for alias, remedy in POINT_ALIASES.items():
        n = sum(1 for p in rows if alias in p)
        if n:
            out.append(f"'{alias}' on {n} point(s) - {remedy}")
    n = sum(1 for p in rows if isinstance(p.get("rw"), bool))
    if n:
        out.append(f"'rw' is true/false on {n} point(s) - it is an access string: "
                   f'"rw" for a writable point, "r" (or leave it out) for read-only')

    statetexts = data.get("statetexts")
    if statetexts is not None and not isinstance(statetexts, dict):
        out.append("'statetexts' is not an object - it maps a list id to its words: "
                   '"statetexts": {"1": {"0": "Off", "1": "On"}}')
    options = data.get("options")
    if options is not None and not isinstance(options, dict):
        out.append("'options' is not an object")

    # Only worth saying beside a real problem: a relative path is legal in a file that
    # lives in this repository, and an odd URL on an otherwise correct file is not a
    # reason to refuse it. Beside one, it is usually the explanation.
    schema = data.get("$schema")
    if out and isinstance(schema, str) and schema != SCHEMA_URL \
            and not schema.endswith("schema/project.schema.json"):
        out.append(f"'$schema' points at {schema}, which is not the published contract "
                   f"{SCHEMA_URL} - a file written against a schema nobody has is a "
                   f"file written from memory")
    return out


def shape_message(problems: list[str]) -> str:
    lines = [f"this is not the modbusgen project shape - {len(problems)} problem(s), "
             f"nothing was loaded:"]
    lines += [f"  - {p}" for p in problems]
    lines.append("the container is: $schema, table, plant, driver, options {}, "
                 "groups {key: alias}, statetexts {id: {number: word}}, "
                 "points [{group, datatype, addr, text, ...}]. Copy the shape from a "
                 "working project or from the schema, never from memory, then re-prove "
                 "every register fact from the vendor document "
                 "(docs/11 'Project shape checkpoint')")
    return "\n".join(lines)


def check_shape(data) -> None:
    """Raise ProjectError naming every shape problem, or return quietly.

    Called on the raw file by load_project, and separately by the routes that prune a
    payload before loading it (webapi.prepare, parse_project, gui.Api.parse), because
    pruning is exactly what hid the first problem from them.
    """
    problems = shape_problems(data)
    if problems:
        raise ProjectError(shape_message(problems))


def _take(d: dict, ctx: str, spec: dict[str, Any]) -> dict:
    # keys compared as text: a YAML key written as a number (`5: x` in a point) is just as
    # unknown as any other, and sorting it beside the text keys raised a TypeError
    unknown = {str(k) for k in d if not (isinstance(k, str) and k in spec)}
    if unknown:
        raise ProjectError(f"{ctx}: unknown key(s): {', '.join(sorted(unknown))}")
    out = {}
    for key, default in spec.items():
        out[key] = d.get(key, default)
    return out


def _mapping(v, ctx: str, what: str, why: str = ""):
    """A block that must be a mapping, or null for its defaults. `"system": 5`, `true` or
    `[{}]` raised a bare TypeError, `"system": "yes"` was read letter by letter ("unknown
    key(s): e, s, y"), and `"comm": "rtu"` became the default mode, tcp, without a word
    (review, 2026-10-24)."""
    if v is None or isinstance(v, dict):
        return v or {}
    raise ProjectError(f"{ctx}: expected {what}, not {type(v).__name__} {v!r}"
                       + (f" - {why}" if why else ""))


@dataclass
class Options:
    # Protocol_Spesific_Setup / Main_Setup toggles (defaults = template defaults)
    subtract_one: bool = True            # Prot!B18
    truncate: bool | None = None         # Main!B23; None = the format's own default (truncates)
    replace_list: bool = False           # new: delete the old list first (bound rows + tables)
    create_tables: bool = False          # Main!B25
    use_system_no: bool = True           # Main!B31
    use_tag: bool = True                 # Main!B27
    use_extra: bool = True               # Main!B35
    reserve_text: str = "Reserve."       # Main!B13 (+B14)
    force_active: bool = True            # Prot!B38
    include_minmax: bool = False         # Prot!B42
    use_json: bool = True                # Prot!B54 (master gate on state texts)
    statetext_only_rw: bool = False      # Prot!B58
    statetext_in_alias: bool = False     # Prot!B62
    override_decimal: bool = False       # Prot!B46 (fill decimals from the unit table)
    require_motherwords: bool = False    # hard-fail bits without motherword (soft warning otherwise)
    sql_format: str = "modern"           # "modern" = REPLACE INTO house style (2026 examples);
                                         # "legacy" = the Excel tool's single-line INSERTs
    exclude_motherwords_from_groups: bool = True  # Prot!B30
    auto_motherwords: bool = True        # new: synthesize motherword rows for bit points
    auto_groups: bool = False            # Prot!B22 (fill missing group from datatype default)
    alarms_to_alm: bool = False          # Prot!B26
    proper_case_states: bool = True      # Excel WorksheetFunction.Proper on state words
    encoding: str = "cp1252"             # SQL file encoding (IWMAC tables are latin1)

    @property
    def truncates(self) -> bool:
        """Whether the script empties the list's three tables before writing them.

        A file that says nothing gets its format's own behaviour: legacy truncates, as
        the Excel tool's Main!B23 does by default, and modern does not, as the 2026
        REPLACE INTO reference export does not. Modern honours an explicit true since
        2026-10-23: the box sat ticked on the page and did nothing there, and a colleague
        re-importing a changed list expected it to clear the rows the list had dropped.
        replace_list empties them too, whatever truncate says.
        """
        if self.replace_list:
            return True
        return self.sql_format == "legacy" if self.truncate is None else bool(self.truncate)


@dataclass
class Comm:
    mode: str = "tcp"                    # tcp | rtu       (Main!B10)
    ip: str = ""                         # Main!B69
    port: int = 502
    com_port: str = ""                   # Main!B66
    baudrate: int = 19200                # Main!B72 (a checkbox there: 9600/19200 only)
    parity: str = "even"                 # none | odd | even  (Main!E75)
    stop_bits: int = 1
    data_bits: int = 8


@dataclass
class UnitRow:
    """One iw_sys_plant_units row - real lists register several devices on one
    driver (e.g. Carel EVD 01..10 with driver_addr 0_1..0_10)."""
    unit_id: str = ""
    unit_name: str = ""
    driver_addr: str = ""                # combined with driver_addr_prefix
    view_order: int = 0


@dataclass
class System:
    """Optional iw_sys_* blocks (Main_Setup B42/B45 sections)."""
    units: bool = False                  # emit iw_sys_plant_units + iw_sys_order_no
    settings: bool = False               # emit iw_sys_processes + iw_sys_plant_settings
    unit_id: str = ""                    # Main!B48 (single-unit shorthand)
    unit_name: str = ""                  # Main!B51
    reg_type: str = ""                   # Main!B54
    order_no: str = ""                   # Main!B57
    owner: str = ""                      # Main!B60 (driver/settings owner)
    driver_addr: str = "1"               # Main!B63
    driver_addr_prefix: str = "1_"       # Main!C63/D63 ("1_" or "0_")
    view_order: int = 0                  # iw_sys_plant_units.view_order
    unit_list: list[UnitRow] = field(default_factory=list)
    comm: Comm = field(default_factory=Comm)

    def effective_units(self) -> list[UnitRow]:
        """unit_list when given, else the single-unit shorthand fields."""
        if self.unit_list:
            return self.unit_list
        return [UnitRow(self.unit_id, self.unit_name, str(self.driver_addr),
                        int(self.view_order or 0))]


@dataclass
class Group:
    name: str
    alias: str = ""
    order: int = 0                       # view_order of the group_alias row


@dataclass
class Point:
    group: str = ""
    datatype: str = ""
    addr: int | None = None
    bit: int | str | None = None         # Work!F; int 0..31 or nibble syntax "5#4"
    element_id: str | None = None        # Work!C override
    system_no: str | None = None         # Work!M
    tag: str | None = None               # Work!N
    text: str = ""                       # Work!P (Aliastext)
    extra: str | None = None             # Work!O (Tag_extra)
    alarm: str | None = None             # Work!R (A/B/C/N)
    unit: str | None = None              # Work!S
    scale: str | None = None             # Work!T
    rw: str = "r"                        # Work!U
    online: bool = False                 # Work!V
    active: int | None = None            # Work!W (None -> 1 unless forced)
    no_group: bool = False               # Work!X = "x"
    menu: str | None = None              # Work!AA
    decimals: int | None = None          # Work!AB
    range_min: str | None = None         # Work!AC
    range_max: str | None = None         # Work!AD
    statetext: int | None = None         # Work!AE (Json Type No)
    update_freq: str | None = None       # override: fast/norm/slow/once/never (None = derived)
    synthesized: bool = False            # internal: auto-created motherword

    @property
    def is_motherword(self) -> bool:
        return self.text == "Motherword"


@dataclass
class Project:
    table: str
    plant: str
    options: Options
    system: System | None
    groups: list[Group]
    statetexts: dict[int, dict[int, str]]
    points: list[Point]
    # Datatype rows the project defines for itself. Last and defaulted so that every
    # existing construction stays valid - a project that defines none is the norm, and
    # the order the file is written in is yamlio's business, not this dataclass's.
    datatypes: dict[str, Datatype] = field(default_factory=dict)
    # Which driver the plant runs, one of DRIVERS or "" for not stated. Defaulted for the
    # same reason as datatypes above; in the file it sits beside `plant`, since both are
    # facts about the target plant rather than generation switches. It reaches no SQL
    # column - it decides what validate.py can say about word order and 32-bit writes.
    # The house standard is mb.exe, but that lives in the GUI's New and in the authoring
    # instructions, never here: a file that says nothing means nobody said, so loading
    # one must not turn silence into a claim about the plant.
    driver: str = ""


def _bool(v, ctx):
    if isinstance(v, bool):
        return v
    raise ProjectError(f"{ctx}: expected true/false, got {v!r}")


# Type checks on load (2026-10-23). The loader used to take any value the file held:
# Python counts every non-empty string as true, so `"subtract_one": "false"` switched
# the subtraction on and shifted every address with no finding; `bit: true` built a
# driver id ending in `.True`; a null system field reached the script as the text
# 'None'. Each helper turns the unambiguous spellings into the right type and refuses
# the rest with the path and what to write instead.

def _flag(v, ctx: str, allow_none: bool = False):
    """A true/false field: a boolean, or 0/1."""
    if isinstance(v, bool) or (allow_none and v is None):
        return v
    if isinstance(v, int) and v in (0, 1):
        return bool(v)
    raise ProjectError(f"{ctx}: write true or false (without quotes), not {v!r}")


def _finite(v: float, ctx: str) -> float:
    """NaN and Infinity are not values any field can carry. parse_text refuses them in
    the text; this is for data handed to load_project directly (a json.loads of its own
    takes both), where `int(inf)` used to surface as an OverflowError mid-load."""
    if not math.isfinite(v):
        raise ProjectError(f"{ctx}: {v!r} is not a number a project can carry - write the "
                           f"value the document prints, or leave the field out")
    return v


def _whole(v, ctx: str):
    """A whole number: an int, or text that is one ("40001"). A true/false is refused -
    Python counts it as 1/0. A fraction is left for validate.py's coded finding."""
    if v is None or (isinstance(v, int) and not isinstance(v, bool)):
        return v
    if isinstance(v, float):
        _finite(v, ctx)
        return int(v) if v.is_integer() else v
    if isinstance(v, str) and re.fullmatch(r"\s*[-+]?\d+\s*", v):
        return int(v)
    raise ProjectError(f"{ctx}: expected a whole number, not {v!r}")


def _text(v, ctx: str, numeric_ok: bool = False):
    """A text field. A whole number becomes its text. A fraction only where the field is
    a number by nature (ranges, scale): elsewhere `360.010` written without quotes reads
    as 360.01 and the alias would lose its zero, so it is refused instead."""
    if v is None or isinstance(v, str):
        return v
    if isinstance(v, bool):
        raise ProjectError(f"{ctx}: write the text in quotes, not {v!r}")
    if isinstance(v, int):
        return str(v)
    if isinstance(v, float):
        _finite(v, ctx)
        if numeric_ok:
            return str(int(v)) if v.is_integer() else repr(v)
        raise ProjectError(f"{ctx}: write {v!r} in quotes, so every digit is kept")
    raise ProjectError(f"{ctx}: expected text, not {type(v).__name__}")


def _coerce(values: dict, spec: dict, ctx: str) -> dict:
    """Every field whose default says its type: booleans, whole numbers, text. A null
    takes the default. Fields defaulting to None are the caller's to check."""
    for name, default in spec.items():
        v, where = values[name], f"{ctx}.{name}"
        if isinstance(default, bool):
            values[name] = default if v is None else _flag(v, where)
        elif isinstance(default, int):
            values[name] = default if v is None else _whole(v, where)
        elif isinstance(default, str):
            values[name] = default if v is None else _text(v, where)
    return values


def _point(raw: dict, ctx: str, spec: dict) -> "Point":
    v = _take(raw, ctx, spec)
    if v["no_group"] in ("x", "X", ""):          # the workbook's own spelling of the flag
        v["no_group"] = v["no_group"] != ""
    _coerce(v, spec, ctx)
    for name in ("element_id", "system_no", "tag", "extra", "alarm", "unit", "menu",
                 "update_freq"):
        v[name] = _text(v[name], f"{ctx}.{name}")
    for name in ("scale", "range_min", "range_max"):
        v[name] = _text(v[name], f"{ctx}.{name}", numeric_ok=True)
    for name in ("addr", "decimals", "statetext"):
        v[name] = _whole(v[name], f"{ctx}.{name}")
    bit = v["bit"]
    if isinstance(bit, bool):
        raise ProjectError(f"{ctx}.bit: expected a bit number, not {bit!r}")
    if isinstance(bit, str) and re.fullmatch(r"\s*\d+\s*", bit):
        v["bit"] = int(bit)
    elif isinstance(bit, float) and bit.is_integer():
        v["bit"] = int(bit)
    if v["active"] is not None:
        v["active"] = int(_flag(v["active"], f"{ctx}.active"))
    return Point(**v)


def unknown_keys(data) -> list[str]:
    """Keys a project has no field for, each with the nearest real one.

    load_project refuses them, but the page's routes prune them first (yamlio.
    to_yaml_dict), so a file with `"scaling": "x0.1"` or `"substract_one": false`
    imported as if the key were not there: no scale, the subtraction still on, and no
    word said (review, 2026-10-23). The page now shows this list when a file is imported.
    """
    if not isinstance(data, dict):
        return []
    out: list[str] = []

    def check(where: str, mapping, allowed: set[str], skip: set[str] = frozenset()):
        if not isinstance(mapping, dict):
            return
        for key in mapping:
            if key in allowed or key in skip:
                continue
            near = difflib.get_close_matches(str(key), sorted(allowed), n=1, cutoff=0.6)
            out.append(f"{where}{key} is not a project key and is left out"
                       + (f" - did you mean {near[0]}?" if near else ""))

    top = {"$schema", "_help", "table", "plant", "driver", "options", "system", "groups",
           "statetexts", "datatypes", "points"}
    check("", data, top, set(_option_names()))   # options at the top are shape_problems'
    check("options.", data.get("options"), set(_option_names()))
    system = data.get("system")
    if isinstance(system, dict):
        check("system.", system, {f.name for f in dc_fields(System)})
        check("system.comm.", system.get("comm"), {f.name for f in dc_fields(Comm)})
        units = system.get("unit_list")
        for i, u in enumerate(units if isinstance(units, list) else [], start=1):
            check(f"system.unit_list[{i}].", u, {f.name for f in dc_fields(UnitRow)})
    groups = data.get("groups")
    if isinstance(groups, dict):
        for name, g in groups.items():
            check(f"groups.{name}.", g, {"alias", "order"}, {"points"})
    point_keys = {f.name for f in dc_fields(Point)} - {"synthesized"}
    points = data.get("points")
    # a block of the wrong type is load_project's to name; here it has no keys to list
    for i, p in enumerate(points if isinstance(points, list) else [], start=1):
        check(f"points[{i}].", p, point_keys, set(POINT_ALIASES))
    return out


def _option_names() -> list[str]:
    return [f.name for f in dc_fields(Options)]


def load_project(data: dict) -> Project:
    if not isinstance(data, dict):
        raise ProjectError("project file must be a YAML mapping")
    # The whole container first, so a file that is not a project is refused with every
    # shape problem named rather than the first unknown key - see shape_problems.
    check_shape(data)
    # Annotation, not project content: JSON files reference their contract with $schema
    # and carry the reader's briefing in _help (yamlio.HELP_BLOCK). Both are stripped
    # here rather than modelled, so nothing downstream can be made to depend on them -
    # a file that lost either still loads, and one that hand-edited _help still generates
    # the same SQL.
    data = {k: v for k, v in data.items() if k not in ("$schema", "_help")}
    top = _take(data, "project", {
        "table": None, "plant": None, "driver": "", "options": {}, "system": None,
        "groups": {}, "statetexts": {}, "datatypes": {}, "points": [],
    })
    if not top["table"]:
        raise ProjectError("'table' is required (names the iw_par_/iw_set_ tables)")
    if top["plant"] is None:
        raise ProjectError("'plant' is required (plant number, used in the file name)")

    opt_spec = {f.name: getattr(Options(), f.name) for f in dc_fields(Options)}
    raw_options = _coerce(_take(top["options"] or {}, "options", opt_spec), opt_spec, "options")
    raw_options["truncate"] = _flag(raw_options["truncate"], "options.truncate", allow_none=True)
    fmt = str(raw_options["sql_format"]).strip().lower()
    if fmt not in ("modern", "legacy"):
        # read as modern without a word before; validate.py's own check never saw it
        raise ProjectError(f"options.sql_format: write modern or legacy, not "
                           f"{raw_options['sql_format']!r}")
    raw_options["sql_format"] = fmt
    options = Options(**raw_options)

    system = None
    # false, like null, is no system block - to_yaml_dict drops both on the page's routes
    if top["system"] is not None and top["system"] is not False:
        sys_spec = {f.name: getattr(System(), f.name) for f in dc_fields(System)}
        raw = _coerce(_take(_mapping(top["system"], "system", "a mapping of the iw_sys "
                                     "fields, or null"), "system", sys_spec),
                      sys_spec, "system")
        comm_spec = {f.name: getattr(Comm(), f.name) for f in dc_fields(Comm)}
        comm = {} if isinstance(raw["comm"], Comm) else _mapping(
            raw["comm"], "system.comm", "a mapping such as {\"mode\": \"rtu\", "
            "\"com_port\": \"3\"}", "the mode alone is not the block, and read as one it "
            "became tcp")
        raw["comm"] = Comm(**_coerce(_take(comm, "system.comm", comm_spec), comm_spec,
                                     "system.comm"))
        unit_spec = {f.name: getattr(UnitRow(), f.name) for f in dc_fields(UnitRow)}
        unit_list = raw["unit_list"]
        if unit_list is not None and not isinstance(unit_list, list):
            raise ProjectError(f"system.unit_list: expected a list of units, "
                               f"[{{\"unit_id\": ..., \"driver_addr\": ...}}], not "
                               f"{type(unit_list).__name__} {unit_list!r}")
        rows = []
        for i, u in enumerate(unit_list or [], start=1):
            if not isinstance(u, dict):
                raise ProjectError(f"system.unit_list[{i}]: expected a mapping")
            ur = _coerce(_take(u, f"system.unit_list[{i}]", unit_spec), unit_spec,
                         f"system.unit_list[{i}]")
            rows.append(UnitRow(**ur))
        raw["unit_list"] = rows
        system = System(**raw)

    groups: list[Group] = []
    raw_groups = top["groups"] or {}
    if not isinstance(raw_groups, dict):
        raise ProjectError("'groups' must be a mapping of name -> alias")
    # Keys are read as text or numbers below, and two spellings can become one key there:
    # YAML's `1:` and `"1":`, JSON's "1" and "01". The second used to replace the first
    # without a word - the same silent loss parse_text refuses for a key written twice.
    group_names: dict[str, object] = {}
    for i, (name, val) in enumerate(raw_groups.items(), start=1):
        if str(name) in group_names:
            raise ProjectError(f"groups.{name}: the group {str(name)!r} is written twice "
                               f"(also as {group_names[str(name)]!r}) - keep one")
        group_names[str(name)] = name
        if val is None or isinstance(val, (str, int, float, bool)):
            groups.append(Group(str(name), _text(val, f"groups.{name}") or "", i))
        elif isinstance(val, dict):
            g = _take(val, f"groups.{name}", {"alias": "", "order": i})
            order = _whole(g["order"], f"groups.{name}.order")
            groups.append(Group(str(name), _text(g["alias"], f"groups.{name}.alias") or "",
                                i if order is None else int(order)))
        else:
            raise ProjectError(f"groups.{name}: expected alias string or mapping")

    statetexts: dict[int, dict[int, str]] = {}
    list_spelled: dict[int, object] = {}
    for sid, states in (top["statetexts"] or {}).items():
        if not isinstance(states, dict):
            raise ProjectError(f"statetexts.{sid}: expected mapping number -> word")
        list_id = _whole(sid, f"statetexts.{sid}")
        words = {}
        spelled: dict[int, object] = {}
        for k, v in states.items():
            number = _whole(k, f"statetexts.{sid}.{k}")
            if not isinstance(number, int):
                raise ProjectError(f"statetexts.{sid}.{k}: a state number is a whole number")
            if number in spelled:
                raise ProjectError(f"statetexts.{sid}.{k}: state {number} is written twice "
                                   f"in this list (also as {spelled[number]!r}) - keep one")
            spelled[number] = k
            words[number] = _text(v, f"statetexts.{sid}.{k}", numeric_ok=True) or ""
        if not isinstance(list_id, int):
            raise ProjectError(f"statetexts.{sid}: a list id is a whole number")
        if list_id in list_spelled:
            raise ProjectError(f"statetexts.{sid}: list {list_id} is written twice (also as "
                               f"{list_spelled[list_id]!r}) - keep one")
        list_spelled[list_id] = sid
        statetexts[list_id] = words

    # Datatype rows of the project's own - the Modbus_Variables sheet, carried in the
    # file. Every field is required: a datatype missing its read function would build
    # driver ids like `0__100` and validate them, which is worse than refusing here.
    datatypes: dict[str, Datatype] = {}
    raw_datatypes = top["datatypes"] or {}
    if not isinstance(raw_datatypes, dict):
        raise ProjectError("'datatypes' must be a mapping of name -> row")
    dt_fields = [f.name for f in dc_fields(Datatype) if f.name != "name"]
    for name, row in raw_datatypes.items():
        ctx = f"datatypes.{name}"
        if not isinstance(row, dict):
            raise ProjectError(f"{ctx}: expected a mapping of the nine column values")
        unknown = {str(k) for k in row if not (isinstance(k, str) and k in dt_fields)}
        if unknown:
            raise ProjectError(f"{ctx}: unknown key(s): {', '.join(sorted(unknown))}")
        missing = [f for f in dt_fields if f not in row]
        if missing:
            raise ProjectError(f"{ctx}: missing key(s): {', '.join(missing)}")
        if str(name) in datatypes:
            raise ProjectError(f"{ctx}: the datatype {str(name)!r} is written twice - "
                               f"keep one")
        # a null column is blank - `write_func: null` is a row with no write function, and
        # read as the text 'None' it drew two findings for that one mistake
        datatypes[str(name)] = Datatype(
            name=str(name), **{f: "" if row[f] is None else str(row[f]) for f in dt_fields})

    pt_spec = {f.name: getattr(Point(), f.name) for f in dc_fields(Point)
               if f.name != "synthesized"}
    points = []
    for i, raw in enumerate(top["points"] or [], start=1):
        if not isinstance(raw, dict):
            raise ProjectError(f"points[{i}]: expected a mapping")
        p = _point(raw, f"points[{i}]", pt_spec)
        if p.addr is None:
            raise ProjectError(f"points[{i}]: 'addr' is required")
        p.rw = str(p.rw).lower()
        if p.alarm is not None:
            p.alarm = str(p.alarm).upper()
        points.append(p)

    # A spelling that is neither driver is not raised here: validate.py names the two
    # legal values and carries advice, which is a better answer than a load error for a
    # field whose whole job is to be stated. `null` and absent both mean not stated.
    return Project(table=str(top["table"]), plant=str(top["plant"]), options=options,
                   system=system, groups=groups, statetexts=statetexts,
                   datatypes=datatypes, points=points,
                   driver=str(top["driver"] or "").strip())
