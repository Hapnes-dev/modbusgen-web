"""Project model: the YAML input file parsed into dataclasses.

Field names follow docs/02-inputs.md; every field maps to a Work-sheet column or a
setup-sheet cell of the original Excel tool. Unknown YAML keys are rejected so typos
fail loudly instead of being silently ignored.
"""
from __future__ import annotations

from dataclasses import dataclass, field, fields as dc_fields
from typing import Any


class ProjectError(ValueError):
    """Invalid project file content."""


def _take(d: dict, ctx: str, spec: dict[str, Any]) -> dict:
    unknown = set(d) - set(spec)
    if unknown:
        raise ProjectError(f"{ctx}: unknown key(s): {', '.join(sorted(unknown))}")
    out = {}
    for key, default in spec.items():
        out[key] = d.get(key, default)
    return out


@dataclass
class Options:
    # Protocol_Spesific_Setup / Main_Setup toggles (defaults = template defaults)
    subtract_one: bool = True            # Prot!B18
    truncate: bool = True                # Main!B23
    create_tables: bool = False          # Main!B25
    use_system_no: bool = True           # Main!B31
    use_tag: bool = True                 # Main!B27
    use_extra: bool = True               # Main!B35
    reserve_text: str = "Reserve."       # Main!B13 (+B14)
    force_active: bool = True            # Prot!B38
    include_minmax: bool = False         # Prot!B42
    statetext_only_rw: bool = False      # Prot!B58
    statetext_in_alias: bool = False     # Prot!B62
    require_motherwords: bool = False    # hard-fail bits without motherword (soft warning otherwise)
    exclude_motherwords_from_groups: bool = True  # Prot!B30
    auto_motherwords: bool = True        # new: synthesize motherword rows for bit points
    auto_groups: bool = False            # Prot!B22 (fill missing group from datatype default)
    alarms_to_alm: bool = False          # Prot!B26
    proper_case_states: bool = True      # Excel WorksheetFunction.Proper on state words
    encoding: str = "cp1252"             # SQL file encoding (IWMAC tables are latin1)


@dataclass
class Comm:
    mode: str = "tcp"                    # tcp | rtu       (Main!B10)
    ip: str = ""                         # Main!B69
    port: int = 502
    com_port: str = ""                   # Main!B66
    baudrate: int = 19200                # Main!B72
    parity: str = "even"                 # none | odd | even  (Main!E75)
    stop_bits: int = 1
    data_bits: int = 8


@dataclass
class System:
    """Optional iw_sys_* blocks (Main_Setup B42/B45 sections)."""
    units: bool = False                  # emit iw_sys_plant_units + iw_sys_order_no
    settings: bool = False               # emit iw_sys_processes + iw_sys_plant_settings
    unit_id: str = ""                    # Main!B48
    unit_name: str = ""                  # Main!B51
    reg_type: str = ""                   # Main!B54
    order_no: str = ""                   # Main!B57
    owner: str = ""                      # Main!B60 (driver/settings owner)
    driver_addr: str = "1"               # Main!B63
    driver_addr_prefix: str = "1_"       # Main!C63/D63 ("1_" or "0_")
    comm: Comm = field(default_factory=Comm)


@dataclass
class Group:
    name: str
    alias: str = ""
    order: int = 0                       # view_order of the group_alias row


@dataclass
class Point:
    group: str = ""
    datatype: str = ""
    addr: int | None = None
    bit: int | str | None = None         # Work!F; int 0..31 or nibble syntax "5#4"
    element_id: str | None = None        # Work!C override
    system_no: str | None = None         # Work!M
    tag: str | None = None               # Work!N
    text: str = ""                       # Work!P (Aliastext)
    extra: str | None = None             # Work!O (Tag_extra)
    alarm: str | None = None             # Work!R (A/B/C/N)
    unit: str | None = None              # Work!S
    scale: str | None = None             # Work!T
    rw: str = "r"                        # Work!U
    online: bool = False                 # Work!V
    active: int | None = None            # Work!W (None -> 1 unless forced)
    no_group: bool = False               # Work!X = "x"
    menu: str | None = None              # Work!AA
    decimals: int | None = None          # Work!AB
    range_min: str | None = None         # Work!AC
    range_max: str | None = None         # Work!AD
    statetext: int | None = None         # Work!AE (Json Type No)
    synthesized: bool = False            # internal: auto-created motherword

    @property
    def is_motherword(self) -> bool:
        return self.text == "Motherword"


@dataclass
class Project:
    table: str
    plant: str
    options: Options
    system: System | None
    groups: list[Group]
    statetexts: dict[int, dict[int, str]]
    points: list[Point]


def _bool(v, ctx):
    if isinstance(v, bool):
        return v
    raise ProjectError(f"{ctx}: expected true/false, got {v!r}")


def load_project(data: dict) -> Project:
    if not isinstance(data, dict):
        raise ProjectError("project file must be a YAML mapping")
    top = _take(data, "project", {
        "table": None, "plant": None, "options": {}, "system": None,
        "groups": {}, "statetexts": {}, "points": [],
    })
    if not top["table"]:
        raise ProjectError("'table' is required (names the iw_par_/iw_set_ tables)")
    if top["plant"] is None:
        raise ProjectError("'plant' is required (plant number, used in the file name)")

    opt_spec = {f.name: getattr(Options(), f.name) for f in dc_fields(Options)}
    options = Options(**_take(top["options"] or {}, "options", opt_spec))

    system = None
    if top["system"] is not None:
        sys_spec = {f.name: getattr(System(), f.name) for f in dc_fields(System)}
        raw = _take(top["system"] or {}, "system", sys_spec)
        comm_spec = {f.name: getattr(Comm(), f.name) for f in dc_fields(Comm)}
        raw["comm"] = Comm(**_take(raw["comm"] if isinstance(raw["comm"], dict) else {},
                                   "system.comm", comm_spec))
        system = System(**raw)

    groups: list[Group] = []
    raw_groups = top["groups"] or {}
    if not isinstance(raw_groups, dict):
        raise ProjectError("'groups' must be a mapping of name -> alias")
    for i, (name, val) in enumerate(raw_groups.items(), start=1):
        if isinstance(val, str):
            groups.append(Group(str(name), val, i))
        elif isinstance(val, dict):
            g = _take(val, f"groups.{name}", {"alias": "", "order": i})
            groups.append(Group(str(name), g["alias"], int(g["order"])))
        else:
            raise ProjectError(f"groups.{name}: expected alias string or mapping")

    statetexts: dict[int, dict[int, str]] = {}
    for sid, states in (top["statetexts"] or {}).items():
        if not isinstance(states, dict):
            raise ProjectError(f"statetexts.{sid}: expected mapping number -> word")
        statetexts[int(sid)] = {int(k): str(v) for k, v in states.items()}

    pt_spec = {f.name: getattr(Point(), f.name) for f in dc_fields(Point)
               if f.name != "synthesized"}
    points = []
    for i, raw in enumerate(top["points"] or [], start=1):
        if not isinstance(raw, dict):
            raise ProjectError(f"points[{i}]: expected a mapping")
        p = Point(**_take(raw, f"points[{i}]", pt_spec))
        if p.addr is None:
            raise ProjectError(f"points[{i}]: 'addr' is required")
        p.rw = str(p.rw).lower()
        if p.alarm is not None:
            p.alarm = str(p.alarm).upper()
        p.online = _bool(p.online, f"points[{i}].online") if isinstance(p.online, bool) else bool(p.online)
        points.append(p)

    return Project(table=str(top["table"]), plant=str(top["plant"]), options=options,
                   system=system, groups=groups, statetexts=statetexts, points=points)
