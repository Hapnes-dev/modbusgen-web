"""Lookup tables (datatypes, units, scaling) loaded from data/tables/*.csv.

These CSVs are derived from the original workbook by tools/make_tables.py and are the
clean equivalents of Modbus_Variables!Z:AI, Modbus_Variables!U:X and
Generic_Variables!O:T (see docs/02-inputs.md).
"""
from __future__ import annotations

import copy
import csv
from dataclasses import dataclass
from pathlib import Path

DEFAULT_DIR = Path(__file__).resolve().parents[2] / "data" / "tables"


@dataclass(frozen=True)
class Datatype:
    name: str
    read_func: str
    write_func: str
    raw_type: str
    read_swap: str
    write_swap: str
    application: str
    parameter_type: str
    rw_hint: str
    default_group: str


@dataclass(frozen=True)
class Unit:
    unit: str
    iwmac_unit: str
    decimals: str


@dataclass(frozen=True)
class Scaling:
    key: str
    scale: str
    raw_min: str
    raw_max: str
    eng_min: str
    eng_max: str


class _FoldDict(dict):
    """Case-insensitive lookup, first-writer-wins - Excel VLOOKUP semantics.
    Keys keep their original spelling for iteration/display."""

    def __init__(self):
        super().__init__()
        self._fold: dict[str, str] = {}     # casefolded -> stored key

    def add(self, key: str, value) -> None:
        cf = key.casefold()
        if cf not in self._fold:
            self._fold[cf] = key
            super().__setitem__(key, value)

    def __contains__(self, key) -> bool:
        return isinstance(key, str) and key.casefold() in self._fold

    def __getitem__(self, key):
        return super().__getitem__(self._fold[key.casefold()])

    def get(self, key, default=None):
        try:
            return self[key]
        except KeyError:
            return default


class Tables:
    def __init__(self, directory: Path | None = None):
        d = Path(directory) if directory else DEFAULT_DIR
        self.directory = d
        self.datatypes = _FoldDict()
        self.units = _FoldDict()
        self.scaling = _FoldDict()
        for row in self._read(d / "datatypes.csv"):
            dt = Datatype(**row)
            self.datatypes.add(dt.name, dt)
        for row in self._read(d / "units.csv"):
            u = Unit(**row)
            self.units.add(u.unit, u)
        for row in self._read(d / "scaling.csv"):
            s = Scaling(**row)
            self.scaling.add(s.key, s)

    @staticmethod
    def _read(path: Path) -> list[dict]:
        with open(path, encoding="utf-8", newline="") as fh:
            return list(csv.DictReader(fh))

    def extended(self, extra: dict[str, "Datatype"]) -> "Tables":
        """A copy of these tables with extra datatype rows added.

        Added, never replacing: `_FoldDict.add` is first-writer-wins, which is Excel's
        VLOOKUP semantics, so a project row that repeats a shipped name is ignored here
        and reported by the validator. The receiver is left alone - the shipped tables
        are a process-wide singleton and one project must not edit them for the next.
        """
        if not extra:
            return self
        clone = copy.copy(self)
        merged = _FoldDict()
        for name, dt in self.datatypes.items():
            merged.add(name, dt)
        for name, dt in extra.items():
            merged.add(name, dt)
        clone.datatypes = merged
        return clone


_default: Tables | None = None


def default_tables() -> Tables:
    """The `data/tables/` CSVs, read once per process.

    Callers that only need to ask whether a key exists should not pay for three CSV
    parses each time; the CLI, the GUI backend and the browser build all run against
    the same shipped tables for the life of a process.
    """
    global _default
    if _default is None:
        _default = Tables()
    return _default


def project_tables(project, base: Tables | None = None) -> Tables:
    """The tables a project is read against: the shipped ones plus its own rows.

    One place, so validate, generate, the exporters and the importers cannot end up
    asking different questions of the same project.
    """
    return (base or default_tables()).extended(getattr(project, "datatypes", None) or {})


def unknown_datatypes(points, tables: Tables | None = None) -> dict[str, list[int]]:
    """Every datatype spelling the table does not describe -> the rows using it.

    Accepts project dicts or `Point` objects, so the importers can call it on what
    they are about to return and the exporter on what it has just loaded. Rows are
    1-based project positions, the numbering the GUI and the validator both use. A
    point with no datatype at all is not reported here: that is `datatype missing`,
    a different error with a different fix.
    """
    table = (tables or default_tables()).datatypes
    found: dict[str, list[int]] = {}
    for i, p in enumerate(points, start=1):
        name = p.get("datatype") if isinstance(p, dict) else getattr(p, "datatype", None)
        name = str(name).strip() if name not in (None, "") else ""
        if not name or name in table:
            continue
        found.setdefault(name, []).append(i)
    return found


def unknown_datatype_notes(points, tables: Tables | None = None) -> list[str]:
    """One importer note per undescribed datatype.

    An importer reads what a delivery actually contains and must not silently improve
    it, so this reports rather than repairs - but reporting at import is the moment
    that saves the work, because the same list will be rejected by `validate` and
    refused by the workbook export later on.
    """
    return [
        f"datatype '{name}' is not in data/tables/datatypes.csv - {len(rows)} point(s), "
        f"first at row {rows[0]}. Validation rejects the list and export-xlsm refuses "
        f"it until the spelling is corrected or the row is added to the table."
        for name, rows in sorted(unknown_datatypes(points, tables).items())
    ]
