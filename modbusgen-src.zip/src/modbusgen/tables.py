"""Lookup tables (datatypes, units, scaling) loaded from data/tables/*.csv.

These CSVs are derived from the original workbook by tools/make_tables.py and are the
clean equivalents of Modbus_Variables!Z:AI, Modbus_Variables!U:X and
Generic_Variables!O:T (see docs/02-inputs.md).
"""
from __future__ import annotations

import csv
from dataclasses import dataclass
from pathlib import Path

DEFAULT_DIR = Path(__file__).resolve().parents[2] / "data" / "tables"


@dataclass(frozen=True)
class Datatype:
    name: str
    read_func: str
    write_func: str
    raw_type: str
    read_swap: str
    write_swap: str
    application: str
    parameter_type: str
    rw_hint: str
    default_group: str


@dataclass(frozen=True)
class Unit:
    unit: str
    iwmac_unit: str
    decimals: str


@dataclass(frozen=True)
class Scaling:
    key: str
    scale: str
    raw_min: str
    raw_max: str
    eng_min: str
    eng_max: str


class Tables:
    def __init__(self, directory: Path | None = None):
        d = Path(directory) if directory else DEFAULT_DIR
        self.directory = d
        self.datatypes: dict[str, Datatype] = {}
        self.units: dict[str, Unit] = {}
        self.scaling: dict[str, Scaling] = {}
        for row in self._read(d / "datatypes.csv"):
            dt = Datatype(**row)
            # first occurrence wins, matching Excel VLOOKUP semantics
            self.datatypes.setdefault(dt.name, dt)
        for row in self._read(d / "units.csv"):
            u = Unit(**row)
            self.units.setdefault(u.unit, u)
        for row in self._read(d / "scaling.csv"):
            s = Scaling(**row)
            self.scaling.setdefault(s.key, s)

    @staticmethod
    def _read(path: Path) -> list[dict]:
        with open(path, encoding="utf-8", newline="") as fh:
            return list(csv.DictReader(fh))
