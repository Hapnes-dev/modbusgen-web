"""Lookup tables (datatypes, units, scaling) loaded from data/tables/*.csv.

These CSVs are derived from the original workbook by tools/make_tables.py and are the
clean equivalents of Modbus_Variables!Z:AI, Modbus_Variables!U:X and
Generic_Variables!O:T (see docs/02-inputs.md).
"""
from __future__ import annotations

import csv
from dataclasses import dataclass
from pathlib import Path

DEFAULT_DIR = Path(__file__).resolve().parents[2] / "data" / "tables"


@dataclass(frozen=True)
class Datatype:
    name: str
    read_func: str
    write_func: str
    raw_type: str
    read_swap: str
    write_swap: str
    application: str
    parameter_type: str
    rw_hint: str
    default_group: str


@dataclass(frozen=True)
class Unit:
    unit: str
    iwmac_unit: str
    decimals: str


@dataclass(frozen=True)
class Scaling:
    key: str
    scale: str
    raw_min: str
    raw_max: str
    eng_min: str
    eng_max: str


class _FoldDict(dict):
    """Case-insensitive lookup, first-writer-wins - Excel VLOOKUP semantics.
    Keys keep their original spelling for iteration/display."""

    def __init__(self):
        super().__init__()
        self._fold: dict[str, str] = {}     # casefolded -> stored key

    def add(self, key: str, value) -> None:
        cf = key.casefold()
        if cf not in self._fold:
            self._fold[cf] = key
            super().__setitem__(key, value)

    def __contains__(self, key) -> bool:
        return isinstance(key, str) and key.casefold() in self._fold

    def __getitem__(self, key):
        return super().__getitem__(self._fold[key.casefold()])

    def get(self, key, default=None):
        try:
            return self[key]
        except KeyError:
            return default


class Tables:
    def __init__(self, directory: Path | None = None):
        d = Path(directory) if directory else DEFAULT_DIR
        self.directory = d
        self.datatypes = _FoldDict()
        self.units = _FoldDict()
        self.scaling = _FoldDict()
        for row in self._read(d / "datatypes.csv"):
            dt = Datatype(**row)
            self.datatypes.add(dt.name, dt)
        for row in self._read(d / "units.csv"):
            u = Unit(**row)
            self.units.add(u.unit, u)
        for row in self._read(d / "scaling.csv"):
            s = Scaling(**row)
            self.scaling.add(s.key, s)

    @staticmethod
    def _read(path: Path) -> list[dict]:
        with open(path, encoding="utf-8", newline="") as fh:
            return list(csv.DictReader(fh))
